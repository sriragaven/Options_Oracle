# OptionsOracle

Since options trading is more complex and can involve much higher risk than simple stock trading, traders need to fully understand the options strategy before investing in it. This is where OptionsOracle comes to help. OptionsOracle is a powerful tool that allows testing of different options strategies using real-time options & stock-market information. The tool provides an easy interface to build a stock/options position and then test it using graphs and analytical tools.

OptionsOracle Web Site http://www.samoasky.com/

Investment
