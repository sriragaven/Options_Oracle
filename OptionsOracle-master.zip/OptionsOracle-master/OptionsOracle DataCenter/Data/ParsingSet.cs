﻿namespace OptionsOracle.DataCenter.Data {


    partial class ParsingSet
    {
    }
}
