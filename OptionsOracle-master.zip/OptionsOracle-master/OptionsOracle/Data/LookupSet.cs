﻿namespace OptionsOracle.Data 
{
    partial class LookupSet
    {
    }
}
