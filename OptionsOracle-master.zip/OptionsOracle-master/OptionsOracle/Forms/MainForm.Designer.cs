namespace OptionsOracle.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.stockContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.downloadWorker = new System.ComponentModel.BackgroundWorker();
            this.positionGroupBox = new System.Windows.Forms.GroupBox();
            this.designerButton = new System.Windows.Forms.Button();
            this.templateButton = new System.Windows.Forms.Button();
            this.endMonthUpDown = new System.Windows.Forms.NumericUpDown();
            this.startMonthUpDown = new System.Windows.Forms.NumericUpDown();
            this.endDayUpDown = new System.Windows.Forms.NumericUpDown();
            this.startDayUpDown = new System.Windows.Forms.NumericUpDown();
            this.endDateTextBox = new System.Windows.Forms.TextBox();
            this.unfreezeContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.unfreezeDateLookupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startDateTextBox = new System.Windows.Forms.TextBox();
            this.endDateLabel = new System.Windows.Forms.Label();
            this.startDateLabel = new System.Windows.Forms.Label();
            this.addRowbutton = new System.Windows.Forms.Button();
            this.deleteRowbutton = new System.Windows.Forms.Button();
            this.clearPositionButton = new System.Windows.Forms.Button();
            this.strategyDataGridView = new System.Windows.Forms.DataGridView();
            this.positionsIndexColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsFlagsColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsEnableColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.positionsIdColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.positionsTypeColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.positionsStrikeColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.positionsExpirationColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.positionsSymbolColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.positionsQuantityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsToOpenColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.positionsPriceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsLastPriceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsVolatilityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsCommissionColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsNetMarginColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsMktValueColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsInvestmentColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsDeltaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsGammaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsVegaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsThetaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsTimeValueColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsInterestColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionsContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addRowMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteRowMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.freezeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.positionsTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.optionsSet = new OptionsOracle.Data.OptionsSet();
            this.endDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.globalTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.startDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.notesTextBox = new System.Windows.Forms.TextBox();
            this.tourButton = new System.Windows.Forms.Button();
            this.resultGroupBox = new System.Windows.Forms.GroupBox();
            this.resultsDataGridView = new System.Windows.Forms.DataGridView();
            this.resultsIndexColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsIsCreditColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.resultsCriteriaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsPriceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsChangeColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsProbColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsTotalColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsTotalPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsMonthlyPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.graphButton = new System.Windows.Forms.Button();
            this.controlGroupBox = new System.Windows.Forms.GroupBox();
            this.aboutButton = new System.Windows.Forms.Button();
            this.optionPainButton = new System.Windows.Forms.Button();
            this.analysisButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.printButton = new System.Windows.Forms.Button();
            this.volatilitySmileButton = new System.Windows.Forms.Button();
            this.portfolioButton = new System.Windows.Forms.Button();
            this.putCallRatioButton = new System.Windows.Forms.Button();
            this.volatilityCalcButton = new System.Windows.Forms.Button();
            this.wizardButton = new System.Windows.Forms.Button();
            this.calculatorButton = new System.Windows.Forms.Button();
            this.newButton = new System.Windows.Forms.Button();
            this.contactUsButton = new System.Windows.Forms.Button();
            this.loadButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.configurationButton = new System.Windows.Forms.Button();
            this.titlePanelWebBrowser = new System.Windows.Forms.WebBrowser();
            this.autoRefreshTimer = new System.Windows.Forms.Timer(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.autoRefreshCheckBox = new System.Windows.Forms.CheckBox();
            this.itmCheckBox = new System.Windows.Forms.CheckBox();
            this.atmCheckBox = new System.Windows.Forms.CheckBox();
            this.otmCheckBox = new System.Windows.Forms.CheckBox();
            this.grkCheckBox = new System.Windows.Forms.CheckBox();
            this.graphWorker = new System.ComponentModel.BackgroundWorker();
            this.optionsDataGridView = new System.Windows.Forms.DataGridView();
            this.optionsTypeColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsStrikeColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsExpirationColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsSymbolColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsLastColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsChangeColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsTimeValueColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsBidColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsAskColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsVolumeColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsOpenIntColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsImpliedVolatilityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsITMProbColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsDeltaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsGammaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsVegaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsThetaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsStockColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsUpdateTimeStampColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsStdDevColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsIndicator1Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsIndicator2Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.optionsTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stockLabel = new System.Windows.Forms.Label();
            this.lastPriceText = new System.Windows.Forms.TextBox();
            this.changeText = new System.Windows.Forms.TextBox();
            this.bidText = new System.Windows.Forms.TextBox();
            this.dividendText = new System.Windows.Forms.TextBox();
            this.lastPriceLabel = new System.Windows.Forms.Label();
            this.changeLabel = new System.Windows.Forms.Label();
            this.bidAskLabel = new System.Windows.Forms.Label();
            this.lastUpdateText = new System.Windows.Forms.TextBox();
            this.dividendLabel = new System.Windows.Forms.Label();
            this.lastUpdateLabel = new System.Windows.Forms.Label();
            this.optionSelectionGroupBox1 = new System.Windows.Forms.GroupBox();
            this.putsCheckBox = new System.Windows.Forms.CheckBox();
            this.callsCheckBox = new System.Windows.Forms.CheckBox();
            this.optionSelectionGroupBox3 = new System.Windows.Forms.GroupBox();
            this.expRadioButton7 = new System.Windows.Forms.RadioButton();
            this.expRadioButton6 = new System.Windows.Forms.RadioButton();
            this.expRadioButton5 = new System.Windows.Forms.RadioButton();
            this.expRadioButton4 = new System.Windows.Forms.RadioButton();
            this.expRadioButton3 = new System.Windows.Forms.RadioButton();
            this.expRadioButton2 = new System.Windows.Forms.RadioButton();
            this.expRadioButton1 = new System.Windows.Forms.RadioButton();
            this.expRadioButtonAll = new System.Windows.Forms.RadioButton();
            this.stockText = new System.Windows.Forms.TextBox();
            this.updateButton = new System.Windows.Forms.Button();
            this.optionSelectionGroupBox2 = new System.Windows.Forms.GroupBox();
            this.impHisLabel = new System.Windows.Forms.Label();
            this.impVolatilityText = new System.Windows.Forms.TextBox();
            this.optionSelectionGroupBox4 = new System.Windows.Forms.GroupBox();
            this.stockGroupBox = new System.Windows.Forms.GroupBox();
            this.askText = new System.Windows.Forms.TextBox();
            this.hisVolatilityText = new System.Windows.Forms.TextBox();
            this.downloadLabel = new System.Windows.Forms.Label();
            this.progressLabel = new System.Windows.Forms.Label();
            this.serverProgressBar = new System.Windows.Forms.ProgressBar();
            this.topSplitContainer = new System.Windows.Forms.SplitContainer();
            this.bottomSplitContainer = new System.Windows.Forms.SplitContainer();
            this.analysisWorker = new System.ComponentModel.BackgroundWorker();
            this.endEditTimer = new System.Windows.Forms.Timer(this.components);
            this.quotesTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.opoOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.opoSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.positionGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.endMonthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startMonthUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.endDayUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startDayUpDown)).BeginInit();
            this.unfreezeContextMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.strategyDataGridView)).BeginInit();
            this.positionsContextMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.positionsTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.optionsSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.globalTableBindingSource)).BeginInit();
            this.resultGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultsTableBindingSource)).BeginInit();
            this.controlGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.optionsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.optionsTableBindingSource)).BeginInit();
            this.optionSelectionGroupBox1.SuspendLayout();
            this.optionSelectionGroupBox3.SuspendLayout();
            this.optionSelectionGroupBox2.SuspendLayout();
            this.optionSelectionGroupBox4.SuspendLayout();
            this.stockGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.topSplitContainer)).BeginInit();
            this.topSplitContainer.Panel1.SuspendLayout();
            this.topSplitContainer.Panel2.SuspendLayout();
            this.topSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bottomSplitContainer)).BeginInit();
            this.bottomSplitContainer.Panel1.SuspendLayout();
            this.bottomSplitContainer.Panel2.SuspendLayout();
            this.bottomSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.quotesTableBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // stockContextMenu
            // 
            this.stockContextMenu.Name = "stockContextMenu";
            this.stockContextMenu.Size = new System.Drawing.Size(61, 4);
            this.stockContextMenu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.stockContextMenu_ItemClicked);
            // 
            // downloadWorker
            // 
            this.downloadWorker.WorkerReportsProgress = true;
            this.downloadWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.downloadWorker_DoWork);
            this.downloadWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.downloadWorker_ProgressChanged);
            this.downloadWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.downloadWorker_RunWorkerComplete);
            // 
            // positionGroupBox
            // 
            this.positionGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.positionGroupBox.Controls.Add(this.designerButton);
            this.positionGroupBox.Controls.Add(this.templateButton);
            this.positionGroupBox.Controls.Add(this.endMonthUpDown);
            this.positionGroupBox.Controls.Add(this.startMonthUpDown);
            this.positionGroupBox.Controls.Add(this.endDayUpDown);
            this.positionGroupBox.Controls.Add(this.startDayUpDown);
            this.positionGroupBox.Controls.Add(this.endDateTextBox);
            this.positionGroupBox.Controls.Add(this.startDateTextBox);
            this.positionGroupBox.Controls.Add(this.endDateLabel);
            this.positionGroupBox.Controls.Add(this.startDateLabel);
            this.positionGroupBox.Controls.Add(this.addRowbutton);
            this.positionGroupBox.Controls.Add(this.deleteRowbutton);
            this.positionGroupBox.Controls.Add(this.clearPositionButton);
            this.positionGroupBox.Controls.Add(this.strategyDataGridView);
            this.positionGroupBox.Controls.Add(this.endDateTimePicker);
            this.positionGroupBox.Controls.Add(this.startDateTimePicker);
            this.positionGroupBox.Controls.Add(this.notesTextBox);
            this.positionGroupBox.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.positionGroupBox.Enabled = false;
            this.positionGroupBox.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.positionGroupBox.Location = new System.Drawing.Point(0, 2);
            this.positionGroupBox.Name = "positionGroupBox";
            this.positionGroupBox.Size = new System.Drawing.Size(1007, 224);
            this.positionGroupBox.TabIndex = 0;
            this.positionGroupBox.TabStop = false;
            this.positionGroupBox.Text = "Strategy Positions";
            // 
            // designerButton
            // 
            this.designerButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.designerButton.Location = new System.Drawing.Point(205, 192);
            this.designerButton.Name = "designerButton";
            this.designerButton.Size = new System.Drawing.Size(90, 24);
            this.designerButton.TabIndex = 36;
            this.designerButton.Text = "Designer...";
            this.designerButton.UseVisualStyleBackColor = true;
            this.designerButton.Visible = false;
            this.designerButton.Click += new System.EventHandler(this.designerButton_Click);
            // 
            // templateButton
            // 
            this.templateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.templateButton.Location = new System.Drawing.Point(205, 166);
            this.templateButton.Name = "templateButton";
            this.templateButton.Size = new System.Drawing.Size(90, 24);
            this.templateButton.TabIndex = 19;
            this.templateButton.Text = "Template...";
            this.templateButton.UseVisualStyleBackColor = true;
            this.templateButton.Click += new System.EventHandler(this.templateButton_Click);
            // 
            // endMonthUpDown
            // 
            this.endMonthUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.endMonthUpDown.Location = new System.Drawing.Point(485, 192);
            this.endMonthUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.endMonthUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.endMonthUpDown.Name = "endMonthUpDown";
            this.endMonthUpDown.Size = new System.Drawing.Size(18, 20);
            this.endMonthUpDown.TabIndex = 28;
            this.endMonthUpDown.Tag = "0";
            this.endMonthUpDown.ValueChanged += new System.EventHandler(this.dateUpDown_ValueChanged);
            // 
            // startMonthUpDown
            // 
            this.startMonthUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.startMonthUpDown.Location = new System.Drawing.Point(485, 169);
            this.startMonthUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.startMonthUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.startMonthUpDown.Name = "startMonthUpDown";
            this.startMonthUpDown.Size = new System.Drawing.Size(18, 20);
            this.startMonthUpDown.TabIndex = 25;
            this.startMonthUpDown.Tag = "0";
            this.startMonthUpDown.ValueChanged += new System.EventHandler(this.dateUpDown_ValueChanged);
            // 
            // endDayUpDown
            // 
            this.endDayUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.endDayUpDown.Location = new System.Drawing.Point(468, 192);
            this.endDayUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.endDayUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.endDayUpDown.Name = "endDayUpDown";
            this.endDayUpDown.Size = new System.Drawing.Size(18, 20);
            this.endDayUpDown.TabIndex = 27;
            this.endDayUpDown.Tag = "0";
            this.endDayUpDown.ValueChanged += new System.EventHandler(this.dateUpDown_ValueChanged);
            // 
            // startDayUpDown
            // 
            this.startDayUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.startDayUpDown.Location = new System.Drawing.Point(468, 169);
            this.startDayUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.startDayUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.startDayUpDown.Name = "startDayUpDown";
            this.startDayUpDown.Size = new System.Drawing.Size(18, 20);
            this.startDayUpDown.TabIndex = 24;
            this.startDayUpDown.Tag = "0";
            this.startDayUpDown.ValueChanged += new System.EventHandler(this.dateUpDown_ValueChanged);
            // 
            // endDateTextBox
            // 
            this.endDateTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.endDateTextBox.BackColor = System.Drawing.Color.Black;
            this.endDateTextBox.ContextMenuStrip = this.unfreezeContextMenu;
            this.endDateTextBox.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endDateTextBox.ForeColor = System.Drawing.Color.Cornsilk;
            this.endDateTextBox.Location = new System.Drawing.Point(388, 192);
            this.endDateTextBox.Name = "endDateTextBox";
            this.endDateTextBox.ReadOnly = true;
            this.endDateTextBox.Size = new System.Drawing.Size(79, 20);
            this.endDateTextBox.TabIndex = 26;
            this.endDateTextBox.TabStop = false;
            this.endDateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.endDateTextBox.Click += new System.EventHandler(this.dateTextBox_Click);
            // 
            // unfreezeContextMenu
            // 
            this.unfreezeContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unfreezeDateLookupToolStripMenuItem});
            this.unfreezeContextMenu.Name = "unfreezeContextMenu";
            this.unfreezeContextMenu.Size = new System.Drawing.Size(121, 26);
            // 
            // unfreezeDateLookupToolStripMenuItem
            // 
            this.unfreezeDateLookupToolStripMenuItem.Name = "unfreezeDateLookupToolStripMenuItem";
            this.unfreezeDateLookupToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.unfreezeDateLookupToolStripMenuItem.Tag = "0";
            this.unfreezeDateLookupToolStripMenuItem.Text = "Unfreeze";
            this.unfreezeDateLookupToolStripMenuItem.Click += new System.EventHandler(this.unfreezeStripMenuItem_Click);
            // 
            // startDateTextBox
            // 
            this.startDateTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.startDateTextBox.BackColor = System.Drawing.Color.Black;
            this.startDateTextBox.ContextMenuStrip = this.unfreezeContextMenu;
            this.startDateTextBox.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startDateTextBox.ForeColor = System.Drawing.Color.Cornsilk;
            this.startDateTextBox.Location = new System.Drawing.Point(388, 169);
            this.startDateTextBox.Name = "startDateTextBox";
            this.startDateTextBox.ReadOnly = true;
            this.startDateTextBox.Size = new System.Drawing.Size(79, 20);
            this.startDateTextBox.TabIndex = 23;
            this.startDateTextBox.TabStop = false;
            this.startDateTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.startDateTextBox.Click += new System.EventHandler(this.dateTextBox_Click);
            // 
            // endDateLabel
            // 
            this.endDateLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.endDateLabel.AutoSize = true;
            this.endDateLabel.Location = new System.Drawing.Point(331, 195);
            this.endDateLabel.Name = "endDateLabel";
            this.endDateLabel.Size = new System.Drawing.Size(50, 14);
            this.endDateLabel.TabIndex = 0;
            this.endDateLabel.Text = "End Date";
            // 
            // startDateLabel
            // 
            this.startDateLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.startDateLabel.AutoSize = true;
            this.startDateLabel.Location = new System.Drawing.Point(331, 172);
            this.startDateLabel.Name = "startDateLabel";
            this.startDateLabel.Size = new System.Drawing.Size(55, 14);
            this.startDateLabel.TabIndex = 0;
            this.startDateLabel.Text = "Start Date";
            // 
            // addRowbutton
            // 
            this.addRowbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addRowbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addRowbutton.Location = new System.Drawing.Point(109, 166);
            this.addRowbutton.Name = "addRowbutton";
            this.addRowbutton.Size = new System.Drawing.Size(90, 24);
            this.addRowbutton.TabIndex = 22;
            this.addRowbutton.Text = "Add Row";
            this.addRowbutton.UseVisualStyleBackColor = true;
            this.addRowbutton.Click += new System.EventHandler(this.addRowbutton_Click);
            // 
            // deleteRowbutton
            // 
            this.deleteRowbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.deleteRowbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deleteRowbutton.Location = new System.Drawing.Point(13, 166);
            this.deleteRowbutton.Name = "deleteRowbutton";
            this.deleteRowbutton.Size = new System.Drawing.Size(90, 24);
            this.deleteRowbutton.TabIndex = 21;
            this.deleteRowbutton.Text = "Delete Row";
            this.deleteRowbutton.UseVisualStyleBackColor = true;
            this.deleteRowbutton.Click += new System.EventHandler(this.deleteRowbutton_Click);
            // 
            // clearPositionButton
            // 
            this.clearPositionButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.clearPositionButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearPositionButton.Location = new System.Drawing.Point(13, 192);
            this.clearPositionButton.Name = "clearPositionButton";
            this.clearPositionButton.Size = new System.Drawing.Size(90, 24);
            this.clearPositionButton.TabIndex = 20;
            this.clearPositionButton.Text = "Delete All";
            this.clearPositionButton.UseVisualStyleBackColor = true;
            this.clearPositionButton.Click += new System.EventHandler(this.clearPositionButton_Click);
            // 
            // strategyDataGridView
            // 
            this.strategyDataGridView.AllowDrop = true;
            this.strategyDataGridView.AllowUserToAddRows = false;
            this.strategyDataGridView.AllowUserToDeleteRows = false;
            this.strategyDataGridView.AllowUserToOrderColumns = true;
            this.strategyDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.strategyDataGridView.AutoGenerateColumns = false;
            this.strategyDataGridView.ColumnHeadersHeight = 22;
            this.strategyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.strategyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.positionsIndexColumn,
            this.positionsFlagsColumn,
            this.positionsEnableColumn,
            this.positionsIdColumn,
            this.positionsTypeColumn,
            this.positionsStrikeColumn,
            this.positionsExpirationColumn,
            this.positionsSymbolColumn,
            this.positionsQuantityColumn,
            this.positionsToOpenColumn,
            this.positionsPriceColumn,
            this.positionsLastPriceColumn,
            this.positionsVolatilityColumn,
            this.positionsCommissionColumn,
            this.positionsNetMarginColumn,
            this.positionsMktValueColumn,
            this.positionsInvestmentColumn,
            this.positionsDeltaColumn,
            this.positionsGammaColumn,
            this.positionsVegaColumn,
            this.positionsThetaColumn,
            this.positionsTimeValueColumn,
            this.positionsInterestColumn});
            this.strategyDataGridView.ContextMenuStrip = this.positionsContextMenu;
            this.strategyDataGridView.DataSource = this.positionsTableBindingSource;
            this.strategyDataGridView.Location = new System.Drawing.Point(13, 17);
            this.strategyDataGridView.Name = "strategyDataGridView";
            this.strategyDataGridView.RowHeadersVisible = false;
            this.strategyDataGridView.RowHeadersWidth = 16;
            dataGridViewCellStyle17.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle17.ForeColor = System.Drawing.Color.Cornsilk;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.Color.Cornsilk;
            this.strategyDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle17;
            this.strategyDataGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.strategyDataGridView.RowTemplate.DefaultCellStyle.NullValue = "N/A";
            this.strategyDataGridView.RowTemplate.Height = 20;
            this.strategyDataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.strategyDataGridView.Size = new System.Drawing.Size(983, 144);
            this.strategyDataGridView.TabIndex = 18;
            this.strategyDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.strategyDataGridView_CellClick);
            this.strategyDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.strategyDataGridView_CellContentClick);
            this.strategyDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.strategyDataGridView_CellFormatting);
            this.strategyDataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.strategyDataGridView_CellValueChanged);
            this.strategyDataGridView.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.strategyDataGridView_DataError);
            this.strategyDataGridView.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.strategyDataGridView_EditingControlShowing);
            this.strategyDataGridView.SelectionChanged += new System.EventHandler(this.strategyDataGridView_SelectionChanged);
            this.strategyDataGridView.DragDrop += new System.Windows.Forms.DragEventHandler(this.strategyDataGridView_DragDrop);
            this.strategyDataGridView.DragEnter += new System.Windows.Forms.DragEventHandler(this.strategyDataGridView_DragEnter);
            this.strategyDataGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.strategyDataGridView_KeyUp);
            this.strategyDataGridView.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.strategyDataGridView_MouseDoubleClick);
            this.strategyDataGridView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.strategyDataGridView_MouseDown);
            // 
            // positionsIndexColumn
            // 
            this.positionsIndexColumn.DataPropertyName = "Index";
            this.positionsIndexColumn.HeaderText = "Index";
            this.positionsIndexColumn.Name = "positionsIndexColumn";
            this.positionsIndexColumn.Visible = false;
            // 
            // positionsFlagsColumn
            // 
            this.positionsFlagsColumn.DataPropertyName = "Flags";
            this.positionsFlagsColumn.HeaderText = "Flags";
            this.positionsFlagsColumn.Name = "positionsFlagsColumn";
            this.positionsFlagsColumn.Visible = false;
            // 
            // positionsEnableColumn
            // 
            this.positionsEnableColumn.DataPropertyName = "Enable";
            this.positionsEnableColumn.HeaderText = "X";
            this.positionsEnableColumn.MinimumWidth = 20;
            this.positionsEnableColumn.Name = "positionsEnableColumn";
            this.positionsEnableColumn.Width = 20;
            // 
            // positionsIdColumn
            // 
            this.positionsIdColumn.DataPropertyName = "Id";
            this.positionsIdColumn.HeaderText = "I";
            this.positionsIdColumn.Name = "positionsIdColumn";
            this.positionsIdColumn.Visible = false;
            // 
            // positionsTypeColumn
            // 
            this.positionsTypeColumn.DataPropertyName = "Type";
            this.positionsTypeColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.positionsTypeColumn.HeaderText = "Type";
            this.positionsTypeColumn.Items.AddRange(new object[] {
            "Long Stock",
            "Short Stock",
            "Long Call",
            "Short Call",
            "Long Put",
            "Short Put"});
            this.positionsTypeColumn.Name = "positionsTypeColumn";
            this.positionsTypeColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.positionsTypeColumn.ToolTipText = "Position Type";
            this.positionsTypeColumn.Width = 68;
            // 
            // positionsStrikeColumn
            // 
            this.positionsStrikeColumn.DataPropertyName = "Strike";
            dataGridViewCellStyle1.Format = "N2";
            this.positionsStrikeColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.positionsStrikeColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.positionsStrikeColumn.HeaderText = "Strike";
            this.positionsStrikeColumn.Name = "positionsStrikeColumn";
            this.positionsStrikeColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.positionsStrikeColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.positionsStrikeColumn.ToolTipText = "Option Position Strike";
            this.positionsStrikeColumn.Width = 66;
            // 
            // positionsExpirationColumn
            // 
            this.positionsExpirationColumn.DataPropertyName = "Expiration";
            dataGridViewCellStyle2.Format = "dd-MMM-yyyy";
            this.positionsExpirationColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.positionsExpirationColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.positionsExpirationColumn.HeaderText = "Expiration";
            this.positionsExpirationColumn.Name = "positionsExpirationColumn";
            this.positionsExpirationColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.positionsExpirationColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.positionsExpirationColumn.ToolTipText = "Option Position Expiration Date";
            this.positionsExpirationColumn.Width = 75;
            // 
            // positionsSymbolColumn
            // 
            this.positionsSymbolColumn.DataPropertyName = "Symbol";
            this.positionsSymbolColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.positionsSymbolColumn.HeaderText = "Symbol";
            this.positionsSymbolColumn.Name = "positionsSymbolColumn";
            this.positionsSymbolColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.positionsSymbolColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.positionsSymbolColumn.ToolTipText = "Position Symbol";
            this.positionsSymbolColumn.Width = 67;
            // 
            // positionsQuantityColumn
            // 
            this.positionsQuantityColumn.DataPropertyName = "Quantity";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.positionsQuantityColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.positionsQuantityColumn.HeaderText = "Quantity";
            this.positionsQuantityColumn.Name = "positionsQuantityColumn";
            this.positionsQuantityColumn.ToolTipText = "Quantity of Position";
            this.positionsQuantityColumn.Width = 52;
            // 
            // positionsToOpenColumn
            // 
            this.positionsToOpenColumn.DataPropertyName = "ToOpen";
            this.positionsToOpenColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.positionsToOpenColumn.HeaderText = "Opn/Cls";
            this.positionsToOpenColumn.Name = "positionsToOpenColumn";
            this.positionsToOpenColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.positionsToOpenColumn.ToolTipText = "Position to Open/Close";
            this.positionsToOpenColumn.Width = 49;
            // 
            // positionsPriceColumn
            // 
            this.positionsPriceColumn.DataPropertyName = "Price";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N2";
            this.positionsPriceColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.positionsPriceColumn.HeaderText = "Price";
            this.positionsPriceColumn.Name = "positionsPriceColumn";
            this.positionsPriceColumn.ToolTipText = "Position Open Price";
            this.positionsPriceColumn.Width = 49;
            // 
            // positionsLastPriceColumn
            // 
            this.positionsLastPriceColumn.DataPropertyName = "LastPrice";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N2";
            this.positionsLastPriceColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.positionsLastPriceColumn.HeaderText = "Last";
            this.positionsLastPriceColumn.Name = "positionsLastPriceColumn";
            this.positionsLastPriceColumn.ReadOnly = true;
            this.positionsLastPriceColumn.ToolTipText = "Position Last Market Price";
            this.positionsLastPriceColumn.Width = 49;
            // 
            // positionsVolatilityColumn
            // 
            this.positionsVolatilityColumn.DataPropertyName = "Volatility";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N2";
            this.positionsVolatilityColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.positionsVolatilityColumn.HeaderText = "Volatility %";
            this.positionsVolatilityColumn.Name = "positionsVolatilityColumn";
            this.positionsVolatilityColumn.ToolTipText = "Volatility used for option time analysis";
            this.positionsVolatilityColumn.Width = 65;
            // 
            // positionsCommissionColumn
            // 
            this.positionsCommissionColumn.DataPropertyName = "Commission";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N2";
            this.positionsCommissionColumn.DefaultCellStyle = dataGridViewCellStyle7;
            this.positionsCommissionColumn.HeaderText = "Commission";
            this.positionsCommissionColumn.Name = "positionsCommissionColumn";
            this.positionsCommissionColumn.ToolTipText = "Commission for Open or Close Transaction";
            this.positionsCommissionColumn.Width = 68;
            // 
            // positionsNetMarginColumn
            // 
            this.positionsNetMarginColumn.DataPropertyName = "NetMargin";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "N2";
            this.positionsNetMarginColumn.DefaultCellStyle = dataGridViewCellStyle8;
            this.positionsNetMarginColumn.HeaderText = "Margin";
            this.positionsNetMarginColumn.Name = "positionsNetMarginColumn";
            this.positionsNetMarginColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.positionsNetMarginColumn.ToolTipText = "Margin Requirement (cost + collateral)";
            this.positionsNetMarginColumn.Width = 65;
            // 
            // positionsMktValueColumn
            // 
            this.positionsMktValueColumn.DataPropertyName = "MktValue";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N2";
            this.positionsMktValueColumn.DefaultCellStyle = dataGridViewCellStyle9;
            this.positionsMktValueColumn.HeaderText = "Debit";
            this.positionsMktValueColumn.Name = "positionsMktValueColumn";
            this.positionsMktValueColumn.ReadOnly = true;
            this.positionsMktValueColumn.ToolTipText = "Position Debit";
            this.positionsMktValueColumn.Width = 65;
            // 
            // positionsInvestmentColumn
            // 
            this.positionsInvestmentColumn.DataPropertyName = "Investment";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "N2";
            this.positionsInvestmentColumn.DefaultCellStyle = dataGridViewCellStyle10;
            this.positionsInvestmentColumn.HeaderText = "Investment";
            this.positionsInvestmentColumn.Name = "positionsInvestmentColumn";
            this.positionsInvestmentColumn.ReadOnly = true;
            this.positionsInvestmentColumn.ToolTipText = "Total Investment (including cost & collateral)";
            this.positionsInvestmentColumn.Width = 65;
            // 
            // positionsDeltaColumn
            // 
            this.positionsDeltaColumn.DataPropertyName = "Delta";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle11.Format = "N2";
            this.positionsDeltaColumn.DefaultCellStyle = dataGridViewCellStyle11;
            this.positionsDeltaColumn.HeaderText = "Delta";
            this.positionsDeltaColumn.Name = "positionsDeltaColumn";
            this.positionsDeltaColumn.Width = 65;
            // 
            // positionsGammaColumn
            // 
            this.positionsGammaColumn.DataPropertyName = "Gamma";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle12.Format = "N2";
            this.positionsGammaColumn.DefaultCellStyle = dataGridViewCellStyle12;
            this.positionsGammaColumn.HeaderText = "Gamma";
            this.positionsGammaColumn.Name = "positionsGammaColumn";
            this.positionsGammaColumn.Width = 65;
            // 
            // positionsVegaColumn
            // 
            this.positionsVegaColumn.DataPropertyName = "Vega";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle13.Format = "N2";
            this.positionsVegaColumn.DefaultCellStyle = dataGridViewCellStyle13;
            this.positionsVegaColumn.HeaderText = "Vega";
            this.positionsVegaColumn.Name = "positionsVegaColumn";
            this.positionsVegaColumn.Width = 65;
            // 
            // positionsThetaColumn
            // 
            this.positionsThetaColumn.DataPropertyName = "Theta";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle14.Format = "N2";
            this.positionsThetaColumn.DefaultCellStyle = dataGridViewCellStyle14;
            this.positionsThetaColumn.HeaderText = "Theta";
            this.positionsThetaColumn.Name = "positionsThetaColumn";
            this.positionsThetaColumn.Width = 65;
            // 
            // positionsTimeValueColumn
            // 
            this.positionsTimeValueColumn.DataPropertyName = "TimeValue";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle15.Format = "N2";
            this.positionsTimeValueColumn.DefaultCellStyle = dataGridViewCellStyle15;
            this.positionsTimeValueColumn.HeaderText = "TimeValue";
            this.positionsTimeValueColumn.Name = "positionsTimeValueColumn";
            this.positionsTimeValueColumn.Width = 65;
            // 
            // positionsInterestColumn
            // 
            this.positionsInterestColumn.DataPropertyName = "Interest";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle16.Format = "N2";
            this.positionsInterestColumn.DefaultCellStyle = dataGridViewCellStyle16;
            this.positionsInterestColumn.HeaderText = "Interest";
            this.positionsInterestColumn.Name = "positionsInterestColumn";
            this.positionsInterestColumn.Width = 65;
            // 
            // positionsContextMenu
            // 
            this.positionsContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addRowMenuItem,
            this.deleteRowMenuItem,
            this.toolStripSeparator2,
            this.freezeToolStripMenuItem});
            this.positionsContextMenu.Name = "expirationMenuStrip";
            this.positionsContextMenu.Size = new System.Drawing.Size(134, 76);
            this.positionsContextMenu.Text = "Positions Menu";
            // 
            // addRowMenuItem
            // 
            this.addRowMenuItem.Name = "addRowMenuItem";
            this.addRowMenuItem.Size = new System.Drawing.Size(133, 22);
            this.addRowMenuItem.Text = "Add Row";
            this.addRowMenuItem.Click += new System.EventHandler(this.addRowbutton_Click);
            // 
            // deleteRowMenuItem
            // 
            this.deleteRowMenuItem.Name = "deleteRowMenuItem";
            this.deleteRowMenuItem.Size = new System.Drawing.Size(133, 22);
            this.deleteRowMenuItem.Text = "Delete Row";
            this.deleteRowMenuItem.Click += new System.EventHandler(this.deleteRowbutton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(130, 6);
            // 
            // freezeToolStripMenuItem
            // 
            this.freezeToolStripMenuItem.Name = "freezeToolStripMenuItem";
            this.freezeToolStripMenuItem.Size = new System.Drawing.Size(133, 22);
            this.freezeToolStripMenuItem.Text = "Freeze";
            this.freezeToolStripMenuItem.Click += new System.EventHandler(this.freezeToolStripMenuItem_Click);
            // 
            // positionsTableBindingSource
            // 
            this.positionsTableBindingSource.DataMember = "PositionsTable";
            this.positionsTableBindingSource.DataSource = this.optionsSet;
            // 
            // optionsSet
            // 
            this.optionsSet.DataSetName = "OptionsSet";
            this.optionsSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // endDateTimePicker
            // 
            this.endDateTimePicker.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.endDateTimePicker.CalendarForeColor = System.Drawing.Color.Cornsilk;
            this.endDateTimePicker.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(0)))));
            this.endDateTimePicker.CalendarTitleBackColor = System.Drawing.Color.DarkSeaGreen;
            this.endDateTimePicker.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.endDateTimePicker.CalendarTrailingForeColor = System.Drawing.Color.LightGreen;
            this.endDateTimePicker.CustomFormat = "d-MMM-yyyy";
            this.endDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.globalTableBindingSource, "EndDate", true));
            this.endDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.endDateTimePicker.Location = new System.Drawing.Point(388, 192);
            this.endDateTimePicker.Name = "endDateTimePicker";
            this.endDateTimePicker.Size = new System.Drawing.Size(79, 20);
            this.endDateTimePicker.TabIndex = 26;
            this.endDateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker_ValueChanged);
            this.endDateTimePicker.DropDown += new System.EventHandler(this.dateTimePicker_DropDown);
            // 
            // globalTableBindingSource
            // 
            this.globalTableBindingSource.DataMember = "GlobalTable";
            this.globalTableBindingSource.DataSource = this.optionsSet;
            // 
            // startDateTimePicker
            // 
            this.startDateTimePicker.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.startDateTimePicker.CalendarForeColor = System.Drawing.Color.Cornsilk;
            this.startDateTimePicker.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(0)))));
            this.startDateTimePicker.CalendarTitleBackColor = System.Drawing.Color.DarkSeaGreen;
            this.startDateTimePicker.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.startDateTimePicker.CalendarTrailingForeColor = System.Drawing.Color.LightGray;
            this.startDateTimePicker.CustomFormat = "d-MMM-yyyy";
            this.startDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.globalTableBindingSource, "StartDate", true));
            this.startDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.startDateTimePicker.Location = new System.Drawing.Point(388, 169);
            this.startDateTimePicker.Name = "startDateTimePicker";
            this.startDateTimePicker.Size = new System.Drawing.Size(79, 20);
            this.startDateTimePicker.TabIndex = 25;
            this.startDateTimePicker.ValueChanged += new System.EventHandler(this.dateTimePicker_ValueChanged);
            this.startDateTimePicker.DropDown += new System.EventHandler(this.dateTimePicker_DropDown);
            // 
            // notesTextBox
            // 
            this.notesTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.notesTextBox.BackColor = System.Drawing.Color.Black;
            this.notesTextBox.ForeColor = System.Drawing.Color.Cornsilk;
            this.notesTextBox.Location = new System.Drawing.Point(511, 168);
            this.notesTextBox.Multiline = true;
            this.notesTextBox.Name = "notesTextBox";
            this.notesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.notesTextBox.Size = new System.Drawing.Size(485, 44);
            this.notesTextBox.TabIndex = 35;
            this.notesTextBox.TextChanged += new System.EventHandler(this.notesTextBox_TextChanged);
            // 
            // tourButton
            // 
            this.tourButton.Image = global::OptionsOracle.Properties.Resources.tour;
            this.tourButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.tourButton.Location = new System.Drawing.Point(12, 69);
            this.tourButton.Name = "tourButton";
            this.tourButton.Size = new System.Drawing.Size(88, 37);
            this.tourButton.TabIndex = 38;
            this.tourButton.Text = "           Start                 Tutorial";
            this.tourButton.UseVisualStyleBackColor = true;
            this.tourButton.Click += new System.EventHandler(this.tourButton_Click);
            // 
            // resultGroupBox
            // 
            this.resultGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.resultGroupBox.Controls.Add(this.resultsDataGridView);
            this.resultGroupBox.Location = new System.Drawing.Point(290, 2);
            this.resultGroupBox.Name = "resultGroupBox";
            this.resultGroupBox.Size = new System.Drawing.Size(717, 262);
            this.resultGroupBox.TabIndex = 0;
            this.resultGroupBox.TabStop = false;
            this.resultGroupBox.Text = "Strategy Summary";
            // 
            // resultsDataGridView
            // 
            this.resultsDataGridView.AllowUserToAddRows = false;
            this.resultsDataGridView.AllowUserToDeleteRows = false;
            this.resultsDataGridView.AllowUserToOrderColumns = true;
            this.resultsDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.resultsDataGridView.AutoGenerateColumns = false;
            this.resultsDataGridView.ColumnHeadersHeight = 22;
            this.resultsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.resultsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.resultsIndexColumn,
            this.resultsIsCreditColumn,
            this.resultsCriteriaColumn,
            this.resultsPriceColumn,
            this.resultsChangeColumn,
            this.resultsProbColumn,
            this.resultsTotalColumn,
            this.resultsTotalPrcColumn,
            this.resultsMonthlyPrcColumn});
            this.resultsDataGridView.DataSource = this.resultsTableBindingSource;
            this.resultsDataGridView.Location = new System.Drawing.Point(9, 17);
            this.resultsDataGridView.Name = "resultsDataGridView";
            this.resultsDataGridView.RowHeadersVisible = false;
            this.resultsDataGridView.RowHeadersWidth = 16;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(0)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Cornsilk;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(0)))), ((int)(((byte)(48)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.Cornsilk;
            this.resultsDataGridView.RowsDefaultCellStyle = dataGridViewCellStyle24;
            this.resultsDataGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resultsDataGridView.RowTemplate.Height = 20;
            this.resultsDataGridView.Size = new System.Drawing.Size(697, 237);
            this.resultsDataGridView.TabIndex = 40;
            this.resultsDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.resultsDataGridView_CellFormatting);
            this.resultsDataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.resultsDataGridView_CellValueChanged);
            // 
            // resultsIndexColumn
            // 
            this.resultsIndexColumn.DataPropertyName = "Index";
            this.resultsIndexColumn.HeaderText = "Index";
            this.resultsIndexColumn.Name = "resultsIndexColumn";
            this.resultsIndexColumn.Visible = false;
            // 
            // resultsIsCreditColumn
            // 
            this.resultsIsCreditColumn.DataPropertyName = "IsCredit";
            this.resultsIsCreditColumn.HeaderText = "IsCredit";
            this.resultsIsCreditColumn.Name = "resultsIsCreditColumn";
            this.resultsIsCreditColumn.Visible = false;
            // 
            // resultsCriteriaColumn
            // 
            this.resultsCriteriaColumn.DataPropertyName = "Criteria";
            this.resultsCriteriaColumn.HeaderText = "Criteria";
            this.resultsCriteriaColumn.Name = "resultsCriteriaColumn";
            this.resultsCriteriaColumn.ReadOnly = true;
            this.resultsCriteriaColumn.ToolTipText = "Criteria";
            this.resultsCriteriaColumn.Width = 160;
            // 
            // resultsPriceColumn
            // 
            this.resultsPriceColumn.DataPropertyName = "Price";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle18.Format = "N2";
            this.resultsPriceColumn.DefaultCellStyle = dataGridViewCellStyle18;
            this.resultsPriceColumn.HeaderText = "Price";
            this.resultsPriceColumn.Name = "resultsPriceColumn";
            this.resultsPriceColumn.ReadOnly = true;
            this.resultsPriceColumn.ToolTipText = "Stock Price";
            this.resultsPriceColumn.Width = 58;
            // 
            // resultsChangeColumn
            // 
            this.resultsChangeColumn.DataPropertyName = "Change";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle19.Format = "P2";
            this.resultsChangeColumn.DefaultCellStyle = dataGridViewCellStyle19;
            this.resultsChangeColumn.HeaderText = "Change";
            this.resultsChangeColumn.Name = "resultsChangeColumn";
            this.resultsChangeColumn.ReadOnly = true;
            this.resultsChangeColumn.ToolTipText = "Stock Price Change %";
            this.resultsChangeColumn.Width = 58;
            // 
            // resultsProbColumn
            // 
            this.resultsProbColumn.DataPropertyName = "Prob";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle20.Format = "P2";
            this.resultsProbColumn.DefaultCellStyle = dataGridViewCellStyle20;
            this.resultsProbColumn.HeaderText = "Prob";
            this.resultsProbColumn.Name = "resultsProbColumn";
            this.resultsProbColumn.ReadOnly = true;
            this.resultsProbColumn.ToolTipText = "Stock Movement Probability";
            this.resultsProbColumn.Width = 58;
            // 
            // resultsTotalColumn
            // 
            this.resultsTotalColumn.DataPropertyName = "Total";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle21.Format = "N2";
            dataGridViewCellStyle21.NullValue = "N/A";
            this.resultsTotalColumn.DefaultCellStyle = dataGridViewCellStyle21;
            this.resultsTotalColumn.HeaderText = "Total";
            this.resultsTotalColumn.Name = "resultsTotalColumn";
            this.resultsTotalColumn.ReadOnly = true;
            this.resultsTotalColumn.ToolTipText = "Total Cash";
            this.resultsTotalColumn.Width = 66;
            // 
            // resultsTotalPrcColumn
            // 
            this.resultsTotalPrcColumn.DataPropertyName = "TotalPrc";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle22.Format = "P2";
            this.resultsTotalPrcColumn.DefaultCellStyle = dataGridViewCellStyle22;
            this.resultsTotalPrcColumn.HeaderText = "Total %";
            this.resultsTotalPrcColumn.Name = "resultsTotalPrcColumn";
            this.resultsTotalPrcColumn.ReadOnly = true;
            this.resultsTotalPrcColumn.ToolTipText = "Total %";
            this.resultsTotalPrcColumn.Width = 66;
            // 
            // resultsMonthlyPrcColumn
            // 
            this.resultsMonthlyPrcColumn.DataPropertyName = "MonthlyPrc";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle23.Format = "P2";
            this.resultsMonthlyPrcColumn.DefaultCellStyle = dataGridViewCellStyle23;
            this.resultsMonthlyPrcColumn.HeaderText = "Total 1Mo %";
            this.resultsMonthlyPrcColumn.Name = "resultsMonthlyPrcColumn";
            this.resultsMonthlyPrcColumn.ReadOnly = true;
            this.resultsMonthlyPrcColumn.ToolTipText = "Total % Per 1-Month";
            this.resultsMonthlyPrcColumn.Width = 70;
            // 
            // resultsTableBindingSource
            // 
            this.resultsTableBindingSource.DataMember = "ResultsTable";
            this.resultsTableBindingSource.DataSource = this.optionsSet;
            // 
            // graphButton
            // 
            this.graphButton.Enabled = false;
            this.graphButton.Image = global::OptionsOracle.Properties.Resources.graph;
            this.graphButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.graphButton.Location = new System.Drawing.Point(190, 69);
            this.graphButton.Name = "graphButton";
            this.graphButton.Size = new System.Drawing.Size(88, 37);
            this.graphButton.TabIndex = 29;
            this.graphButton.Text = "         Graph";
            this.graphButton.UseVisualStyleBackColor = true;
            this.graphButton.Click += new System.EventHandler(this.graphButton_Click);
            // 
            // controlGroupBox
            // 
            this.controlGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.controlGroupBox.Controls.Add(this.aboutButton);
            this.controlGroupBox.Controls.Add(this.optionPainButton);
            this.controlGroupBox.Controls.Add(this.analysisButton);
            this.controlGroupBox.Controls.Add(this.exitButton);
            this.controlGroupBox.Controls.Add(this.printButton);
            this.controlGroupBox.Controls.Add(this.volatilitySmileButton);
            this.controlGroupBox.Controls.Add(this.portfolioButton);
            this.controlGroupBox.Controls.Add(this.putCallRatioButton);
            this.controlGroupBox.Controls.Add(this.volatilityCalcButton);
            this.controlGroupBox.Controls.Add(this.wizardButton);
            this.controlGroupBox.Controls.Add(this.calculatorButton);
            this.controlGroupBox.Controls.Add(this.newButton);
            this.controlGroupBox.Controls.Add(this.contactUsButton);
            this.controlGroupBox.Controls.Add(this.loadButton);
            this.controlGroupBox.Controls.Add(this.saveButton);
            this.controlGroupBox.Controls.Add(this.tourButton);
            this.controlGroupBox.Controls.Add(this.graphButton);
            this.controlGroupBox.Controls.Add(this.configurationButton);
            this.controlGroupBox.Controls.Add(this.titlePanelWebBrowser);
            this.controlGroupBox.Location = new System.Drawing.Point(0, 2);
            this.controlGroupBox.Name = "controlGroupBox";
            this.controlGroupBox.Size = new System.Drawing.Size(284, 262);
            this.controlGroupBox.TabIndex = 0;
            this.controlGroupBox.TabStop = false;
            // 
            // aboutButton
            // 
            this.aboutButton.Location = new System.Drawing.Point(101, 195);
            this.aboutButton.Name = "aboutButton";
            this.aboutButton.Size = new System.Drawing.Size(88, 24);
            this.aboutButton.TabIndex = 45;
            this.aboutButton.Text = "About";
            this.aboutButton.UseVisualStyleBackColor = true;
            this.aboutButton.Click += new System.EventHandler(this.aboutButton_Click);
            // 
            // optionPainButton
            // 
            this.optionPainButton.Enabled = false;
            this.optionPainButton.Location = new System.Drawing.Point(101, 220);
            this.optionPainButton.Name = "optionPainButton";
            this.optionPainButton.Size = new System.Drawing.Size(88, 24);
            this.optionPainButton.TabIndex = 44;
            this.optionPainButton.Text = "Option Pain";
            this.optionPainButton.UseVisualStyleBackColor = true;
            this.optionPainButton.Click += new System.EventHandler(this.optionPainButton_Click);
            // 
            // analysisButton
            // 
            this.analysisButton.Enabled = false;
            this.analysisButton.Location = new System.Drawing.Point(101, 170);
            this.analysisButton.Name = "analysisButton";
            this.analysisButton.Size = new System.Drawing.Size(88, 24);
            this.analysisButton.TabIndex = 43;
            this.analysisButton.Text = "Analysis";
            this.analysisButton.UseVisualStyleBackColor = true;
            this.analysisButton.Click += new System.EventHandler(this.analysisButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.exitButton.Location = new System.Drawing.Point(190, 220);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(88, 24);
            this.exitButton.TabIndex = 42;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // printButton
            // 
            this.printButton.Enabled = false;
            this.printButton.Location = new System.Drawing.Point(101, 145);
            this.printButton.Name = "printButton";
            this.printButton.Size = new System.Drawing.Size(88, 24);
            this.printButton.TabIndex = 41;
            this.printButton.Text = "Print";
            this.printButton.UseVisualStyleBackColor = true;
            this.printButton.Click += new System.EventHandler(this.printButton_Click);
            // 
            // volatilitySmileButton
            // 
            this.volatilitySmileButton.Enabled = false;
            this.volatilitySmileButton.Location = new System.Drawing.Point(12, 195);
            this.volatilitySmileButton.Name = "volatilitySmileButton";
            this.volatilitySmileButton.Size = new System.Drawing.Size(88, 24);
            this.volatilitySmileButton.TabIndex = 40;
            this.volatilitySmileButton.Text = "Volatility Smile";
            this.volatilitySmileButton.UseVisualStyleBackColor = true;
            this.volatilitySmileButton.Click += new System.EventHandler(this.volatilitySmileButton_Click);
            // 
            // portfolioButton
            // 
            this.portfolioButton.Image = global::OptionsOracle.Properties.Resources.portfolio;
            this.portfolioButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.portfolioButton.Location = new System.Drawing.Point(101, 107);
            this.portfolioButton.Name = "portfolioButton";
            this.portfolioButton.Size = new System.Drawing.Size(88, 37);
            this.portfolioButton.TabIndex = 39;
            this.portfolioButton.Text = "          Portfolio         Mgmt";
            this.portfolioButton.UseVisualStyleBackColor = true;
            this.portfolioButton.Click += new System.EventHandler(this.portfolioButton_Click);
            // 
            // putCallRatioButton
            // 
            this.putCallRatioButton.Enabled = false;
            this.putCallRatioButton.Location = new System.Drawing.Point(12, 220);
            this.putCallRatioButton.Name = "putCallRatioButton";
            this.putCallRatioButton.Size = new System.Drawing.Size(88, 24);
            this.putCallRatioButton.TabIndex = 31;
            this.putCallRatioButton.Text = "Put/Call Ratio";
            this.putCallRatioButton.UseVisualStyleBackColor = true;
            this.putCallRatioButton.Click += new System.EventHandler(this.putCallRatioButton_Click);
            // 
            // volatilityCalcButton
            // 
            this.volatilityCalcButton.Enabled = false;
            this.volatilityCalcButton.Location = new System.Drawing.Point(12, 170);
            this.volatilityCalcButton.Name = "volatilityCalcButton";
            this.volatilityCalcButton.Size = new System.Drawing.Size(88, 24);
            this.volatilityCalcButton.TabIndex = 31;
            this.volatilityCalcButton.Text = "Volatility Cone";
            this.volatilityCalcButton.UseVisualStyleBackColor = true;
            this.volatilityCalcButton.Click += new System.EventHandler(this.volatilityCalcButton_Click);
            // 
            // wizardButton
            // 
            this.wizardButton.Image = global::OptionsOracle.Properties.Resources.wizard;
            this.wizardButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.wizardButton.Location = new System.Drawing.Point(190, 107);
            this.wizardButton.Name = "wizardButton";
            this.wizardButton.Size = new System.Drawing.Size(88, 37);
            this.wizardButton.TabIndex = 30;
            this.wizardButton.Text = "         Wizard";
            this.wizardButton.UseVisualStyleBackColor = true;
            this.wizardButton.Click += new System.EventHandler(this.wizardButton_Click);
            // 
            // calculatorButton
            // 
            this.calculatorButton.Location = new System.Drawing.Point(12, 145);
            this.calculatorButton.Name = "calculatorButton";
            this.calculatorButton.Size = new System.Drawing.Size(88, 24);
            this.calculatorButton.TabIndex = 32;
            this.calculatorButton.Text = "Greeks Calc";
            this.calculatorButton.UseVisualStyleBackColor = true;
            this.calculatorButton.Click += new System.EventHandler(this.calculatorButton_Click);
            // 
            // newButton
            // 
            this.newButton.Location = new System.Drawing.Point(190, 145);
            this.newButton.Name = "newButton";
            this.newButton.Size = new System.Drawing.Size(88, 24);
            this.newButton.TabIndex = 36;
            this.newButton.Text = "New";
            this.newButton.UseVisualStyleBackColor = true;
            this.newButton.Click += new System.EventHandler(this.newButton_Click);
            // 
            // contactUsButton
            // 
            this.contactUsButton.Image = global::OptionsOracle.Properties.Resources.contactus;
            this.contactUsButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.contactUsButton.Location = new System.Drawing.Point(12, 107);
            this.contactUsButton.Name = "contactUsButton";
            this.contactUsButton.Size = new System.Drawing.Size(88, 37);
            this.contactUsButton.TabIndex = 37;
            this.contactUsButton.Text = "           Contact    Us";
            this.contactUsButton.UseVisualStyleBackColor = true;
            this.contactUsButton.Click += new System.EventHandler(this.contactUsButton_Click);
            // 
            // loadButton
            // 
            this.loadButton.Location = new System.Drawing.Point(190, 170);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(88, 24);
            this.loadButton.TabIndex = 35;
            this.loadButton.Text = "Load";
            this.loadButton.UseVisualStyleBackColor = true;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(190, 195);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(88, 24);
            this.saveButton.TabIndex = 34;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // configurationButton
            // 
            this.configurationButton.Image = global::OptionsOracle.Properties.Resources.config;
            this.configurationButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.configurationButton.Location = new System.Drawing.Point(101, 69);
            this.configurationButton.Name = "configurationButton";
            this.configurationButton.Size = new System.Drawing.Size(88, 37);
            this.configurationButton.TabIndex = 33;
            this.configurationButton.Text = "         Config";
            this.configurationButton.UseVisualStyleBackColor = true;
            this.configurationButton.Click += new System.EventHandler(this.configurationButton_Click);
            // 
            // titlePanelWebBrowser
            // 
            this.titlePanelWebBrowser.AllowWebBrowserDrop = false;
            this.titlePanelWebBrowser.Location = new System.Drawing.Point(13, 19);
            this.titlePanelWebBrowser.MinimumSize = new System.Drawing.Size(20, 19);
            this.titlePanelWebBrowser.Name = "titlePanelWebBrowser";
            this.titlePanelWebBrowser.ScriptErrorsSuppressed = true;
            this.titlePanelWebBrowser.ScrollBarsEnabled = false;
            this.titlePanelWebBrowser.Size = new System.Drawing.Size(265, 35);
            this.titlePanelWebBrowser.TabIndex = 0;
            this.titlePanelWebBrowser.TabStop = false;
            this.titlePanelWebBrowser.Url = new System.Uri("", System.UriKind.Relative);
            this.titlePanelWebBrowser.Visible = false;
            this.titlePanelWebBrowser.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser_DocumentCompleted);
            this.titlePanelWebBrowser.Navigating += new System.Windows.Forms.WebBrowserNavigatingEventHandler(this.webBrowser_Navigating);
            // 
            // autoRefreshTimer
            // 
            this.autoRefreshTimer.Interval = 1000;
            this.autoRefreshTimer.Tick += new System.EventHandler(this.autoRefreshTimer_Tick);
            // 
            // autoRefreshCheckBox
            // 
            this.autoRefreshCheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.autoRefreshCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.autoRefreshCheckBox.Enabled = false;
            this.autoRefreshCheckBox.Location = new System.Drawing.Point(9, 50);
            this.autoRefreshCheckBox.Name = "autoRefreshCheckBox";
            this.autoRefreshCheckBox.Size = new System.Drawing.Size(67, 24);
            this.autoRefreshCheckBox.TabIndex = 16;
            this.autoRefreshCheckBox.Text = "No Auto";
            this.autoRefreshCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip.SetToolTip(this.autoRefreshCheckBox, "Enable/Disable Periodic Refresh");
            this.autoRefreshCheckBox.UseVisualStyleBackColor = true;
            this.autoRefreshCheckBox.CheckedChanged += new System.EventHandler(this.autoRefreshCheckBox_CheckedChanged);
            // 
            // itmCheckBox
            // 
            this.itmCheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.itmCheckBox.Checked = true;
            this.itmCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itmCheckBox.Location = new System.Drawing.Point(2, 9);
            this.itmCheckBox.Name = "itmCheckBox";
            this.itmCheckBox.Size = new System.Drawing.Size(45, 22);
            this.itmCheckBox.TabIndex = 6;
            this.itmCheckBox.Tag = "(TheMoney LIKE \'*ITM*\')";
            this.itmCheckBox.Text = "ITM";
            this.itmCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip.SetToolTip(this.itmCheckBox, "In-The-Money");
            this.itmCheckBox.UseVisualStyleBackColor = true;
            this.itmCheckBox.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // atmCheckBox
            // 
            this.atmCheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.atmCheckBox.Checked = true;
            this.atmCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.atmCheckBox.Location = new System.Drawing.Point(46, 9);
            this.atmCheckBox.Name = "atmCheckBox";
            this.atmCheckBox.Size = new System.Drawing.Size(45, 22);
            this.atmCheckBox.TabIndex = 7;
            this.atmCheckBox.Tag = "(TheMoney LIKE \'*ATM*\')";
            this.atmCheckBox.Text = "ATM";
            this.atmCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip.SetToolTip(this.atmCheckBox, "At-The-Money");
            this.atmCheckBox.UseVisualStyleBackColor = true;
            this.atmCheckBox.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // otmCheckBox
            // 
            this.otmCheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.otmCheckBox.Checked = true;
            this.otmCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.otmCheckBox.Location = new System.Drawing.Point(90, 9);
            this.otmCheckBox.Name = "otmCheckBox";
            this.otmCheckBox.Size = new System.Drawing.Size(45, 22);
            this.otmCheckBox.TabIndex = 8;
            this.otmCheckBox.Tag = "(TheMoney LIKE \'*OTM*\')";
            this.otmCheckBox.Text = "OTM";
            this.otmCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip.SetToolTip(this.otmCheckBox, "Out-of-The-Money");
            this.otmCheckBox.UseVisualStyleBackColor = true;
            this.otmCheckBox.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // grkCheckBox
            // 
            this.grkCheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.grkCheckBox.Location = new System.Drawing.Point(3, 9);
            this.grkCheckBox.Name = "grkCheckBox";
            this.grkCheckBox.Size = new System.Drawing.Size(45, 22);
            this.grkCheckBox.TabIndex = 9;
            this.grkCheckBox.Tag = "";
            this.grkCheckBox.Text = "GRK";
            this.grkCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.toolTip.SetToolTip(this.grkCheckBox, "Show Options Specific Greeks");
            this.grkCheckBox.UseVisualStyleBackColor = true;
            this.grkCheckBox.CheckedChanged += new System.EventHandler(this.grkCheckBox_CheckedChanged);
            // 
            // graphWorker
            // 
            this.graphWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.graphWorker_DoWork);
            this.graphWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.graphWorker_RunWorkerCompleted);
            // 
            // optionsDataGridView
            // 
            this.optionsDataGridView.AllowUserToAddRows = false;
            this.optionsDataGridView.AllowUserToDeleteRows = false;
            this.optionsDataGridView.AllowUserToOrderColumns = true;
            this.optionsDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.optionsDataGridView.AutoGenerateColumns = false;
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.optionsDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle25;
            this.optionsDataGridView.ColumnHeadersHeight = 22;
            this.optionsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.optionsTypeColumn,
            this.optionsStrikeColumn,
            this.optionsExpirationColumn,
            this.optionsSymbolColumn,
            this.optionsLastColumn,
            this.optionsChangeColumn,
            this.optionsTimeValueColumn,
            this.optionsBidColumn,
            this.optionsAskColumn,
            this.optionsVolumeColumn,
            this.optionsOpenIntColumn,
            this.optionsImpliedVolatilityColumn,
            this.optionsITMProbColumn,
            this.optionsDeltaColumn,
            this.optionsGammaColumn,
            this.optionsVegaColumn,
            this.optionsThetaColumn,
            this.optionsStockColumn,
            this.optionsUpdateTimeStampColumn,
            this.optionsStdDevColumn,
            this.optionsIndicator1Column,
            this.optionsIndicator2Column});
            this.optionsDataGridView.DataSource = this.optionsTableBindingSource;
            this.optionsDataGridView.Location = new System.Drawing.Point(174, 51);
            this.optionsDataGridView.Name = "optionsDataGridView";
            this.optionsDataGridView.ReadOnly = true;
            this.optionsDataGridView.RowHeadersVisible = false;
            this.optionsDataGridView.RowHeadersWidth = 16;
            this.optionsDataGridView.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Black;
            this.optionsDataGridView.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionsDataGridView.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Cornsilk;
            this.optionsDataGridView.RowTemplate.Height = 20;
            this.optionsDataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.optionsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.optionsDataGridView.Size = new System.Drawing.Size(822, 143);
            this.optionsDataGridView.TabIndex = 3;
            this.optionsDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.optionsDataGridView_CellFormatting);
            this.optionsDataGridView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.optionsDataGridView_MouseDown);
            // 
            // optionsTypeColumn
            // 
            this.optionsTypeColumn.DataPropertyName = "Type";
            this.optionsTypeColumn.Frozen = true;
            this.optionsTypeColumn.HeaderText = "Type";
            this.optionsTypeColumn.Name = "optionsTypeColumn";
            this.optionsTypeColumn.ReadOnly = true;
            this.optionsTypeColumn.Width = 45;
            // 
            // optionsStrikeColumn
            // 
            this.optionsStrikeColumn.DataPropertyName = "Strike";
            dataGridViewCellStyle26.Format = "N2";
            this.optionsStrikeColumn.DefaultCellStyle = dataGridViewCellStyle26;
            this.optionsStrikeColumn.Frozen = true;
            this.optionsStrikeColumn.HeaderText = "Strike";
            this.optionsStrikeColumn.Name = "optionsStrikeColumn";
            this.optionsStrikeColumn.ReadOnly = true;
            this.optionsStrikeColumn.Width = 60;
            // 
            // optionsExpirationColumn
            // 
            this.optionsExpirationColumn.DataPropertyName = "Expiration";
            dataGridViewCellStyle27.Format = "dd-MMM-yyyy";
            this.optionsExpirationColumn.DefaultCellStyle = dataGridViewCellStyle27;
            this.optionsExpirationColumn.Frozen = true;
            this.optionsExpirationColumn.HeaderText = "Expiration";
            this.optionsExpirationColumn.Name = "optionsExpirationColumn";
            this.optionsExpirationColumn.ReadOnly = true;
            this.optionsExpirationColumn.Width = 75;
            // 
            // optionsSymbolColumn
            // 
            this.optionsSymbolColumn.DataPropertyName = "Symbol";
            this.optionsSymbolColumn.HeaderText = "Symbol";
            this.optionsSymbolColumn.Name = "optionsSymbolColumn";
            this.optionsSymbolColumn.ReadOnly = true;
            this.optionsSymbolColumn.Width = 60;
            // 
            // optionsLastColumn
            // 
            this.optionsLastColumn.DataPropertyName = "Last";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle28.Format = "N2";
            dataGridViewCellStyle28.NullValue = "N/A";
            this.optionsLastColumn.DefaultCellStyle = dataGridViewCellStyle28;
            this.optionsLastColumn.HeaderText = "Last";
            this.optionsLastColumn.Name = "optionsLastColumn";
            this.optionsLastColumn.ReadOnly = true;
            this.optionsLastColumn.Width = 60;
            // 
            // optionsChangeColumn
            // 
            this.optionsChangeColumn.DataPropertyName = "Change";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle29.Format = "N2";
            dataGridViewCellStyle29.NullValue = "N/A";
            this.optionsChangeColumn.DefaultCellStyle = dataGridViewCellStyle29;
            this.optionsChangeColumn.HeaderText = "Change";
            this.optionsChangeColumn.Name = "optionsChangeColumn";
            this.optionsChangeColumn.ReadOnly = true;
            this.optionsChangeColumn.Width = 60;
            // 
            // optionsTimeValueColumn
            // 
            this.optionsTimeValueColumn.DataPropertyName = "TimeValue";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle30.Format = "N2";
            dataGridViewCellStyle30.NullValue = "N/A";
            this.optionsTimeValueColumn.DefaultCellStyle = dataGridViewCellStyle30;
            this.optionsTimeValueColumn.HeaderText = "TimeValue";
            this.optionsTimeValueColumn.Name = "optionsTimeValueColumn";
            this.optionsTimeValueColumn.ReadOnly = true;
            this.optionsTimeValueColumn.Width = 61;
            // 
            // optionsBidColumn
            // 
            this.optionsBidColumn.DataPropertyName = "Bid";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle31.Format = "N2";
            dataGridViewCellStyle31.NullValue = "N/A";
            this.optionsBidColumn.DefaultCellStyle = dataGridViewCellStyle31;
            this.optionsBidColumn.HeaderText = "Bid";
            this.optionsBidColumn.Name = "optionsBidColumn";
            this.optionsBidColumn.ReadOnly = true;
            this.optionsBidColumn.Width = 60;
            // 
            // optionsAskColumn
            // 
            this.optionsAskColumn.DataPropertyName = "Ask";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle32.Format = "N2";
            dataGridViewCellStyle32.NullValue = "N/A";
            this.optionsAskColumn.DefaultCellStyle = dataGridViewCellStyle32;
            this.optionsAskColumn.HeaderText = "Ask";
            this.optionsAskColumn.Name = "optionsAskColumn";
            this.optionsAskColumn.ReadOnly = true;
            this.optionsAskColumn.Width = 60;
            // 
            // optionsVolumeColumn
            // 
            this.optionsVolumeColumn.DataPropertyName = "Volume";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle33.Format = "N0";
            this.optionsVolumeColumn.DefaultCellStyle = dataGridViewCellStyle33;
            this.optionsVolumeColumn.HeaderText = "Volume";
            this.optionsVolumeColumn.Name = "optionsVolumeColumn";
            this.optionsVolumeColumn.ReadOnly = true;
            this.optionsVolumeColumn.Width = 60;
            // 
            // optionsOpenIntColumn
            // 
            this.optionsOpenIntColumn.DataPropertyName = "OpenInt";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle34.Format = "N0";
            this.optionsOpenIntColumn.DefaultCellStyle = dataGridViewCellStyle34;
            this.optionsOpenIntColumn.HeaderText = "Open Int";
            this.optionsOpenIntColumn.Name = "optionsOpenIntColumn";
            this.optionsOpenIntColumn.ReadOnly = true;
            this.optionsOpenIntColumn.Width = 60;
            // 
            // optionsImpliedVolatilityColumn
            // 
            this.optionsImpliedVolatilityColumn.DataPropertyName = "ImpliedVolatility";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle35.Format = "N2";
            this.optionsImpliedVolatilityColumn.DefaultCellStyle = dataGridViewCellStyle35;
            this.optionsImpliedVolatilityColumn.HeaderText = "ImpV";
            this.optionsImpliedVolatilityColumn.Name = "optionsImpliedVolatilityColumn";
            this.optionsImpliedVolatilityColumn.ReadOnly = true;
            this.optionsImpliedVolatilityColumn.Visible = false;
            this.optionsImpliedVolatilityColumn.Width = 60;
            // 
            // optionsITMProbColumn
            // 
            this.optionsITMProbColumn.DataPropertyName = "ITMProb";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle36.Format = "N2";
            this.optionsITMProbColumn.DefaultCellStyle = dataGridViewCellStyle36;
            this.optionsITMProbColumn.HeaderText = "ITM Prob";
            this.optionsITMProbColumn.Name = "optionsITMProbColumn";
            this.optionsITMProbColumn.ReadOnly = true;
            this.optionsITMProbColumn.Visible = false;
            this.optionsITMProbColumn.Width = 60;
            // 
            // optionsDeltaColumn
            // 
            this.optionsDeltaColumn.DataPropertyName = "Delta";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle37.Format = "N3";
            this.optionsDeltaColumn.DefaultCellStyle = dataGridViewCellStyle37;
            this.optionsDeltaColumn.HeaderText = "Delta";
            this.optionsDeltaColumn.Name = "optionsDeltaColumn";
            this.optionsDeltaColumn.ReadOnly = true;
            this.optionsDeltaColumn.Visible = false;
            this.optionsDeltaColumn.Width = 60;
            // 
            // optionsGammaColumn
            // 
            this.optionsGammaColumn.DataPropertyName = "Gamma";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle38.Format = "N3";
            this.optionsGammaColumn.DefaultCellStyle = dataGridViewCellStyle38;
            this.optionsGammaColumn.HeaderText = "Gamma";
            this.optionsGammaColumn.Name = "optionsGammaColumn";
            this.optionsGammaColumn.ReadOnly = true;
            this.optionsGammaColumn.Visible = false;
            this.optionsGammaColumn.Width = 60;
            // 
            // optionsVegaColumn
            // 
            this.optionsVegaColumn.DataPropertyName = "Vega";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle39.Format = "N3";
            this.optionsVegaColumn.DefaultCellStyle = dataGridViewCellStyle39;
            this.optionsVegaColumn.HeaderText = "Vega";
            this.optionsVegaColumn.Name = "optionsVegaColumn";
            this.optionsVegaColumn.ReadOnly = true;
            this.optionsVegaColumn.Visible = false;
            this.optionsVegaColumn.Width = 60;
            // 
            // optionsThetaColumn
            // 
            this.optionsThetaColumn.DataPropertyName = "Theta";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle40.Format = "N3";
            this.optionsThetaColumn.DefaultCellStyle = dataGridViewCellStyle40;
            this.optionsThetaColumn.HeaderText = "Theta";
            this.optionsThetaColumn.Name = "optionsThetaColumn";
            this.optionsThetaColumn.ReadOnly = true;
            this.optionsThetaColumn.Visible = false;
            this.optionsThetaColumn.Width = 60;
            // 
            // optionsStockColumn
            // 
            this.optionsStockColumn.DataPropertyName = "Stock";
            this.optionsStockColumn.HeaderText = "Stock";
            this.optionsStockColumn.Name = "optionsStockColumn";
            this.optionsStockColumn.ReadOnly = true;
            this.optionsStockColumn.Visible = false;
            this.optionsStockColumn.Width = 60;
            // 
            // optionsUpdateTimeStampColumn
            // 
            this.optionsUpdateTimeStampColumn.DataPropertyName = "UpdateTimeStamp";
            dataGridViewCellStyle41.Format = "g";
            dataGridViewCellStyle41.NullValue = null;
            this.optionsUpdateTimeStampColumn.DefaultCellStyle = dataGridViewCellStyle41;
            this.optionsUpdateTimeStampColumn.HeaderText = "UpdateTimeStamp";
            this.optionsUpdateTimeStampColumn.Name = "optionsUpdateTimeStampColumn";
            this.optionsUpdateTimeStampColumn.ReadOnly = true;
            this.optionsUpdateTimeStampColumn.Visible = false;
            this.optionsUpdateTimeStampColumn.Width = 60;
            // 
            // optionsStdDevColumn
            // 
            this.optionsStdDevColumn.DataPropertyName = "StdDevFromStock";
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle42.Format = "N2";
            this.optionsStdDevColumn.DefaultCellStyle = dataGridViewCellStyle42;
            this.optionsStdDevColumn.HeaderText = "Strike SD";
            this.optionsStdDevColumn.Name = "optionsStdDevColumn";
            this.optionsStdDevColumn.ReadOnly = true;
            this.optionsStdDevColumn.Visible = false;
            this.optionsStdDevColumn.Width = 60;
            // 
            // optionsIndicator1Column
            // 
            this.optionsIndicator1Column.DataPropertyName = "Indicator1";
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle43.Format = "N3";
            this.optionsIndicator1Column.DefaultCellStyle = dataGridViewCellStyle43;
            this.optionsIndicator1Column.HeaderText = "Ind 1";
            this.optionsIndicator1Column.Name = "optionsIndicator1Column";
            this.optionsIndicator1Column.ReadOnly = true;
            this.optionsIndicator1Column.Visible = false;
            this.optionsIndicator1Column.Width = 60;
            // 
            // optionsIndicator2Column
            // 
            this.optionsIndicator2Column.DataPropertyName = "Indicator2";
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle44.Format = "N3";
            this.optionsIndicator2Column.DefaultCellStyle = dataGridViewCellStyle44;
            this.optionsIndicator2Column.HeaderText = "Ind 2";
            this.optionsIndicator2Column.Name = "optionsIndicator2Column";
            this.optionsIndicator2Column.ReadOnly = true;
            this.optionsIndicator2Column.Visible = false;
            this.optionsIndicator2Column.Width = 60;
            // 
            // optionsTableBindingSource
            // 
            this.optionsTableBindingSource.DataMember = "OptionsTable";
            this.optionsTableBindingSource.DataSource = this.optionsSet;
            // 
            // stockLabel
            // 
            this.stockLabel.AutoSize = true;
            this.stockLabel.Location = new System.Drawing.Point(8, 23);
            this.stockLabel.Name = "stockLabel";
            this.stockLabel.Size = new System.Drawing.Size(41, 13);
            this.stockLabel.TabIndex = 0;
            this.stockLabel.Text = "Symbol";
            this.stockLabel.Click += new System.EventHandler(this.stockLabel_Click);
            // 
            // lastPriceText
            // 
            this.lastPriceText.BackColor = System.Drawing.Color.Black;
            this.lastPriceText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastPriceText.ForeColor = System.Drawing.Color.Cornsilk;
            this.lastPriceText.Location = new System.Drawing.Point(75, 98);
            this.lastPriceText.Name = "lastPriceText";
            this.lastPriceText.Size = new System.Drawing.Size(94, 20);
            this.lastPriceText.TabIndex = 0;
            this.lastPriceText.TabStop = false;
            this.lastPriceText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.lastPriceText.Enter += new System.EventHandler(this.xxxText_Enter);
            this.lastPriceText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.xxxText_KeyUp);
            this.lastPriceText.Leave += new System.EventHandler(this.xxxText_Leave);
            // 
            // changeText
            // 
            this.changeText.BackColor = System.Drawing.Color.Black;
            this.changeText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeText.ForeColor = System.Drawing.Color.Cornsilk;
            this.changeText.Location = new System.Drawing.Point(75, 117);
            this.changeText.Name = "changeText";
            this.changeText.ReadOnly = true;
            this.changeText.Size = new System.Drawing.Size(94, 20);
            this.changeText.TabIndex = 0;
            this.changeText.TabStop = false;
            this.changeText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // bidText
            // 
            this.bidText.BackColor = System.Drawing.Color.Black;
            this.bidText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bidText.ForeColor = System.Drawing.Color.Cornsilk;
            this.bidText.Location = new System.Drawing.Point(75, 136);
            this.bidText.Name = "bidText";
            this.bidText.ReadOnly = true;
            this.bidText.Size = new System.Drawing.Size(48, 20);
            this.bidText.TabIndex = 0;
            this.bidText.TabStop = false;
            this.bidText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // dividendText
            // 
            this.dividendText.BackColor = System.Drawing.Color.Black;
            this.dividendText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dividendText.ForeColor = System.Drawing.Color.Cornsilk;
            this.dividendText.Location = new System.Drawing.Point(75, 155);
            this.dividendText.Name = "dividendText";
            this.dividendText.Size = new System.Drawing.Size(94, 20);
            this.dividendText.TabIndex = 0;
            this.dividendText.TabStop = false;
            this.dividendText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.dividendText.Enter += new System.EventHandler(this.xxxText_Enter);
            this.dividendText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.xxxText_KeyUp);
            this.dividendText.Leave += new System.EventHandler(this.xxxText_Leave);
            // 
            // lastPriceLabel
            // 
            this.lastPriceLabel.AutoSize = true;
            this.lastPriceLabel.Location = new System.Drawing.Point(8, 101);
            this.lastPriceLabel.Name = "lastPriceLabel";
            this.lastPriceLabel.Size = new System.Drawing.Size(54, 13);
            this.lastPriceLabel.TabIndex = 0;
            this.lastPriceLabel.Text = "Last Price";
            // 
            // changeLabel
            // 
            this.changeLabel.AutoSize = true;
            this.changeLabel.Location = new System.Drawing.Point(8, 120);
            this.changeLabel.Name = "changeLabel";
            this.changeLabel.Size = new System.Drawing.Size(44, 13);
            this.changeLabel.TabIndex = 0;
            this.changeLabel.Text = "Change";
            // 
            // bidAskLabel
            // 
            this.bidAskLabel.AutoSize = true;
            this.bidAskLabel.Location = new System.Drawing.Point(8, 139);
            this.bidAskLabel.Name = "bidAskLabel";
            this.bidAskLabel.Size = new System.Drawing.Size(51, 13);
            this.bidAskLabel.TabIndex = 0;
            this.bidAskLabel.Text = "Bid / Ask";
            // 
            // lastUpdateText
            // 
            this.lastUpdateText.BackColor = System.Drawing.Color.Black;
            this.lastUpdateText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastUpdateText.ForeColor = System.Drawing.Color.Cornsilk;
            this.lastUpdateText.Location = new System.Drawing.Point(75, 77);
            this.lastUpdateText.Name = "lastUpdateText";
            this.lastUpdateText.ReadOnly = true;
            this.lastUpdateText.Size = new System.Drawing.Size(94, 20);
            this.lastUpdateText.TabIndex = 0;
            this.lastUpdateText.TabStop = false;
            this.lastUpdateText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dividendLabel
            // 
            this.dividendLabel.AutoSize = true;
            this.dividendLabel.Location = new System.Drawing.Point(8, 158);
            this.dividendLabel.Name = "dividendLabel";
            this.dividendLabel.Size = new System.Drawing.Size(60, 13);
            this.dividendLabel.TabIndex = 0;
            this.dividendLabel.Text = "Dividend %";
            // 
            // lastUpdateLabel
            // 
            this.lastUpdateLabel.AutoSize = true;
            this.lastUpdateLabel.Location = new System.Drawing.Point(8, 82);
            this.lastUpdateLabel.Name = "lastUpdateLabel";
            this.lastUpdateLabel.Size = new System.Drawing.Size(65, 13);
            this.lastUpdateLabel.TabIndex = 0;
            this.lastUpdateLabel.Text = "Last Update";
            // 
            // optionSelectionGroupBox1
            // 
            this.optionSelectionGroupBox1.Controls.Add(this.putsCheckBox);
            this.optionSelectionGroupBox1.Controls.Add(this.callsCheckBox);
            this.optionSelectionGroupBox1.Enabled = false;
            this.optionSelectionGroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.optionSelectionGroupBox1.Location = new System.Drawing.Point(174, 10);
            this.optionSelectionGroupBox1.Name = "optionSelectionGroupBox1";
            this.optionSelectionGroupBox1.Size = new System.Drawing.Size(93, 34);
            this.optionSelectionGroupBox1.TabIndex = 0;
            this.optionSelectionGroupBox1.TabStop = false;
            // 
            // putsCheckBox
            // 
            this.putsCheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.putsCheckBox.Checked = true;
            this.putsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.putsCheckBox.Location = new System.Drawing.Point(46, 9);
            this.putsCheckBox.Name = "putsCheckBox";
            this.putsCheckBox.Size = new System.Drawing.Size(45, 22);
            this.putsCheckBox.TabIndex = 5;
            this.putsCheckBox.Tag = "(Type = \'Put\')";
            this.putsCheckBox.Text = "Puts";
            this.putsCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.putsCheckBox.UseVisualStyleBackColor = true;
            this.putsCheckBox.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // callsCheckBox
            // 
            this.callsCheckBox.Appearance = System.Windows.Forms.Appearance.Button;
            this.callsCheckBox.Checked = true;
            this.callsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.callsCheckBox.Location = new System.Drawing.Point(2, 9);
            this.callsCheckBox.Name = "callsCheckBox";
            this.callsCheckBox.Size = new System.Drawing.Size(45, 22);
            this.callsCheckBox.TabIndex = 4;
            this.callsCheckBox.Tag = "(Type = \'Call\')";
            this.callsCheckBox.Text = "Calls";
            this.callsCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.callsCheckBox.UseVisualStyleBackColor = true;
            this.callsCheckBox.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // optionSelectionGroupBox3
            // 
            this.optionSelectionGroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.optionSelectionGroupBox3.Controls.Add(this.expRadioButton7);
            this.optionSelectionGroupBox3.Controls.Add(this.expRadioButton6);
            this.optionSelectionGroupBox3.Controls.Add(this.expRadioButton5);
            this.optionSelectionGroupBox3.Controls.Add(this.expRadioButton4);
            this.optionSelectionGroupBox3.Controls.Add(this.expRadioButton3);
            this.optionSelectionGroupBox3.Controls.Add(this.expRadioButton2);
            this.optionSelectionGroupBox3.Controls.Add(this.expRadioButton1);
            this.optionSelectionGroupBox3.Controls.Add(this.expRadioButtonAll);
            this.optionSelectionGroupBox3.Enabled = false;
            this.optionSelectionGroupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.optionSelectionGroupBox3.Location = new System.Drawing.Point(460, 10);
            this.optionSelectionGroupBox3.Name = "optionSelectionGroupBox3";
            this.optionSelectionGroupBox3.Size = new System.Drawing.Size(536, 34);
            this.optionSelectionGroupBox3.TabIndex = 0;
            this.optionSelectionGroupBox3.TabStop = false;
            // 
            // expRadioButton7
            // 
            this.expRadioButton7.Appearance = System.Windows.Forms.Appearance.Button;
            this.expRadioButton7.Location = new System.Drawing.Point(345, 9);
            this.expRadioButton7.Name = "expRadioButton7";
            this.expRadioButton7.Size = new System.Drawing.Size(50, 22);
            this.expRadioButton7.TabIndex = 17;
            this.expRadioButton7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expRadioButton7.UseVisualStyleBackColor = true;
            this.expRadioButton7.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // expRadioButton6
            // 
            this.expRadioButton6.Appearance = System.Windows.Forms.Appearance.Button;
            this.expRadioButton6.Location = new System.Drawing.Point(296, 9);
            this.expRadioButton6.Name = "expRadioButton6";
            this.expRadioButton6.Size = new System.Drawing.Size(50, 22);
            this.expRadioButton6.TabIndex = 16;
            this.expRadioButton6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expRadioButton6.UseVisualStyleBackColor = true;
            this.expRadioButton6.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // expRadioButton5
            // 
            this.expRadioButton5.Appearance = System.Windows.Forms.Appearance.Button;
            this.expRadioButton5.Location = new System.Drawing.Point(247, 9);
            this.expRadioButton5.Name = "expRadioButton5";
            this.expRadioButton5.Size = new System.Drawing.Size(50, 22);
            this.expRadioButton5.TabIndex = 15;
            this.expRadioButton5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expRadioButton5.UseVisualStyleBackColor = true;
            this.expRadioButton5.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // expRadioButton4
            // 
            this.expRadioButton4.Appearance = System.Windows.Forms.Appearance.Button;
            this.expRadioButton4.Location = new System.Drawing.Point(198, 9);
            this.expRadioButton4.Name = "expRadioButton4";
            this.expRadioButton4.Size = new System.Drawing.Size(50, 22);
            this.expRadioButton4.TabIndex = 14;
            this.expRadioButton4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expRadioButton4.UseVisualStyleBackColor = true;
            this.expRadioButton4.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // expRadioButton3
            // 
            this.expRadioButton3.Appearance = System.Windows.Forms.Appearance.Button;
            this.expRadioButton3.Location = new System.Drawing.Point(149, 9);
            this.expRadioButton3.Name = "expRadioButton3";
            this.expRadioButton3.Size = new System.Drawing.Size(50, 22);
            this.expRadioButton3.TabIndex = 13;
            this.expRadioButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expRadioButton3.UseVisualStyleBackColor = true;
            this.expRadioButton3.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // expRadioButton2
            // 
            this.expRadioButton2.Appearance = System.Windows.Forms.Appearance.Button;
            this.expRadioButton2.Location = new System.Drawing.Point(100, 9);
            this.expRadioButton2.Name = "expRadioButton2";
            this.expRadioButton2.Size = new System.Drawing.Size(50, 22);
            this.expRadioButton2.TabIndex = 12;
            this.expRadioButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expRadioButton2.UseVisualStyleBackColor = true;
            this.expRadioButton2.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // expRadioButton1
            // 
            this.expRadioButton1.Appearance = System.Windows.Forms.Appearance.Button;
            this.expRadioButton1.Location = new System.Drawing.Point(51, 9);
            this.expRadioButton1.Name = "expRadioButton1";
            this.expRadioButton1.Size = new System.Drawing.Size(50, 22);
            this.expRadioButton1.TabIndex = 11;
            this.expRadioButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expRadioButton1.UseVisualStyleBackColor = true;
            this.expRadioButton1.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // expRadioButtonAll
            // 
            this.expRadioButtonAll.Appearance = System.Windows.Forms.Appearance.Button;
            this.expRadioButtonAll.Checked = true;
            this.expRadioButtonAll.Location = new System.Drawing.Point(2, 9);
            this.expRadioButtonAll.Name = "expRadioButtonAll";
            this.expRadioButtonAll.Size = new System.Drawing.Size(50, 22);
            this.expRadioButtonAll.TabIndex = 10;
            this.expRadioButtonAll.TabStop = true;
            this.expRadioButtonAll.Text = "All";
            this.expRadioButtonAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.expRadioButtonAll.UseVisualStyleBackColor = true;
            this.expRadioButtonAll.CheckedChanged += new System.EventHandler(this.filtersCheckBox_CheckedChanged);
            // 
            // stockText
            // 
            this.stockText.BackColor = System.Drawing.Color.LightSteelBlue;
            this.stockText.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.stockText.ContextMenuStrip = this.stockContextMenu;
            this.stockText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stockText.ForeColor = System.Drawing.Color.Black;
            this.stockText.Location = new System.Drawing.Point(75, 19);
            this.stockText.Name = "stockText";
            this.stockText.Size = new System.Drawing.Size(94, 20);
            this.stockText.TabIndex = 1;
            this.stockText.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockText.TextChanged += new System.EventHandler(this.stockText_TextChanged);
            this.stockText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.stockText_KeyUp);
            this.stockText.MouseDown += new System.Windows.Forms.MouseEventHandler(this.stockText_MouseDown);
            // 
            // updateButton
            // 
            this.updateButton.Enabled = false;
            this.updateButton.Location = new System.Drawing.Point(75, 50);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(94, 24);
            this.updateButton.TabIndex = 2;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            this.updateButton.Click += new System.EventHandler(this.updateButton_Click);
            // 
            // optionSelectionGroupBox2
            // 
            this.optionSelectionGroupBox2.Controls.Add(this.otmCheckBox);
            this.optionSelectionGroupBox2.Controls.Add(this.atmCheckBox);
            this.optionSelectionGroupBox2.Controls.Add(this.itmCheckBox);
            this.optionSelectionGroupBox2.Enabled = false;
            this.optionSelectionGroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.optionSelectionGroupBox2.Location = new System.Drawing.Point(269, 10);
            this.optionSelectionGroupBox2.Name = "optionSelectionGroupBox2";
            this.optionSelectionGroupBox2.Size = new System.Drawing.Size(137, 34);
            this.optionSelectionGroupBox2.TabIndex = 0;
            this.optionSelectionGroupBox2.TabStop = false;
            // 
            // impHisLabel
            // 
            this.impHisLabel.AutoSize = true;
            this.impHisLabel.Location = new System.Drawing.Point(8, 177);
            this.impHisLabel.Name = "impHisLabel";
            this.impHisLabel.Size = new System.Drawing.Size(61, 13);
            this.impHisLabel.TabIndex = 0;
            this.impHisLabel.Text = "Imp / His %";
            // 
            // impVolatilityText
            // 
            this.impVolatilityText.BackColor = System.Drawing.Color.Black;
            this.impVolatilityText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.impVolatilityText.ForeColor = System.Drawing.Color.Cornsilk;
            this.impVolatilityText.Location = new System.Drawing.Point(75, 174);
            this.impVolatilityText.Name = "impVolatilityText";
            this.impVolatilityText.Size = new System.Drawing.Size(48, 20);
            this.impVolatilityText.TabIndex = 0;
            this.impVolatilityText.TabStop = false;
            this.impVolatilityText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.impVolatilityText.Enter += new System.EventHandler(this.xxxText_Enter);
            this.impVolatilityText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.xxxText_KeyUp);
            this.impVolatilityText.Leave += new System.EventHandler(this.xxxText_Leave);
            // 
            // optionSelectionGroupBox4
            // 
            this.optionSelectionGroupBox4.Controls.Add(this.grkCheckBox);
            this.optionSelectionGroupBox4.Enabled = false;
            this.optionSelectionGroupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.optionSelectionGroupBox4.Location = new System.Drawing.Point(408, 10);
            this.optionSelectionGroupBox4.Name = "optionSelectionGroupBox4";
            this.optionSelectionGroupBox4.Size = new System.Drawing.Size(50, 34);
            this.optionSelectionGroupBox4.TabIndex = 0;
            this.optionSelectionGroupBox4.TabStop = false;
            // 
            // stockGroupBox
            // 
            this.stockGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.stockGroupBox.Controls.Add(this.askText);
            this.stockGroupBox.Controls.Add(this.hisVolatilityText);
            this.stockGroupBox.Controls.Add(this.optionSelectionGroupBox4);
            this.stockGroupBox.Controls.Add(this.impVolatilityText);
            this.stockGroupBox.Controls.Add(this.impHisLabel);
            this.stockGroupBox.Controls.Add(this.optionSelectionGroupBox2);
            this.stockGroupBox.Controls.Add(this.stockText);
            this.stockGroupBox.Controls.Add(this.optionSelectionGroupBox3);
            this.stockGroupBox.Controls.Add(this.optionSelectionGroupBox1);
            this.stockGroupBox.Controls.Add(this.lastUpdateLabel);
            this.stockGroupBox.Controls.Add(this.dividendLabel);
            this.stockGroupBox.Controls.Add(this.lastUpdateText);
            this.stockGroupBox.Controls.Add(this.bidAskLabel);
            this.stockGroupBox.Controls.Add(this.changeLabel);
            this.stockGroupBox.Controls.Add(this.lastPriceLabel);
            this.stockGroupBox.Controls.Add(this.dividendText);
            this.stockGroupBox.Controls.Add(this.bidText);
            this.stockGroupBox.Controls.Add(this.changeText);
            this.stockGroupBox.Controls.Add(this.lastPriceText);
            this.stockGroupBox.Controls.Add(this.stockLabel);
            this.stockGroupBox.Controls.Add(this.optionsDataGridView);
            this.stockGroupBox.Controls.Add(this.updateButton);
            this.stockGroupBox.Controls.Add(this.autoRefreshCheckBox);
            this.stockGroupBox.Controls.Add(this.downloadLabel);
            this.stockGroupBox.Controls.Add(this.progressLabel);
            this.stockGroupBox.Controls.Add(this.serverProgressBar);
            this.stockGroupBox.Location = new System.Drawing.Point(0, 2);
            this.stockGroupBox.Name = "stockGroupBox";
            this.stockGroupBox.Size = new System.Drawing.Size(1007, 205);
            this.stockGroupBox.TabIndex = 0;
            this.stockGroupBox.TabStop = false;
            this.stockGroupBox.Text = "Underlying Data";
            // 
            // askText
            // 
            this.askText.BackColor = System.Drawing.Color.Black;
            this.askText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.askText.ForeColor = System.Drawing.Color.Cornsilk;
            this.askText.Location = new System.Drawing.Point(122, 136);
            this.askText.Name = "askText";
            this.askText.ReadOnly = true;
            this.askText.Size = new System.Drawing.Size(47, 20);
            this.askText.TabIndex = 42;
            this.askText.TabStop = false;
            this.askText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // hisVolatilityText
            // 
            this.hisVolatilityText.BackColor = System.Drawing.Color.Black;
            this.hisVolatilityText.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hisVolatilityText.ForeColor = System.Drawing.Color.Cornsilk;
            this.hisVolatilityText.Location = new System.Drawing.Point(122, 174);
            this.hisVolatilityText.Name = "hisVolatilityText";
            this.hisVolatilityText.Size = new System.Drawing.Size(47, 20);
            this.hisVolatilityText.TabIndex = 41;
            this.hisVolatilityText.TabStop = false;
            this.hisVolatilityText.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.hisVolatilityText.Enter += new System.EventHandler(this.xxxText_Enter);
            this.hisVolatilityText.KeyUp += new System.Windows.Forms.KeyEventHandler(this.xxxText_KeyUp);
            this.hisVolatilityText.Leave += new System.EventHandler(this.xxxText_Leave);
            // 
            // downloadLabel
            // 
            this.downloadLabel.BackColor = System.Drawing.Color.Transparent;
            this.downloadLabel.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.downloadLabel.Location = new System.Drawing.Point(11, 50);
            this.downloadLabel.Name = "downloadLabel";
            this.downloadLabel.Size = new System.Drawing.Size(158, 24);
            this.downloadLabel.TabIndex = 0;
            this.downloadLabel.Text = "Downloading Stock Data ...";
            this.downloadLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // progressLabel
            // 
            this.progressLabel.AutoSize = true;
            this.progressLabel.Location = new System.Drawing.Point(9, 56);
            this.progressLabel.Name = "progressLabel";
            this.progressLabel.Size = new System.Drawing.Size(48, 13);
            this.progressLabel.TabIndex = 40;
            this.progressLabel.Text = "Progress";
            // 
            // serverProgressBar
            // 
            this.serverProgressBar.Location = new System.Drawing.Point(75, 51);
            this.serverProgressBar.Name = "serverProgressBar";
            this.serverProgressBar.Size = new System.Drawing.Size(94, 22);
            this.serverProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.serverProgressBar.TabIndex = 0;
            this.serverProgressBar.Value = 60;
            // 
            // topSplitContainer
            // 
            this.topSplitContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.topSplitContainer.Location = new System.Drawing.Point(4, 0);
            this.topSplitContainer.Name = "topSplitContainer";
            this.topSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // topSplitContainer.Panel1
            // 
            this.topSplitContainer.Panel1.Controls.Add(this.stockGroupBox);
            // 
            // topSplitContainer.Panel2
            // 
            this.topSplitContainer.Panel2.Controls.Add(this.bottomSplitContainer);
            this.topSplitContainer.Size = new System.Drawing.Size(1007, 700);
            this.topSplitContainer.SplitterDistance = 208;
            this.topSplitContainer.SplitterWidth = 1;
            this.topSplitContainer.TabIndex = 40;
            // 
            // bottomSplitContainer
            // 
            this.bottomSplitContainer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bottomSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.bottomSplitContainer.Name = "bottomSplitContainer";
            this.bottomSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // bottomSplitContainer.Panel1
            // 
            this.bottomSplitContainer.Panel1.Controls.Add(this.positionGroupBox);
            // 
            // bottomSplitContainer.Panel2
            // 
            this.bottomSplitContainer.Panel2.Controls.Add(this.resultGroupBox);
            this.bottomSplitContainer.Panel2.Controls.Add(this.controlGroupBox);
            this.bottomSplitContainer.Size = new System.Drawing.Size(1007, 497);
            this.bottomSplitContainer.SplitterDistance = 227;
            this.bottomSplitContainer.SplitterWidth = 1;
            this.bottomSplitContainer.TabIndex = 0;
            // 
            // analysisWorker
            // 
            this.analysisWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.analysisWorker_DoWork);
            // 
            // endEditTimer
            // 
            this.endEditTimer.Interval = 1;
            this.endEditTimer.Tick += new System.EventHandler(this.endEditTimer_Tick);
            // 
            // quotesTableBindingSource
            // 
            this.quotesTableBindingSource.DataMember = "QuotesTable";
            this.quotesTableBindingSource.DataSource = this.optionsSet;
            // 
            // opoOpenFileDialog
            // 
            this.opoOpenFileDialog.Filter = "opo files (*.opo)|*.opo|All files (*.*)|*.*";
            this.opoOpenFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opoPath;
            // 
            // opoSaveFileDialog
            // 
            this.opoSaveFileDialog.Filter = "opo files (*.opo)|*.opo|excel xml (*.xml)|*.xml|All files (*.*)|*.*";
            this.opoSaveFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opoPath;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1016, 694);
            this.Controls.Add(this.topSplitContainer);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(1024, 730);
            this.Name = "MainForm";
            this.Tag = "OptionsOracle";
            this.Text = "OptionsOracle";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Shown += new System.EventHandler(this.MainForm_Shown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyUp);
            this.positionGroupBox.ResumeLayout(false);
            this.positionGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.endMonthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startMonthUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.endDayUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startDayUpDown)).EndInit();
            this.unfreezeContextMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.strategyDataGridView)).EndInit();
            this.positionsContextMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.positionsTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.optionsSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.globalTableBindingSource)).EndInit();
            this.resultGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.resultsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultsTableBindingSource)).EndInit();
            this.controlGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.optionsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.optionsTableBindingSource)).EndInit();
            this.optionSelectionGroupBox1.ResumeLayout(false);
            this.optionSelectionGroupBox3.ResumeLayout(false);
            this.optionSelectionGroupBox2.ResumeLayout(false);
            this.optionSelectionGroupBox4.ResumeLayout(false);
            this.stockGroupBox.ResumeLayout(false);
            this.stockGroupBox.PerformLayout();
            this.topSplitContainer.Panel1.ResumeLayout(false);
            this.topSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.topSplitContainer)).EndInit();
            this.topSplitContainer.ResumeLayout(false);
            this.bottomSplitContainer.Panel1.ResumeLayout(false);
            this.bottomSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bottomSplitContainer)).EndInit();
            this.bottomSplitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.quotesTableBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource optionsTableBindingSource;
        private OptionsOracle.Data.OptionsSet optionsSet;
        private System.ComponentModel.BackgroundWorker downloadWorker;
        private System.Windows.Forms.GroupBox positionGroupBox;
        private System.Windows.Forms.DataGridView strategyDataGridView;
        private System.Windows.Forms.BindingSource positionsTableBindingSource;
        private System.Windows.Forms.Button configurationButton;
        private System.Windows.Forms.BindingSource resultsTableBindingSource;
        private System.Windows.Forms.Button clearPositionButton;
        private System.Windows.Forms.Button addRowbutton;
        private System.Windows.Forms.Button deleteRowbutton;
        private System.Windows.Forms.GroupBox resultGroupBox;
        private System.Windows.Forms.GroupBox controlGroupBox;
        private System.Windows.Forms.WebBrowser titlePanelWebBrowser;
        private System.Windows.Forms.ContextMenuStrip positionsContextMenu;
        private System.Windows.Forms.ToolStripMenuItem addRowMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteRowMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.Button tourButton;
        private System.Windows.Forms.Button graphButton;
        private System.Windows.Forms.ContextMenuStrip stockContextMenu;
        private System.Windows.Forms.Button loadButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button contactUsButton;
        private System.Windows.Forms.Timer autoRefreshTimer;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Button newButton;
        private System.Windows.Forms.BindingSource quotesTableBindingSource;
        private System.Windows.Forms.Label endDateLabel;
        private System.Windows.Forms.Label startDateLabel;
        private System.Windows.Forms.DateTimePicker startDateTimePicker;
        private System.Windows.Forms.DateTimePicker endDateTimePicker;
        private System.Windows.Forms.DataGridView resultsDataGridView;
        private System.Windows.Forms.TextBox startDateTextBox;
        private System.Windows.Forms.TextBox endDateTextBox;
        private System.Windows.Forms.NumericUpDown endDayUpDown;
        private System.Windows.Forms.NumericUpDown startDayUpDown;
        private System.Windows.Forms.NumericUpDown endMonthUpDown;
        private System.Windows.Forms.NumericUpDown startMonthUpDown;
        private System.Windows.Forms.BindingSource globalTableBindingSource;
        private System.Windows.Forms.ContextMenuStrip unfreezeContextMenu;
        private System.Windows.Forms.ToolStripMenuItem unfreezeDateLookupToolStripMenuItem;
        private System.Windows.Forms.Button calculatorButton;
        private System.ComponentModel.BackgroundWorker graphWorker;
        private System.Windows.Forms.Button wizardButton;
        private System.Windows.Forms.ToolStripMenuItem freezeToolStripMenuItem;
        private System.Windows.Forms.Button templateButton;
        private System.Windows.Forms.Button volatilityCalcButton;
        private System.Windows.Forms.Button portfolioButton;
        private System.Windows.Forms.TextBox notesTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsIndexColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn resultsIsCreditColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsCriteriaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsPriceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsChangeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsProbColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsTotalColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsTotalPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsMonthlyPrcColumn;
        private System.Windows.Forms.Button volatilitySmileButton;
        private System.Windows.Forms.Button printButton;
        private System.Windows.Forms.Button putCallRatioButton;
        private System.Windows.Forms.DataGridView optionsDataGridView;
        private System.Windows.Forms.Label stockLabel;
        private System.Windows.Forms.TextBox lastPriceText;
        private System.Windows.Forms.TextBox changeText;
        private System.Windows.Forms.TextBox bidText;
        private System.Windows.Forms.TextBox dividendText;
        private System.Windows.Forms.Label lastPriceLabel;
        private System.Windows.Forms.Label changeLabel;
        private System.Windows.Forms.Label bidAskLabel;
        private System.Windows.Forms.TextBox lastUpdateText;
        private System.Windows.Forms.Label dividendLabel;
        private System.Windows.Forms.Label lastUpdateLabel;
        private System.Windows.Forms.GroupBox optionSelectionGroupBox1;
        private System.Windows.Forms.CheckBox putsCheckBox;
        private System.Windows.Forms.CheckBox callsCheckBox;
        private System.Windows.Forms.GroupBox optionSelectionGroupBox3;
        private System.Windows.Forms.RadioButton expRadioButton7;
        private System.Windows.Forms.RadioButton expRadioButton6;
        private System.Windows.Forms.RadioButton expRadioButton5;
        private System.Windows.Forms.RadioButton expRadioButton4;
        private System.Windows.Forms.RadioButton expRadioButton3;
        private System.Windows.Forms.RadioButton expRadioButton2;
        private System.Windows.Forms.RadioButton expRadioButton1;
        private System.Windows.Forms.RadioButton expRadioButtonAll;
        private System.Windows.Forms.TextBox stockText;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.CheckBox autoRefreshCheckBox;
        private System.Windows.Forms.GroupBox optionSelectionGroupBox2;
        private System.Windows.Forms.CheckBox otmCheckBox;
        private System.Windows.Forms.CheckBox atmCheckBox;
        private System.Windows.Forms.CheckBox itmCheckBox;
        private System.Windows.Forms.Label impHisLabel;
        private System.Windows.Forms.TextBox impVolatilityText;
        private System.Windows.Forms.GroupBox optionSelectionGroupBox4;
        private System.Windows.Forms.CheckBox grkCheckBox;
        private System.Windows.Forms.GroupBox stockGroupBox;
        private System.Windows.Forms.Label downloadLabel;
        private System.Windows.Forms.ProgressBar serverProgressBar;
        private System.Windows.Forms.Label progressLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsTypeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsStrikeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsExpirationColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsSymbolColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsLastColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsChangeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsTimeValueColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsBidColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsAskColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsVolumeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsOpenIntColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsImpliedVolatilityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsITMProbColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsDeltaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsGammaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsVegaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsThetaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsStockColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsUpdateTimeStampColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsStdDevColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsIndicator1Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn optionsIndicator2Column;
        private System.Windows.Forms.SplitContainer topSplitContainer;
        private System.Windows.Forms.SplitContainer bottomSplitContainer;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox hisVolatilityText;
        private System.Windows.Forms.TextBox askText;
        private System.Windows.Forms.Button analysisButton;
        private System.ComponentModel.BackgroundWorker analysisWorker;
        private System.Windows.Forms.Button optionPainButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsIndexColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsFlagsColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn positionsEnableColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn positionsIdColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn positionsTypeColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn positionsStrikeColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn positionsExpirationColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn positionsSymbolColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsQuantityColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn positionsToOpenColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsPriceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsLastPriceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsVolatilityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsCommissionColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsNetMarginColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsMktValueColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsInvestmentColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsDeltaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsGammaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsVegaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsThetaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsTimeValueColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionsInterestColumn;
        private System.Windows.Forms.Button designerButton;
        private System.Windows.Forms.Timer endEditTimer;
        private System.Windows.Forms.OpenFileDialog opoOpenFileDialog;
        private System.Windows.Forms.SaveFileDialog opoSaveFileDialog;
        private System.Windows.Forms.Button aboutButton;
    }
}

