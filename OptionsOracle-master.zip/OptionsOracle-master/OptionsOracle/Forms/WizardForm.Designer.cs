namespace OptionsOracle.Forms
{
    partial class WizardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WizardForm));
            this.cancelButton = new System.Windows.Forms.Button();
            this.strategyComboBox = new System.Windows.Forms.ComboBox();
            this.strategyGroup = new System.Windows.Forms.GroupBox();
            this.loadSetButton = new System.Windows.Forms.Button();
            this.saveSetButton = new System.Windows.Forms.Button();
            this.clearSetButton = new System.Windows.Forms.Button();
            this.strategyDataGridView = new System.Windows.Forms.DataGridView();
            this.wizardEndDateColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardIndexColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardTypeColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardQuantityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardStrikeSign1Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardStrike1Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardStrikeSign2Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardStrike2Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardExpirationSign1Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardExpiration1Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardExpirationSign2Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardExpiration2Column = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.wizardTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wizardSet = new OptionsOracle.Data.WizardSet();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.strategyTabControl = new System.Windows.Forms.TabControl();
            this.tabStrategy1 = new System.Windows.Forms.TabPage();
            this.tabStrategy2 = new System.Windows.Forms.TabPage();
            this.tabStrategy3 = new System.Windows.Forms.TabPage();
            this.tabStrategy4 = new System.Windows.Forms.TabPage();
            this.endDateManualLabel = new System.Windows.Forms.Label();
            this.investmentSizeManualLabel = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.investmentSizeModeComboBox = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.endDateModeComboBox = new System.Windows.Forms.ComboBox();
            this.loadButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.investmentSizeManualNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.addRowbutton = new System.Windows.Forms.Button();
            this.deleteRowbutton = new System.Windows.Forms.Button();
            this.clearPositionButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.endDateManualDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.dateRulesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.strikeRulesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.expirationRulesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wizardControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label31 = new System.Windows.Forms.Label();
            this.stockListGroupBox = new System.Windows.Forms.GroupBox();
            this.quickGetButton = new System.Windows.Forms.Button();
            this.clearListButton = new System.Windows.Forms.Button();
            this.loadListButton = new System.Windows.Forms.Button();
            this.saveListButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.stocksListTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.infoLabel = new System.Windows.Forms.Label();
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.duplicateOptionsFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.askBidFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.impVolFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.historicalVolNotePanel = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.stockMaxVolRatioNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.stockMinVolRatioNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.stockVolRatioFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.stockMaxHisVolNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.stockMinHisVolNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.stockHisVolFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.stockMaxImpVolNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.stockMinImpVolNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.stockImpVolFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label22 = new System.Windows.Forms.Label();
            this.maxResultsNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.maxResultsFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.minOpenIntNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.openIntFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.expirationFilterGroupBox = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.expFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.maxExpDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.minExpDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.stockMaxPriceNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.stockMinPriceNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.stockPriceFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.otmMaxStrikeNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.itmMaxStrikeNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.otmMinStrikeNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.itmMinStrikeNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.otmStrikeFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.itmStrikeFilterCheckBox = new System.Windows.Forms.CheckBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.maxMaxLossNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.minMaxProfitNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.maxMaxLossCheckBox = new System.Windows.Forms.CheckBox();
            this.minMaxProfitCheckBox = new System.Windows.Forms.CheckBox();
            this.profitLossRatioCheckBox = new System.Windows.Forms.CheckBox();
            this.minProtectionNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.profitLossMinRatioNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label80 = new System.Windows.Forms.Label();
            this.minProtectionCheckBox = new System.Windows.Forms.CheckBox();
            this.maxBreakevenNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label82 = new System.Windows.Forms.Label();
            this.maxBreakevenCheckBox = new System.Windows.Forms.CheckBox();
            this.protectionMaxProbNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.protectionMinProbNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label54 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.protectionProbCheckBox = new System.Windows.Forms.CheckBox();
            this.breakevenMaxProbNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.breakevenMinProbNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label51 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.breakevenProbCheckBox = new System.Windows.Forms.CheckBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.totalThetaMaxNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.totalVegaMaxNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.totalThetaMinNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.totalVegaMinNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label55 = new System.Windows.Forms.Label();
            this.totalThetaCheckBox = new System.Windows.Forms.CheckBox();
            this.label57 = new System.Windows.Forms.Label();
            this.totalVegaCheckBox = new System.Windows.Forms.CheckBox();
            this.totalGammaMaxNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.totalDeltaMaxNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.totalGammaMinNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.totalDeltaMinNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label50 = new System.Windows.Forms.Label();
            this.totalGammaCheckBox = new System.Windows.Forms.CheckBox();
            this.label53 = new System.Windows.Forms.Label();
            this.totalDeltaCheckBox = new System.Windows.Forms.CheckBox();
            this.label43 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.stockMove2RadioButton = new System.Windows.Forms.RadioButton();
            this.stockMove1RadioButton = new System.Windows.Forms.RadioButton();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.stockMoveMaxStdDevNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.stockMoveMinStdDevNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.stockMoveMaxNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.stockMoveMinNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.stockMoveCheckBox = new System.Windows.Forms.CheckBox();
            this.expReturnMinNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.expReturnCheckBox = new System.Windows.Forms.CheckBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.indicator2CheckBox = new System.Windows.Forms.CheckBox();
            this.indicator2GroupBox = new System.Windows.Forms.GroupBox();
            this.indicator2MaxNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.indicator2MinNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label78 = new System.Windows.Forms.Label();
            this.indicator2FilterCheckBox = new System.Windows.Forms.CheckBox();
            this.label69 = new System.Windows.Forms.Label();
            this.indicator2FormatTextBox = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.indicator2NameTextBox = new System.Windows.Forms.TextBox();
            this.indicator2EquationTextBox = new System.Windows.Forms.TextBox();
            this.indicator1CheckBox = new System.Windows.Forms.CheckBox();
            this.indicator1GroupBox = new System.Windows.Forms.GroupBox();
            this.indicator1MaxNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.indicator1MinNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label79 = new System.Windows.Forms.Label();
            this.indicator1FilterCheckBox = new System.Windows.Forms.CheckBox();
            this.label74 = new System.Windows.Forms.Label();
            this.indicator1FormatTextBox = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.indicator1NameTextBox = new System.Windows.Forms.TextBox();
            this.indicator1EquationTextBox = new System.Windows.Forms.TextBox();
            this.label73 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.stockDatabaseGroupBox = new System.Windows.Forms.GroupBox();
            this.stockListDataGridView1 = new System.Windows.Forms.DataGridView();
            this.stockDownloadSymbolColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockDownloadDatabaseColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stocksTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label17 = new System.Windows.Forms.Label();
            this.downloadMethodGroupBox = new System.Windows.Forms.GroupBox();
            this.dw1RadioButton = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.dw3RadioButton = new System.Windows.Forms.RadioButton();
            this.oldDaysTextBox = new System.Windows.Forms.TextBox();
            this.dw2RadioButton = new System.Windows.Forms.RadioButton();
            this.progressGroupBox = new System.Windows.Forms.GroupBox();
            this.downloadStatusLabel = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.downloadStartStopButton = new System.Windows.Forms.Button();
            this.downloadProgressBar = new System.Windows.Forms.ProgressBar();
            this.label18 = new System.Windows.Forms.Label();
            this.downloadStartTimeLabel = new System.Windows.Forms.Label();
            this.downloadEstFinishTimeLabel = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.stockListDataGridView2 = new System.Windows.Forms.DataGridView();
            this.stockAnalysisSymbolColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockAnalysisAnalysisColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.analysisStatusLabel = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.analysisStartStopButton = new System.Windows.Forms.Button();
            this.analysisProgressBar = new System.Windows.Forms.ProgressBar();
            this.label23 = new System.Windows.Forms.Label();
            this.analysisStartTimeLabel = new System.Windows.Forms.Label();
            this.analysisEstFinishTimeLabel = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.moveDaysToExpTextBox = new System.Windows.Forms.TextBox();
            this.moveButton = new System.Windows.Forms.Button();
            this.resultLoadButton = new System.Windows.Forms.Button();
            this.resultSaveButton = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.moveHistoricalVolatilityTextBox = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.moveImpiledVolatilityTextBox = new System.Windows.Forms.TextBox();
            this.movePriceTextBox = new System.Windows.Forms.TextBox();
            this.movePositionTextBox = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.resultsDataGridView = new System.Windows.Forms.DataGridView();
            this.wizardResultsIndexColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsStockColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsPositionColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsEndDateColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsNetInvestmentColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsTotalDebitColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsMaxProfitPotentialColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsMaxProfitPotentialPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsMaxLossRiskColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsMaxLossRiskPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsLowerBreakevenColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsUpperBreakevenColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsReturnAtMovementColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsReturnAtMovementPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsMeanReturnColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsMeanReturnPrcColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsTotalDeltaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsTotalGammaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsTotalThetaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsTotalVegaColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsInterestPaidColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsBreakevenProbColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsProtectionProbColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsProfitLossRatioColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsStockLastPriceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsStockImpVolatilityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsStockHisVolatilityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsIndicator1Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wizardResultsIndicator2Column = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsTableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label19 = new System.Windows.Forms.Label();
            this.skipAllButton = new System.Windows.Forms.Button();
            this.ReturnAtMovementPrc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nextButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.taskWorker = new System.ComponentModel.BackgroundWorker();
            this.taskTimer = new System.Windows.Forms.Timer(this.components);
            this.stockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.endDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.netInvestmentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maxProfitPotentialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maxLossRiskDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lowerBreakevenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.upperBreakevenDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.returnAtPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.meanReturnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.meanReturnPrcDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalDeltaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalGammaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalThetaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalVegaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.interestPaidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label33 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.restartButton = new System.Windows.Forms.Button();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.label65 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label66 = new System.Windows.Forms.Label();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown12 = new System.Windows.Forms.NumericUpDown();
            this.label67 = new System.Windows.Forms.Label();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.label68 = new System.Windows.Forms.Label();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.opwSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.opwOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.opsSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.opsOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.txtSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.txtOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.opxSaveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.opxOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.strategyGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.strategyDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wizardTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wizardSet)).BeginInit();
            this.strategyTabControl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.investmentSizeManualNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateRulesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.strikeRulesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.expirationRulesBindingSource)).BeginInit();
            this.wizardControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.stockListGroupBox.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.historicalVolNotePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockMaxVolRatioNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMinVolRatioNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMaxHisVolNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMinHisVolNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMaxImpVolNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMinImpVolNumericUpDown)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maxResultsNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minOpenIntNumericUpDown)).BeginInit();
            this.expirationFilterGroupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockMaxPriceNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMinPriceNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otmMaxStrikeNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itmMaxStrikeNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otmMinStrikeNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itmMinStrikeNumericUpDown)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maxMaxLossNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minMaxProfitNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.minProtectionNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.profitLossMinRatioNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxBreakevenNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.protectionMaxProbNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.protectionMinProbNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.breakevenMaxProbNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.breakevenMinProbNumericUpDown)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.totalThetaMaxNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalVegaMaxNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalThetaMinNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalVegaMinNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalGammaMaxNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalDeltaMaxNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalGammaMinNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalDeltaMinNumericUpDown)).BeginInit();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockMoveMaxStdDevNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMoveMinStdDevNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMoveMaxNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMoveMinNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.expReturnMinNumericUpDown)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.indicator2GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.indicator2MaxNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicator2MinNumericUpDown)).BeginInit();
            this.indicator1GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.indicator1MaxNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicator1MinNumericUpDown)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.stockDatabaseGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockListDataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stocksTableBindingSource)).BeginInit();
            this.downloadMethodGroupBox.SuspendLayout();
            this.progressGroupBox.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockListDataGridView2)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultsTableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).BeginInit();
            this.SuspendLayout();
            // 
            // cancelButton
            // 
            this.cancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(504, 420);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(90, 24);
            this.cancelButton.TabIndex = 7;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // strategyComboBox
            // 
            this.strategyComboBox.FormattingEnabled = true;
            this.strategyComboBox.Location = new System.Drawing.Point(8, 32);
            this.strategyComboBox.Name = "strategyComboBox";
            this.strategyComboBox.Size = new System.Drawing.Size(280, 21);
            this.strategyComboBox.TabIndex = 1;
            this.strategyComboBox.SelectedIndexChanged += new System.EventHandler(this.strategyComboBox_SelectedIndexChanged);
            this.strategyComboBox.TextChanged += new System.EventHandler(this.strategyComboBox_TextChanged);
            // 
            // strategyGroup
            // 
            this.strategyGroup.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.strategyGroup.Controls.Add(this.loadSetButton);
            this.strategyGroup.Controls.Add(this.saveSetButton);
            this.strategyGroup.Controls.Add(this.clearSetButton);
            this.strategyGroup.Controls.Add(this.strategyDataGridView);
            this.strategyGroup.Controls.Add(this.groupBox4);
            this.strategyGroup.Controls.Add(this.groupBox5);
            this.strategyGroup.Controls.Add(this.groupBox6);
            this.strategyGroup.Controls.Add(this.groupBox7);
            this.strategyGroup.Controls.Add(this.strategyTabControl);
            this.strategyGroup.Controls.Add(this.endDateManualLabel);
            this.strategyGroup.Controls.Add(this.investmentSizeManualLabel);
            this.strategyGroup.Controls.Add(this.label29);
            this.strategyGroup.Controls.Add(this.investmentSizeModeComboBox);
            this.strategyGroup.Controls.Add(this.label28);
            this.strategyGroup.Controls.Add(this.endDateModeComboBox);
            this.strategyGroup.Controls.Add(this.loadButton);
            this.strategyGroup.Controls.Add(this.saveButton);
            this.strategyGroup.Controls.Add(this.investmentSizeManualNumericUpDown);
            this.strategyGroup.Controls.Add(this.addRowbutton);
            this.strategyGroup.Controls.Add(this.deleteRowbutton);
            this.strategyGroup.Controls.Add(this.clearPositionButton);
            this.strategyGroup.Controls.Add(this.label4);
            this.strategyGroup.Controls.Add(this.strategyComboBox);
            this.strategyGroup.Controls.Add(this.endDateManualDateTimePicker);
            this.strategyGroup.Location = new System.Drawing.Point(3, 25);
            this.strategyGroup.Name = "strategyGroup";
            this.strategyGroup.Size = new System.Drawing.Size(783, 309);
            this.strategyGroup.TabIndex = 0;
            this.strategyGroup.TabStop = false;
            this.strategyGroup.Text = "Strategy";
            // 
            // loadSetButton
            // 
            this.loadSetButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.loadSetButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.loadSetButton.Location = new System.Drawing.Point(591, 246);
            this.loadSetButton.Name = "loadSetButton";
            this.loadSetButton.Size = new System.Drawing.Size(90, 24);
            this.loadSetButton.TabIndex = 14;
            this.loadSetButton.Text = "Load Set";
            this.loadSetButton.UseVisualStyleBackColor = true;
            this.loadSetButton.Click += new System.EventHandler(this.loadSetButton_Click);
            // 
            // saveSetButton
            // 
            this.saveSetButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.saveSetButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveSetButton.Location = new System.Drawing.Point(591, 274);
            this.saveSetButton.Name = "saveSetButton";
            this.saveSetButton.Size = new System.Drawing.Size(90, 24);
            this.saveSetButton.TabIndex = 15;
            this.saveSetButton.Text = "Save Set";
            this.saveSetButton.UseVisualStyleBackColor = true;
            this.saveSetButton.Click += new System.EventHandler(this.saveSetButton_Click);
            // 
            // clearSetButton
            // 
            this.clearSetButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.clearSetButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearSetButton.Location = new System.Drawing.Point(8, 246);
            this.clearSetButton.Name = "clearSetButton";
            this.clearSetButton.Size = new System.Drawing.Size(90, 24);
            this.clearSetButton.TabIndex = 13;
            this.clearSetButton.Text = "Delete Set";
            this.clearSetButton.UseVisualStyleBackColor = true;
            this.clearSetButton.Click += new System.EventHandler(this.clearSetButton_Click);
            // 
            // strategyDataGridView
            // 
            this.strategyDataGridView.AllowUserToAddRows = false;
            this.strategyDataGridView.AllowUserToDeleteRows = false;
            this.strategyDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.strategyDataGridView.AutoGenerateColumns = false;
            this.strategyDataGridView.ColumnHeadersHeight = 22;
            this.strategyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.strategyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.wizardEndDateColumn,
            this.wizardIndexColumn,
            this.wizardTypeColumn,
            this.wizardQuantityColumn,
            this.wizardStrikeSign1Column,
            this.wizardStrike1Column,
            this.wizardStrikeSign2Column,
            this.wizardStrike2Column,
            this.wizardExpirationSign1Column,
            this.wizardExpiration1Column,
            this.wizardExpirationSign2Column,
            this.wizardExpiration2Column});
            this.strategyDataGridView.DataSource = this.wizardTableBindingSource;
            this.strategyDataGridView.Location = new System.Drawing.Point(8, 83);
            this.strategyDataGridView.Name = "strategyDataGridView";
            this.strategyDataGridView.RowHeadersVisible = false;
            this.strategyDataGridView.RowHeadersWidth = 16;
            this.strategyDataGridView.RowTemplate.Height = 20;
            this.strategyDataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.strategyDataGridView.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.strategyDataGridView.Size = new System.Drawing.Size(768, 154);
            this.strategyDataGridView.TabIndex = 6;
            this.strategyDataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.strategyDataGridView_CellValueChanged);
            this.strategyDataGridView.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.strategyDataGridView_CellBeginEdit);
            this.strategyDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.strategyDataGridView_CellFormatting);
            this.strategyDataGridView.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.strategyDataGridView_EditingControlShowing);
            this.strategyDataGridView.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.strategyDataGridView_DataError);
            // 
            // wizardEndDateColumn
            // 
            this.wizardEndDateColumn.DataPropertyName = "EndDate";
            this.wizardEndDateColumn.HeaderText = "End Date";
            this.wizardEndDateColumn.Name = "wizardEndDateColumn";
            this.wizardEndDateColumn.Visible = false;
            this.wizardEndDateColumn.Width = 85;
            // 
            // wizardIndexColumn
            // 
            this.wizardIndexColumn.DataPropertyName = "Index";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.wizardIndexColumn.DefaultCellStyle = dataGridViewCellStyle1;
            this.wizardIndexColumn.HeaderText = global::OptionsOracle.Properties.Resources.AppCustomizationMode;
            this.wizardIndexColumn.Name = "wizardIndexColumn";
            this.wizardIndexColumn.Width = 20;
            // 
            // wizardTypeColumn
            // 
            this.wizardTypeColumn.DataPropertyName = "Type";
            this.wizardTypeColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardTypeColumn.HeaderText = "Type";
            this.wizardTypeColumn.Items.AddRange(new object[] {
            "Long Stock",
            "Short Stock",
            "Long Call",
            "Short Call",
            "Long Put",
            "Short Put"});
            this.wizardTypeColumn.Name = "wizardTypeColumn";
            this.wizardTypeColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardTypeColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardTypeColumn.Width = 80;
            // 
            // wizardQuantityColumn
            // 
            this.wizardQuantityColumn.DataPropertyName = "Quantity";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle2.Format = "N0";
            this.wizardQuantityColumn.DefaultCellStyle = dataGridViewCellStyle2;
            this.wizardQuantityColumn.HeaderText = "Quantity";
            this.wizardQuantityColumn.Name = "wizardQuantityColumn";
            this.wizardQuantityColumn.Width = 59;
            // 
            // wizardStrikeSign1Column
            // 
            this.wizardStrikeSign1Column.DataPropertyName = "StrikeSign1";
            this.wizardStrikeSign1Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardStrikeSign1Column.HeaderText = "1st";
            this.wizardStrikeSign1Column.Items.AddRange(new object[] {
            global::OptionsOracle.Properties.Resources.AppCustomizationMode,
            "<",
            "<=",
            "=",
            ">=",
            ">",
            "<>"});
            this.wizardStrikeSign1Column.Name = "wizardStrikeSign1Column";
            this.wizardStrikeSign1Column.ReadOnly = true;
            this.wizardStrikeSign1Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardStrikeSign1Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardStrikeSign1Column.Width = 45;
            // 
            // wizardStrike1Column
            // 
            this.wizardStrike1Column.DataPropertyName = "Strike1";
            this.wizardStrike1Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardStrike1Column.HeaderText = "Strike Rule";
            this.wizardStrike1Column.Items.AddRange(new object[] {
            "Stock-Price - 3*SD",
            "Stock-Price - 2*SD",
            "Stock-Price - 1*SD",
            "Stock-Price",
            "Stock-Price + 1*SD",
            "Stock-Price + 2*SD",
            "Stock-Price + 3*SD",
            "Strike of A-1",
            "Strike of A",
            "Strike of A+1",
            "Strike of B-1",
            "Strike of B",
            "Strike of B+1",
            "Strike of C-1",
            "Strike of C",
            "Strike of C+1",
            "Strike of D-1",
            "Strike of D",
            "Strike of D+1",
            "Strike of E-1",
            "Strike of E",
            "Strike of E+1",
            "Strike of F-1",
            "Strike of F",
            "Strike of F+1",
            "Strike of G-1",
            "Strike of G",
            "Strike of G+1",
            "Strike of H-1",
            "Strike of H",
            "Strike of H+1",
            "Strike of I-1",
            "Strike of I",
            "Strike of I+1",
            "Strike of J-1",
            "Strike of J",
            "Strike of J+1"});
            this.wizardStrike1Column.Name = "wizardStrike1Column";
            this.wizardStrike1Column.ReadOnly = true;
            this.wizardStrike1Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardStrike1Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardStrike1Column.Width = 103;
            // 
            // wizardStrikeSign2Column
            // 
            this.wizardStrikeSign2Column.DataPropertyName = "StrikeSign2";
            this.wizardStrikeSign2Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardStrikeSign2Column.HeaderText = "2nd";
            this.wizardStrikeSign2Column.Items.AddRange(new object[] {
            global::OptionsOracle.Properties.Resources.AppCustomizationMode,
            "<",
            "<=",
            "=",
            ">=",
            ">",
            "<>"});
            this.wizardStrikeSign2Column.Name = "wizardStrikeSign2Column";
            this.wizardStrikeSign2Column.ReadOnly = true;
            this.wizardStrikeSign2Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardStrikeSign2Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardStrikeSign2Column.Width = 45;
            // 
            // wizardStrike2Column
            // 
            this.wizardStrike2Column.DataPropertyName = "Strike2";
            this.wizardStrike2Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardStrike2Column.HeaderText = "Strike Rule";
            this.wizardStrike2Column.Items.AddRange(new object[] {
            "Stock-Price - 3*SD",
            "Stock-Price - 2*SD",
            "Stock-Price - 1*SD",
            "Stock-Price",
            "Stock-Price + 1*SD",
            "Stock-Price + 2*SD",
            "Stock-Price + 3*SD",
            "Strike of A-1",
            "Strike of A",
            "Strike of A+1",
            "Strike of B-1",
            "Strike of B",
            "Strike of B+1",
            "Strike of C-1",
            "Strike of C",
            "Strike of C+1",
            "Strike of D-1",
            "Strike of D",
            "Strike of D+1",
            "Strike of E-1",
            "Strike of E",
            "Strike of E+1",
            "Strike of F-1",
            "Strike of F",
            "Strike of F+1",
            "Strike of G-1",
            "Strike of G",
            "Strike of G+1",
            "Strike of H-1",
            "Strike of H",
            "Strike of H+1",
            "Strike of I-1",
            "Strike of I",
            "Strike of I+1",
            "Strike of J-1",
            "Strike of J",
            "Strike of J+1"});
            this.wizardStrike2Column.Name = "wizardStrike2Column";
            this.wizardStrike2Column.ReadOnly = true;
            this.wizardStrike2Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardStrike2Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardStrike2Column.Width = 103;
            // 
            // wizardExpirationSign1Column
            // 
            this.wizardExpirationSign1Column.DataPropertyName = "ExpirationSign1";
            this.wizardExpirationSign1Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardExpirationSign1Column.HeaderText = "1st";
            this.wizardExpirationSign1Column.Items.AddRange(new object[] {
            global::OptionsOracle.Properties.Resources.AppCustomizationMode,
            "<",
            "<=",
            "=",
            ">=",
            ">",
            "<>"});
            this.wizardExpirationSign1Column.Name = "wizardExpirationSign1Column";
            this.wizardExpirationSign1Column.ReadOnly = true;
            this.wizardExpirationSign1Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardExpirationSign1Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardExpirationSign1Column.Width = 45;
            // 
            // wizardExpiration1Column
            // 
            this.wizardExpiration1Column.DataPropertyName = "Expiration1";
            this.wizardExpiration1Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardExpiration1Column.HeaderText = "Expiration Rule";
            this.wizardExpiration1Column.Items.AddRange(new object[] {
            "Manual End-Date",
            "Expiration of A-1",
            "Expiration of A",
            "Expiration of A+1",
            "Expiration of B-1",
            "Expiration of B",
            "Expiration of B+1",
            "Expiration of C-1",
            "Expiration of C",
            "Expiration of C+1",
            "Expiration of D-1",
            "Expiration of D",
            "Expiration of D+1",
            "Expiration of E-1",
            "Expiration of E",
            "Expiration of E+1",
            "Expiration of F-1",
            "Expiration of F",
            "Expiration of F+1",
            "Expiration of G-1",
            "Expiration of G",
            "Expiration of G+1",
            "Expiration of H-1",
            "Expiration of H",
            "Expiration of H+1",
            "Expiration of I-1",
            "Expiration of I",
            "Expiration of I+1",
            "Expiration of J-1",
            "Expiration of J",
            "Expiration of J+1",
            "Expiration 1",
            "Expiration 2",
            "Expiration 3",
            "Expiration 4",
            "Expiration 5",
            "Expiration 6",
            "Expiration 7",
            "Expiration 8"});
            this.wizardExpiration1Column.Name = "wizardExpiration1Column";
            this.wizardExpiration1Column.ReadOnly = true;
            this.wizardExpiration1Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardExpiration1Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardExpiration1Column.Width = 110;
            // 
            // wizardExpirationSign2Column
            // 
            this.wizardExpirationSign2Column.DataPropertyName = "ExpirationSign2";
            this.wizardExpirationSign2Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardExpirationSign2Column.HeaderText = "2nd";
            this.wizardExpirationSign2Column.Items.AddRange(new object[] {
            global::OptionsOracle.Properties.Resources.AppCustomizationMode,
            "<",
            "<=",
            "=",
            ">=",
            ">",
            "<>"});
            this.wizardExpirationSign2Column.Name = "wizardExpirationSign2Column";
            this.wizardExpirationSign2Column.ReadOnly = true;
            this.wizardExpirationSign2Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardExpirationSign2Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardExpirationSign2Column.Width = 45;
            // 
            // wizardExpiration2Column
            // 
            this.wizardExpiration2Column.DataPropertyName = "Expiration2";
            this.wizardExpiration2Column.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.wizardExpiration2Column.HeaderText = "Expiration Rule";
            this.wizardExpiration2Column.Items.AddRange(new object[] {
            "Manual End-Date",
            "Expiration of A-1",
            "Expiration of A",
            "Expiration of A+1",
            "Expiration of B-1",
            "Expiration of B",
            "Expiration of B+1",
            "Expiration of C-1",
            "Expiration of C",
            "Expiration of C+1",
            "Expiration of D-1",
            "Expiration of D",
            "Expiration of D+1",
            "Expiration of E-1",
            "Expiration of E",
            "Expiration of E+1",
            "Expiration of F-1",
            "Expiration of F",
            "Expiration of F+1",
            "Expiration of G-1",
            "Expiration of G",
            "Expiration of G+1",
            "Expiration of H-1",
            "Expiration of H",
            "Expiration of H+1",
            "Expiration of I-1",
            "Expiration of I",
            "Expiration of I+1",
            "Expiration of J-1",
            "Expiration of J",
            "Expiration of J+1",
            "Expiration 1",
            "Expiration 2",
            "Expiration 3",
            "Expiration 4",
            "Expiration 5",
            "Expiration 6",
            "Expiration 7",
            "Expiration 8"});
            this.wizardExpiration2Column.Name = "wizardExpiration2Column";
            this.wizardExpiration2Column.ReadOnly = true;
            this.wizardExpiration2Column.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.wizardExpiration2Column.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.wizardExpiration2Column.Width = 110;
            // 
            // wizardTableBindingSource
            // 
            this.wizardTableBindingSource.DataMember = "WizardTable";
            this.wizardTableBindingSource.DataSource = this.wizardSet;
            // 
            // wizardSet
            // 
            this.wizardSet.DataSetName = "WizardSet";
            this.wizardSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox4
            // 
            this.groupBox4.ForeColor = System.Drawing.Color.SlateGray;
            this.groupBox4.Location = new System.Drawing.Point(646, 64);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(117, 17);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "  Expiration Rule #2  ";
            // 
            // groupBox5
            // 
            this.groupBox5.ForeColor = System.Drawing.Color.SlateGray;
            this.groupBox5.Location = new System.Drawing.Point(490, 64);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(117, 17);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "  Expiration Rule #1 ";
            // 
            // groupBox6
            // 
            this.groupBox6.ForeColor = System.Drawing.Color.SlateGray;
            this.groupBox6.Location = new System.Drawing.Point(334, 64);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(117, 17);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Strike Price Rule #2";
            // 
            // groupBox7
            // 
            this.groupBox7.ForeColor = System.Drawing.Color.SlateGray;
            this.groupBox7.Location = new System.Drawing.Point(187, 64);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(117, 17);
            this.groupBox7.TabIndex = 0;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Strike Price Rule #1";
            // 
            // strategyTabControl
            // 
            this.strategyTabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.strategyTabControl.Controls.Add(this.tabStrategy1);
            this.strategyTabControl.Controls.Add(this.tabStrategy2);
            this.strategyTabControl.Controls.Add(this.tabStrategy3);
            this.strategyTabControl.Controls.Add(this.tabStrategy4);
            this.strategyTabControl.Location = new System.Drawing.Point(8, 64);
            this.strategyTabControl.Name = "strategyTabControl";
            this.strategyTabControl.SelectedIndex = 0;
            this.strategyTabControl.Size = new System.Drawing.Size(769, 21);
            this.strategyTabControl.TabIndex = 12;
            this.strategyTabControl.SelectedIndexChanged += new System.EventHandler(this.strategyTabControl_SelectedIndexChanged);
            // 
            // tabStrategy1
            // 
            this.tabStrategy1.Location = new System.Drawing.Point(4, 22);
            this.tabStrategy1.Name = "tabStrategy1";
            this.tabStrategy1.Padding = new System.Windows.Forms.Padding(3);
            this.tabStrategy1.Size = new System.Drawing.Size(761, 0);
            this.tabStrategy1.TabIndex = 0;
            this.tabStrategy1.Text = "1";
            this.tabStrategy1.UseVisualStyleBackColor = true;
            // 
            // tabStrategy2
            // 
            this.tabStrategy2.Location = new System.Drawing.Point(4, 22);
            this.tabStrategy2.Name = "tabStrategy2";
            this.tabStrategy2.Padding = new System.Windows.Forms.Padding(3);
            this.tabStrategy2.Size = new System.Drawing.Size(761, 0);
            this.tabStrategy2.TabIndex = 1;
            this.tabStrategy2.Text = "2";
            this.tabStrategy2.UseVisualStyleBackColor = true;
            // 
            // tabStrategy3
            // 
            this.tabStrategy3.Location = new System.Drawing.Point(4, 22);
            this.tabStrategy3.Name = "tabStrategy3";
            this.tabStrategy3.Size = new System.Drawing.Size(761, 0);
            this.tabStrategy3.TabIndex = 2;
            this.tabStrategy3.Text = "3";
            this.tabStrategy3.UseVisualStyleBackColor = true;
            // 
            // tabStrategy4
            // 
            this.tabStrategy4.Location = new System.Drawing.Point(4, 22);
            this.tabStrategy4.Name = "tabStrategy4";
            this.tabStrategy4.Size = new System.Drawing.Size(761, 0);
            this.tabStrategy4.TabIndex = 3;
            this.tabStrategy4.Text = "4";
            this.tabStrategy4.UseVisualStyleBackColor = true;
            // 
            // endDateManualLabel
            // 
            this.endDateManualLabel.AutoSize = true;
            this.endDateManualLabel.Enabled = false;
            this.endDateManualLabel.Location = new System.Drawing.Point(433, 17);
            this.endDateManualLabel.Name = "endDateManualLabel";
            this.endDateManualLabel.Size = new System.Drawing.Size(93, 13);
            this.endDateManualLabel.TabIndex = 0;
            this.endDateManualLabel.Text = "Manual End-Date:";
            // 
            // investmentSizeManualLabel
            // 
            this.investmentSizeManualLabel.AutoSize = true;
            this.investmentSizeManualLabel.Enabled = false;
            this.investmentSizeManualLabel.Location = new System.Drawing.Point(678, 16);
            this.investmentSizeManualLabel.Name = "investmentSizeManualLabel";
            this.investmentSizeManualLabel.Size = new System.Drawing.Size(34, 13);
            this.investmentSizeManualLabel.TabIndex = 0;
            this.investmentSizeManualLabel.Text = "Total:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(540, 16);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(85, 13);
            this.label29.TabIndex = 0;
            this.label29.Text = "Investment Size:";
            // 
            // investmentSizeModeComboBox
            // 
            this.investmentSizeModeComboBox.FormattingEnabled = true;
            this.investmentSizeModeComboBox.Items.AddRange(new object[] {
            "Fix Quantities",
            "Fix Total"});
            this.investmentSizeModeComboBox.Location = new System.Drawing.Point(543, 32);
            this.investmentSizeModeComboBox.Name = "investmentSizeModeComboBox";
            this.investmentSizeModeComboBox.Size = new System.Drawing.Size(135, 21);
            this.investmentSizeModeComboBox.TabIndex = 4;
            this.investmentSizeModeComboBox.SelectedIndexChanged += new System.EventHandler(this.xxComboBox_SelectedIndexChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(295, 16);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(55, 13);
            this.label28.TabIndex = 0;
            this.label28.Text = "End-Date:";
            // 
            // endDateModeComboBox
            // 
            this.endDateModeComboBox.FormattingEnabled = true;
            this.endDateModeComboBox.Items.AddRange(new object[] {
            "Auto",
            "Manual"});
            this.endDateModeComboBox.Location = new System.Drawing.Point(298, 32);
            this.endDateModeComboBox.Name = "endDateModeComboBox";
            this.endDateModeComboBox.Size = new System.Drawing.Size(135, 21);
            this.endDateModeComboBox.TabIndex = 2;
            this.endDateModeComboBox.SelectedIndexChanged += new System.EventHandler(this.xxComboBox_SelectedIndexChanged);
            // 
            // loadButton
            // 
            this.loadButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.loadButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.loadButton.Location = new System.Drawing.Point(687, 246);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(90, 24);
            this.loadButton.TabIndex = 10;
            this.loadButton.Text = "Load Strategy";
            this.loadButton.UseVisualStyleBackColor = true;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.saveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveButton.Location = new System.Drawing.Point(687, 274);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(90, 24);
            this.saveButton.TabIndex = 11;
            this.saveButton.Text = "Save Strategy";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // investmentSizeManualNumericUpDown
            // 
            this.investmentSizeManualNumericUpDown.Enabled = false;
            this.investmentSizeManualNumericUpDown.Increment = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.investmentSizeManualNumericUpDown.Location = new System.Drawing.Point(681, 33);
            this.investmentSizeManualNumericUpDown.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.investmentSizeManualNumericUpDown.Name = "investmentSizeManualNumericUpDown";
            this.investmentSizeManualNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.investmentSizeManualNumericUpDown.TabIndex = 5;
            this.investmentSizeManualNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.investmentSizeManualNumericUpDown.ThousandsSeparator = true;
            this.investmentSizeManualNumericUpDown.Value = new decimal(new int[] {
            2500,
            0,
            0,
            0});
            // 
            // addRowbutton
            // 
            this.addRowbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addRowbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addRowbutton.Location = new System.Drawing.Point(104, 246);
            this.addRowbutton.Name = "addRowbutton";
            this.addRowbutton.Size = new System.Drawing.Size(90, 24);
            this.addRowbutton.TabIndex = 9;
            this.addRowbutton.Text = "Add Row";
            this.addRowbutton.UseVisualStyleBackColor = true;
            this.addRowbutton.Click += new System.EventHandler(this.addRowbutton_Click);
            // 
            // deleteRowbutton
            // 
            this.deleteRowbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.deleteRowbutton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.deleteRowbutton.Location = new System.Drawing.Point(104, 274);
            this.deleteRowbutton.Name = "deleteRowbutton";
            this.deleteRowbutton.Size = new System.Drawing.Size(90, 24);
            this.deleteRowbutton.TabIndex = 8;
            this.deleteRowbutton.Text = "Delete Row";
            this.deleteRowbutton.UseVisualStyleBackColor = true;
            this.deleteRowbutton.Click += new System.EventHandler(this.deleteRowbutton_Click);
            // 
            // clearPositionButton
            // 
            this.clearPositionButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.clearPositionButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearPositionButton.Location = new System.Drawing.Point(8, 274);
            this.clearPositionButton.Name = "clearPositionButton";
            this.clearPositionButton.Size = new System.Drawing.Size(90, 24);
            this.clearPositionButton.TabIndex = 7;
            this.clearPositionButton.Text = "Delete Strategy";
            this.clearPositionButton.UseVisualStyleBackColor = true;
            this.clearPositionButton.Click += new System.EventHandler(this.clearPositionButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Select pre-configured stategy:";
            // 
            // endDateManualDateTimePicker
            // 
            this.endDateManualDateTimePicker.CalendarForeColor = System.Drawing.Color.Cornsilk;
            this.endDateManualDateTimePicker.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(0)))));
            this.endDateManualDateTimePicker.CalendarTitleBackColor = System.Drawing.Color.DarkSeaGreen;
            this.endDateManualDateTimePicker.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.endDateManualDateTimePicker.CalendarTrailingForeColor = System.Drawing.Color.LightGray;
            this.endDateManualDateTimePicker.CustomFormat = "d-MMM-yyyy";
            this.endDateManualDateTimePicker.Enabled = false;
            this.endDateManualDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.endDateManualDateTimePicker.Location = new System.Drawing.Point(436, 33);
            this.endDateManualDateTimePicker.Name = "endDateManualDateTimePicker";
            this.endDateManualDateTimePicker.Size = new System.Drawing.Size(97, 20);
            this.endDateManualDateTimePicker.TabIndex = 3;
            this.endDateManualDateTimePicker.ValueChanged += new System.EventHandler(this.endDateManualDateTimePicker_ValueChanged);
            // 
            // wizardControl
            // 
            this.wizardControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.wizardControl.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.wizardControl.Controls.Add(this.tabPage1);
            this.wizardControl.Controls.Add(this.tabPage2);
            this.wizardControl.Controls.Add(this.tabPage3);
            this.wizardControl.Controls.Add(this.tabPage4);
            this.wizardControl.Controls.Add(this.tabPage5);
            this.wizardControl.Controls.Add(this.tabPage6);
            this.wizardControl.Controls.Add(this.tabPage7);
            this.wizardControl.Controls.Add(this.tabPage8);
            this.wizardControl.Location = new System.Drawing.Point(2, 2);
            this.wizardControl.Name = "wizardControl";
            this.wizardControl.SelectedIndex = 0;
            this.wizardControl.Size = new System.Drawing.Size(797, 413);
            this.wizardControl.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.wizardControl.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.stockListGroupBox);
            this.tabPage1.Controls.Add(this.infoLabel);
            this.tabPage1.Controls.Add(this.welcomeLabel);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(789, 384);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(5, 68);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(183, 14);
            this.label31.TabIndex = 0;
            this.label31.Text = "Step 1: Enter Stock Symbols";
            // 
            // stockListGroupBox
            // 
            this.stockListGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.stockListGroupBox.Controls.Add(this.quickGetButton);
            this.stockListGroupBox.Controls.Add(this.clearListButton);
            this.stockListGroupBox.Controls.Add(this.loadListButton);
            this.stockListGroupBox.Controls.Add(this.saveListButton);
            this.stockListGroupBox.Controls.Add(this.label2);
            this.stockListGroupBox.Controls.Add(this.stocksListTextBox);
            this.stockListGroupBox.Controls.Add(this.label1);
            this.stockListGroupBox.Location = new System.Drawing.Point(3, 92);
            this.stockListGroupBox.Name = "stockListGroupBox";
            this.stockListGroupBox.Size = new System.Drawing.Size(783, 147);
            this.stockListGroupBox.TabIndex = 0;
            this.stockListGroupBox.TabStop = false;
            this.stockListGroupBox.Text = "Stock List";
            // 
            // quickGetButton
            // 
            this.quickGetButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.quickGetButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.quickGetButton.Location = new System.Drawing.Point(591, 114);
            this.quickGetButton.Name = "quickGetButton";
            this.quickGetButton.Size = new System.Drawing.Size(90, 24);
            this.quickGetButton.TabIndex = 5;
            this.quickGetButton.Text = "Quick Add..";
            this.quickGetButton.UseVisualStyleBackColor = true;
            this.quickGetButton.Visible = false;
            this.quickGetButton.Click += new System.EventHandler(this.quickGetButton_Click);
            // 
            // clearListButton
            // 
            this.clearListButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.clearListButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clearListButton.Location = new System.Drawing.Point(591, 86);
            this.clearListButton.Name = "clearListButton";
            this.clearListButton.Size = new System.Drawing.Size(90, 24);
            this.clearListButton.TabIndex = 2;
            this.clearListButton.Text = "Clear";
            this.clearListButton.UseVisualStyleBackColor = true;
            this.clearListButton.Click += new System.EventHandler(this.clearListButton_Click);
            // 
            // loadListButton
            // 
            this.loadListButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.loadListButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.loadListButton.Location = new System.Drawing.Point(687, 86);
            this.loadListButton.Name = "loadListButton";
            this.loadListButton.Size = new System.Drawing.Size(90, 24);
            this.loadListButton.TabIndex = 3;
            this.loadListButton.Text = "Load";
            this.loadListButton.UseVisualStyleBackColor = true;
            this.loadListButton.Click += new System.EventHandler(this.loadListButton_Click);
            // 
            // saveListButton
            // 
            this.saveListButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.saveListButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.saveListButton.Location = new System.Drawing.Point(687, 114);
            this.saveListButton.Name = "saveListButton";
            this.saveListButton.Size = new System.Drawing.Size(90, 24);
            this.saveListButton.TabIndex = 4;
            this.saveListButton.Text = "Save";
            this.saveListButton.UseVisualStyleBackColor = true;
            this.saveListButton.Click += new System.EventHandler(this.saveListButton_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(572, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "* enter stocks-symbols seperated by commas (e.g. MSFT,CSCO,NVDA). Each download s" +
                "ession is limited to 50 symbols.";
            // 
            // stocksListTextBox
            // 
            this.stocksListTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.stocksListTextBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.stocksListTextBox.Location = new System.Drawing.Point(6, 32);
            this.stocksListTextBox.Multiline = true;
            this.stocksListTextBox.Name = "stocksListTextBox";
            this.stocksListTextBox.Size = new System.Drawing.Size(771, 48);
            this.stocksListTextBox.TabIndex = 1;
            this.stocksListTextBox.TextChanged += new System.EventHandler(this.stocksListTextBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "List of stocks: ( * )";
            // 
            // infoLabel
            // 
            this.infoLabel.AutoSize = true;
            this.infoLabel.Location = new System.Drawing.Point(6, 25);
            this.infoLabel.Name = "infoLabel";
            this.infoLabel.Size = new System.Drawing.Size(778, 26);
            this.infoLabel.TabIndex = 0;
            this.infoLabel.Text = "The strategy wizard provides the ability to download one or more stocks data, and" +
                " test built-in or customized strategies on all possible combinations (all stocks" +
                " and all\r\noptions of each stock).\r\n";
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.welcomeLabel.Location = new System.Drawing.Point(5, 3);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(218, 14);
            this.welcomeLabel.TabIndex = 0;
            this.welcomeLabel.Text = "Welcome to OptionsOracle Wizard!\r\n";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.strategyGroup);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(789, 384);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(5, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(188, 14);
            this.label6.TabIndex = 0;
            this.label6.Text = "Step 2: Select your Strategy!";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox14);
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.expirationFilterGroupBox);
            this.tabPage3.Controls.Add(this.groupBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(789, 384);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox14
            // 
            this.groupBox14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox14.Controls.Add(this.duplicateOptionsFilterCheckBox);
            this.groupBox14.Controls.Add(this.askBidFilterCheckBox);
            this.groupBox14.Controls.Add(this.impVolFilterCheckBox);
            this.groupBox14.Location = new System.Drawing.Point(392, 175);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(394, 66);
            this.groupBox14.TabIndex = 1;
            this.groupBox14.TabStop = false;
            // 
            // duplicateOptionsFilterCheckBox
            // 
            this.duplicateOptionsFilterCheckBox.AutoSize = true;
            this.duplicateOptionsFilterCheckBox.Checked = true;
            this.duplicateOptionsFilterCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.duplicateOptionsFilterCheckBox.Location = new System.Drawing.Point(232, 19);
            this.duplicateOptionsFilterCheckBox.Name = "duplicateOptionsFilterCheckBox";
            this.duplicateOptionsFilterCheckBox.Size = new System.Drawing.Size(152, 17);
            this.duplicateOptionsFilterCheckBox.TabIndex = 23;
            this.duplicateOptionsFilterCheckBox.Text = "Only options w/o duplicate";
            this.duplicateOptionsFilterCheckBox.UseVisualStyleBackColor = true;
            // 
            // askBidFilterCheckBox
            // 
            this.askBidFilterCheckBox.AutoSize = true;
            this.askBidFilterCheckBox.Checked = true;
            this.askBidFilterCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.askBidFilterCheckBox.Location = new System.Drawing.Point(11, 19);
            this.askBidFilterCheckBox.Name = "askBidFilterCheckBox";
            this.askBidFilterCheckBox.Size = new System.Drawing.Size(183, 17);
            this.askBidFilterCheckBox.TabIndex = 12;
            this.askBidFilterCheckBox.Text = "Only options with ask && bid prices";
            this.askBidFilterCheckBox.UseVisualStyleBackColor = true;
            // 
            // impVolFilterCheckBox
            // 
            this.impVolFilterCheckBox.AutoSize = true;
            this.impVolFilterCheckBox.Checked = true;
            this.impVolFilterCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.impVolFilterCheckBox.Location = new System.Drawing.Point(11, 42);
            this.impVolFilterCheckBox.Name = "impVolFilterCheckBox";
            this.impVolFilterCheckBox.Size = new System.Drawing.Size(212, 17);
            this.impVolFilterCheckBox.TabIndex = 23;
            this.impVolFilterCheckBox.Text = "Only options with implied volatility prices";
            this.impVolFilterCheckBox.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox9.Controls.Add(this.historicalVolNotePanel);
            this.groupBox9.Controls.Add(this.stockMaxVolRatioNumericUpDown);
            this.groupBox9.Controls.Add(this.stockMinVolRatioNumericUpDown);
            this.groupBox9.Controls.Add(this.label40);
            this.groupBox9.Controls.Add(this.label41);
            this.groupBox9.Controls.Add(this.stockVolRatioFilterCheckBox);
            this.groupBox9.Controls.Add(this.stockMaxHisVolNumericUpDown);
            this.groupBox9.Controls.Add(this.stockMinHisVolNumericUpDown);
            this.groupBox9.Controls.Add(this.label38);
            this.groupBox9.Controls.Add(this.label39);
            this.groupBox9.Controls.Add(this.stockHisVolFilterCheckBox);
            this.groupBox9.Controls.Add(this.stockMaxImpVolNumericUpDown);
            this.groupBox9.Controls.Add(this.stockMinImpVolNumericUpDown);
            this.groupBox9.Controls.Add(this.label32);
            this.groupBox9.Controls.Add(this.label37);
            this.groupBox9.Controls.Add(this.stockImpVolFilterCheckBox);
            this.groupBox9.Location = new System.Drawing.Point(3, 246);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(783, 95);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Stock Volatility Filter";
            // 
            // historicalVolNotePanel
            // 
            this.historicalVolNotePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.historicalVolNotePanel.Controls.Add(this.label42);
            this.historicalVolNotePanel.Location = new System.Drawing.Point(495, 18);
            this.historicalVolNotePanel.Name = "historicalVolNotePanel";
            this.historicalVolNotePanel.Size = new System.Drawing.Size(282, 45);
            this.historicalVolNotePanel.TabIndex = 0;
            this.historicalVolNotePanel.Visible = false;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(9, 8);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(268, 26);
            this.label42.TabIndex = 64;
            this.label42.Text = "Note: Historical volatility is NOT supported by the static \r\nservers and most of " +
                "the non-US dynamic servers.";
            // 
            // stockMaxVolRatioNumericUpDown
            // 
            this.stockMaxVolRatioNumericUpDown.DecimalPlaces = 2;
            this.stockMaxVolRatioNumericUpDown.Enabled = false;
            this.stockMaxVolRatioNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMaxVolRatioNumericUpDown.Location = new System.Drawing.Point(332, 67);
            this.stockMaxVolRatioNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMaxVolRatioNumericUpDown.Name = "stockMaxVolRatioNumericUpDown";
            this.stockMaxVolRatioNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMaxVolRatioNumericUpDown.TabIndex = 31;
            this.stockMaxVolRatioNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMaxVolRatioNumericUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // stockMinVolRatioNumericUpDown
            // 
            this.stockMinVolRatioNumericUpDown.DecimalPlaces = 2;
            this.stockMinVolRatioNumericUpDown.Enabled = false;
            this.stockMinVolRatioNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMinVolRatioNumericUpDown.Location = new System.Drawing.Point(215, 68);
            this.stockMinVolRatioNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMinVolRatioNumericUpDown.Name = "stockMinVolRatioNumericUpDown";
            this.stockMinVolRatioNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.stockMinVolRatioNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMinVolRatioNumericUpDown.TabIndex = 30;
            this.stockMinVolRatioNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMinVolRatioNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(433, 69);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(27, 13);
            this.label40.TabIndex = 0;
            this.label40.Text = "[ % ]";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(316, 69);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(10, 13);
            this.label41.TabIndex = 0;
            this.label41.Text = "-";
            // 
            // stockVolRatioFilterCheckBox
            // 
            this.stockVolRatioFilterCheckBox.AutoSize = true;
            this.stockVolRatioFilterCheckBox.Location = new System.Drawing.Point(9, 71);
            this.stockVolRatioFilterCheckBox.Name = "stockVolRatioFilterCheckBox";
            this.stockVolRatioFilterCheckBox.Size = new System.Drawing.Size(207, 17);
            this.stockVolRatioFilterCheckBox.TabIndex = 29;
            this.stockVolRatioFilterCheckBox.Text = "Stock Impiled/Historical Volatility Ratio";
            this.stockVolRatioFilterCheckBox.UseVisualStyleBackColor = true;
            this.stockVolRatioFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // stockMaxHisVolNumericUpDown
            // 
            this.stockMaxHisVolNumericUpDown.DecimalPlaces = 2;
            this.stockMaxHisVolNumericUpDown.Enabled = false;
            this.stockMaxHisVolNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMaxHisVolNumericUpDown.Location = new System.Drawing.Point(332, 42);
            this.stockMaxHisVolNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMaxHisVolNumericUpDown.Name = "stockMaxHisVolNumericUpDown";
            this.stockMaxHisVolNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMaxHisVolNumericUpDown.TabIndex = 28;
            this.stockMaxHisVolNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMaxHisVolNumericUpDown.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            // 
            // stockMinHisVolNumericUpDown
            // 
            this.stockMinHisVolNumericUpDown.DecimalPlaces = 2;
            this.stockMinHisVolNumericUpDown.Enabled = false;
            this.stockMinHisVolNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMinHisVolNumericUpDown.Location = new System.Drawing.Point(215, 43);
            this.stockMinHisVolNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMinHisVolNumericUpDown.Name = "stockMinHisVolNumericUpDown";
            this.stockMinHisVolNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.stockMinHisVolNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMinHisVolNumericUpDown.TabIndex = 27;
            this.stockMinHisVolNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(433, 44);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(27, 13);
            this.label38.TabIndex = 0;
            this.label38.Text = "[ % ]";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(316, 44);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(10, 13);
            this.label39.TabIndex = 0;
            this.label39.Text = "-";
            // 
            // stockHisVolFilterCheckBox
            // 
            this.stockHisVolFilterCheckBox.AutoSize = true;
            this.stockHisVolFilterCheckBox.Location = new System.Drawing.Point(9, 46);
            this.stockHisVolFilterCheckBox.Name = "stockHisVolFilterCheckBox";
            this.stockHisVolFilterCheckBox.Size = new System.Drawing.Size(176, 17);
            this.stockHisVolFilterCheckBox.TabIndex = 26;
            this.stockHisVolFilterCheckBox.Text = "Stock Historical Volatility Range";
            this.stockHisVolFilterCheckBox.UseVisualStyleBackColor = true;
            this.stockHisVolFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // stockMaxImpVolNumericUpDown
            // 
            this.stockMaxImpVolNumericUpDown.DecimalPlaces = 2;
            this.stockMaxImpVolNumericUpDown.Enabled = false;
            this.stockMaxImpVolNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMaxImpVolNumericUpDown.Location = new System.Drawing.Point(332, 17);
            this.stockMaxImpVolNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMaxImpVolNumericUpDown.Name = "stockMaxImpVolNumericUpDown";
            this.stockMaxImpVolNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMaxImpVolNumericUpDown.TabIndex = 25;
            this.stockMaxImpVolNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMaxImpVolNumericUpDown.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            // 
            // stockMinImpVolNumericUpDown
            // 
            this.stockMinImpVolNumericUpDown.DecimalPlaces = 2;
            this.stockMinImpVolNumericUpDown.Enabled = false;
            this.stockMinImpVolNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMinImpVolNumericUpDown.Location = new System.Drawing.Point(215, 18);
            this.stockMinImpVolNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMinImpVolNumericUpDown.Name = "stockMinImpVolNumericUpDown";
            this.stockMinImpVolNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.stockMinImpVolNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMinImpVolNumericUpDown.TabIndex = 24;
            this.stockMinImpVolNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(433, 19);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(27, 13);
            this.label32.TabIndex = 0;
            this.label32.Text = "[ % ]";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(316, 19);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(10, 13);
            this.label37.TabIndex = 0;
            this.label37.Text = "-";
            // 
            // stockImpVolFilterCheckBox
            // 
            this.stockImpVolFilterCheckBox.AutoSize = true;
            this.stockImpVolFilterCheckBox.Location = new System.Drawing.Point(9, 21);
            this.stockImpVolFilterCheckBox.Name = "stockImpVolFilterCheckBox";
            this.stockImpVolFilterCheckBox.Size = new System.Drawing.Size(166, 17);
            this.stockImpVolFilterCheckBox.TabIndex = 23;
            this.stockImpVolFilterCheckBox.Text = "Stock Implied Volatility Range";
            this.stockImpVolFilterCheckBox.UseVisualStyleBackColor = true;
            this.stockImpVolFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.maxResultsNumericUpDown);
            this.groupBox2.Controls.Add(this.maxResultsFilterCheckBox);
            this.groupBox2.Controls.Add(this.groupBox13);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.minOpenIntNumericUpDown);
            this.groupBox2.Controls.Add(this.openIntFilterCheckBox);
            this.groupBox2.Location = new System.Drawing.Point(3, 175);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(383, 67);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Options Data Filter";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(316, 44);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(49, 13);
            this.label22.TabIndex = 23;
            this.label22.Text = "[ results ]";
            // 
            // maxResultsNumericUpDown
            // 
            this.maxResultsNumericUpDown.Enabled = false;
            this.maxResultsNumericUpDown.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.maxResultsNumericUpDown.Location = new System.Drawing.Point(215, 40);
            this.maxResultsNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.maxResultsNumericUpDown.Name = "maxResultsNumericUpDown";
            this.maxResultsNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maxResultsNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.maxResultsNumericUpDown.TabIndex = 25;
            this.maxResultsNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.maxResultsNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // maxResultsFilterCheckBox
            // 
            this.maxResultsFilterCheckBox.AutoSize = true;
            this.maxResultsFilterCheckBox.Checked = true;
            this.maxResultsFilterCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.maxResultsFilterCheckBox.Location = new System.Drawing.Point(9, 43);
            this.maxResultsFilterCheckBox.Name = "maxResultsFilterCheckBox";
            this.maxResultsFilterCheckBox.Size = new System.Drawing.Size(150, 17);
            this.maxResultsFilterCheckBox.TabIndex = 24;
            this.maxResultsFilterCheckBox.Text = "Maximum results per-stock";
            this.maxResultsFilterCheckBox.UseVisualStyleBackColor = true;
            this.maxResultsFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // groupBox13
            // 
            this.groupBox13.Location = new System.Drawing.Point(444, 0);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(339, 67);
            this.groupBox13.TabIndex = 1;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Option Data Filter";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(316, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "[ contracts ]";
            // 
            // minOpenIntNumericUpDown
            // 
            this.minOpenIntNumericUpDown.Enabled = false;
            this.minOpenIntNumericUpDown.Increment = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.minOpenIntNumericUpDown.Location = new System.Drawing.Point(215, 16);
            this.minOpenIntNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.minOpenIntNumericUpDown.Name = "minOpenIntNumericUpDown";
            this.minOpenIntNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.minOpenIntNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.minOpenIntNumericUpDown.TabIndex = 22;
            this.minOpenIntNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.minOpenIntNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // openIntFilterCheckBox
            // 
            this.openIntFilterCheckBox.AutoSize = true;
            this.openIntFilterCheckBox.Checked = true;
            this.openIntFilterCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.openIntFilterCheckBox.Location = new System.Drawing.Point(9, 19);
            this.openIntFilterCheckBox.Name = "openIntFilterCheckBox";
            this.openIntFilterCheckBox.Size = new System.Drawing.Size(131, 17);
            this.openIntFilterCheckBox.TabIndex = 21;
            this.openIntFilterCheckBox.Text = "Minimum open interest";
            this.openIntFilterCheckBox.UseVisualStyleBackColor = true;
            this.openIntFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(215, 14);
            this.label7.TabIndex = 0;
            this.label7.Text = "Step 3: Setup Wizard Filters (1/2)";
            // 
            // expirationFilterGroupBox
            // 
            this.expirationFilterGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.expirationFilterGroupBox.Controls.Add(this.label9);
            this.expirationFilterGroupBox.Controls.Add(this.expFilterCheckBox);
            this.expirationFilterGroupBox.Controls.Add(this.maxExpDateTimePicker);
            this.expirationFilterGroupBox.Controls.Add(this.minExpDateTimePicker);
            this.expirationFilterGroupBox.Location = new System.Drawing.Point(3, 25);
            this.expirationFilterGroupBox.Name = "expirationFilterGroupBox";
            this.expirationFilterGroupBox.Size = new System.Drawing.Size(783, 45);
            this.expirationFilterGroupBox.TabIndex = 0;
            this.expirationFilterGroupBox.TabStop = false;
            this.expirationFilterGroupBox.Text = "Options Expiration Date Filter";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(316, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(10, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "-";
            // 
            // expFilterCheckBox
            // 
            this.expFilterCheckBox.AutoSize = true;
            this.expFilterCheckBox.Location = new System.Drawing.Point(9, 20);
            this.expFilterCheckBox.Name = "expFilterCheckBox";
            this.expFilterCheckBox.Size = new System.Drawing.Size(126, 17);
            this.expFilterCheckBox.TabIndex = 12;
            this.expFilterCheckBox.Text = "Expiration date range";
            this.expFilterCheckBox.UseVisualStyleBackColor = true;
            this.expFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // maxExpDateTimePicker
            // 
            this.maxExpDateTimePicker.CalendarForeColor = System.Drawing.Color.Cornsilk;
            this.maxExpDateTimePicker.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(0)))));
            this.maxExpDateTimePicker.CalendarTitleBackColor = System.Drawing.Color.DarkSeaGreen;
            this.maxExpDateTimePicker.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.maxExpDateTimePicker.CalendarTrailingForeColor = System.Drawing.Color.LightGray;
            this.maxExpDateTimePicker.CustomFormat = "d-MMM-yyyy";
            this.maxExpDateTimePicker.Enabled = false;
            this.maxExpDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.maxExpDateTimePicker.Location = new System.Drawing.Point(332, 17);
            this.maxExpDateTimePicker.Name = "maxExpDateTimePicker";
            this.maxExpDateTimePicker.Size = new System.Drawing.Size(95, 20);
            this.maxExpDateTimePicker.TabIndex = 14;
            // 
            // minExpDateTimePicker
            // 
            this.minExpDateTimePicker.CalendarForeColor = System.Drawing.Color.Cornsilk;
            this.minExpDateTimePicker.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(0)))));
            this.minExpDateTimePicker.CalendarTitleBackColor = System.Drawing.Color.DarkSeaGreen;
            this.minExpDateTimePicker.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.minExpDateTimePicker.CalendarTrailingForeColor = System.Drawing.Color.LightGray;
            this.minExpDateTimePicker.CustomFormat = "d-MMM-yyyy";
            this.minExpDateTimePicker.Enabled = false;
            this.minExpDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.minExpDateTimePicker.Location = new System.Drawing.Point(215, 17);
            this.minExpDateTimePicker.Name = "minExpDateTimePicker";
            this.minExpDateTimePicker.Size = new System.Drawing.Size(95, 20);
            this.minExpDateTimePicker.TabIndex = 13;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.stockMaxPriceNumericUpDown);
            this.groupBox1.Controls.Add(this.stockMinPriceNumericUpDown);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.stockPriceFilterCheckBox);
            this.groupBox1.Controls.Add(this.otmMaxStrikeNumericUpDown);
            this.groupBox1.Controls.Add(this.itmMaxStrikeNumericUpDown);
            this.groupBox1.Controls.Add(this.otmMinStrikeNumericUpDown);
            this.groupBox1.Controls.Add(this.itmMinStrikeNumericUpDown);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.otmStrikeFilterCheckBox);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.itmStrikeFilterCheckBox);
            this.groupBox1.Location = new System.Drawing.Point(3, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(783, 99);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options-Strike and Stock-Price Filter ";
            // 
            // stockMaxPriceNumericUpDown
            // 
            this.stockMaxPriceNumericUpDown.DecimalPlaces = 2;
            this.stockMaxPriceNumericUpDown.Enabled = false;
            this.stockMaxPriceNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMaxPriceNumericUpDown.Location = new System.Drawing.Point(332, 69);
            this.stockMaxPriceNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMaxPriceNumericUpDown.Name = "stockMaxPriceNumericUpDown";
            this.stockMaxPriceNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMaxPriceNumericUpDown.TabIndex = 45;
            this.stockMaxPriceNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMaxPriceNumericUpDown.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // stockMinPriceNumericUpDown
            // 
            this.stockMinPriceNumericUpDown.DecimalPlaces = 2;
            this.stockMinPriceNumericUpDown.Enabled = false;
            this.stockMinPriceNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMinPriceNumericUpDown.Location = new System.Drawing.Point(215, 70);
            this.stockMinPriceNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMinPriceNumericUpDown.Name = "stockMinPriceNumericUpDown";
            this.stockMinPriceNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.stockMinPriceNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMinPriceNumericUpDown.TabIndex = 44;
            this.stockMinPriceNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(316, 72);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(10, 13);
            this.label24.TabIndex = 42;
            this.label24.Text = "-";
            // 
            // stockPriceFilterCheckBox
            // 
            this.stockPriceFilterCheckBox.AutoSize = true;
            this.stockPriceFilterCheckBox.Location = new System.Drawing.Point(9, 71);
            this.stockPriceFilterCheckBox.Name = "stockPriceFilterCheckBox";
            this.stockPriceFilterCheckBox.Size = new System.Drawing.Size(161, 17);
            this.stockPriceFilterCheckBox.TabIndex = 43;
            this.stockPriceFilterCheckBox.Text = "Underlying stock price range";
            this.stockPriceFilterCheckBox.UseVisualStyleBackColor = true;
            this.stockPriceFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // otmMaxStrikeNumericUpDown
            // 
            this.otmMaxStrikeNumericUpDown.DecimalPlaces = 2;
            this.otmMaxStrikeNumericUpDown.Enabled = false;
            this.otmMaxStrikeNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.otmMaxStrikeNumericUpDown.Location = new System.Drawing.Point(332, 44);
            this.otmMaxStrikeNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.otmMaxStrikeNumericUpDown.Name = "otmMaxStrikeNumericUpDown";
            this.otmMaxStrikeNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.otmMaxStrikeNumericUpDown.TabIndex = 20;
            this.otmMaxStrikeNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.otmMaxStrikeNumericUpDown.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // itmMaxStrikeNumericUpDown
            // 
            this.itmMaxStrikeNumericUpDown.DecimalPlaces = 2;
            this.itmMaxStrikeNumericUpDown.Enabled = false;
            this.itmMaxStrikeNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.itmMaxStrikeNumericUpDown.Location = new System.Drawing.Point(332, 19);
            this.itmMaxStrikeNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.itmMaxStrikeNumericUpDown.Name = "itmMaxStrikeNumericUpDown";
            this.itmMaxStrikeNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.itmMaxStrikeNumericUpDown.TabIndex = 17;
            this.itmMaxStrikeNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.itmMaxStrikeNumericUpDown.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // otmMinStrikeNumericUpDown
            // 
            this.otmMinStrikeNumericUpDown.DecimalPlaces = 2;
            this.otmMinStrikeNumericUpDown.Enabled = false;
            this.otmMinStrikeNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.otmMinStrikeNumericUpDown.Location = new System.Drawing.Point(215, 45);
            this.otmMinStrikeNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.otmMinStrikeNumericUpDown.Name = "otmMinStrikeNumericUpDown";
            this.otmMinStrikeNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.otmMinStrikeNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.otmMinStrikeNumericUpDown.TabIndex = 19;
            this.otmMinStrikeNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // itmMinStrikeNumericUpDown
            // 
            this.itmMinStrikeNumericUpDown.DecimalPlaces = 2;
            this.itmMinStrikeNumericUpDown.Enabled = false;
            this.itmMinStrikeNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.itmMinStrikeNumericUpDown.Location = new System.Drawing.Point(215, 20);
            this.itmMinStrikeNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.itmMinStrikeNumericUpDown.Name = "itmMinStrikeNumericUpDown";
            this.itmMinStrikeNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.itmMinStrikeNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.itmMinStrikeNumericUpDown.TabIndex = 16;
            this.itmMinStrikeNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(433, 47);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 13);
            this.label11.TabIndex = 41;
            this.label11.Text = "[ % of stock-price ]";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(316, 47);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(10, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "-";
            // 
            // otmStrikeFilterCheckBox
            // 
            this.otmStrikeFilterCheckBox.AutoSize = true;
            this.otmStrikeFilterCheckBox.Location = new System.Drawing.Point(9, 46);
            this.otmStrikeFilterCheckBox.Name = "otmStrikeFilterCheckBox";
            this.otmStrikeFilterCheckBox.Size = new System.Drawing.Size(188, 17);
            this.otmStrikeFilterCheckBox.TabIndex = 18;
            this.otmStrikeFilterCheckBox.Text = "Out of the money stike price range";
            this.otmStrikeFilterCheckBox.UseVisualStyleBackColor = true;
            this.otmStrikeFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(433, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "[ % of stock-price ]";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(316, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "-";
            // 
            // itmStrikeFilterCheckBox
            // 
            this.itmStrikeFilterCheckBox.AutoSize = true;
            this.itmStrikeFilterCheckBox.Location = new System.Drawing.Point(9, 20);
            this.itmStrikeFilterCheckBox.Name = "itmStrikeFilterCheckBox";
            this.itmStrikeFilterCheckBox.Size = new System.Drawing.Size(168, 17);
            this.itmStrikeFilterCheckBox.TabIndex = 15;
            this.itmStrikeFilterCheckBox.Text = "In the money stike price range";
            this.itmStrikeFilterCheckBox.UseVisualStyleBackColor = true;
            this.itmStrikeFilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.groupBox12);
            this.tabPage4.Controls.Add(this.groupBox10);
            this.tabPage4.Controls.Add(this.label43);
            this.tabPage4.Controls.Add(this.groupBox11);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(789, 384);
            this.tabPage4.TabIndex = 6;
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox12.Controls.Add(this.maxMaxLossNumericUpDown);
            this.groupBox12.Controls.Add(this.minMaxProfitNumericUpDown);
            this.groupBox12.Controls.Add(this.label20);
            this.groupBox12.Controls.Add(this.label81);
            this.groupBox12.Controls.Add(this.maxMaxLossCheckBox);
            this.groupBox12.Controls.Add(this.minMaxProfitCheckBox);
            this.groupBox12.Controls.Add(this.profitLossRatioCheckBox);
            this.groupBox12.Controls.Add(this.minProtectionNumericUpDown);
            this.groupBox12.Controls.Add(this.profitLossMinRatioNumericUpDown);
            this.groupBox12.Controls.Add(this.label80);
            this.groupBox12.Controls.Add(this.minProtectionCheckBox);
            this.groupBox12.Controls.Add(this.maxBreakevenNumericUpDown);
            this.groupBox12.Controls.Add(this.label82);
            this.groupBox12.Controls.Add(this.maxBreakevenCheckBox);
            this.groupBox12.Controls.Add(this.protectionMaxProbNumericUpDown);
            this.groupBox12.Controls.Add(this.protectionMinProbNumericUpDown);
            this.groupBox12.Controls.Add(this.label54);
            this.groupBox12.Controls.Add(this.label56);
            this.groupBox12.Controls.Add(this.protectionProbCheckBox);
            this.groupBox12.Controls.Add(this.breakevenMaxProbNumericUpDown);
            this.groupBox12.Controls.Add(this.breakevenMinProbNumericUpDown);
            this.groupBox12.Controls.Add(this.label51);
            this.groupBox12.Controls.Add(this.label49);
            this.groupBox12.Controls.Add(this.breakevenProbCheckBox);
            this.groupBox12.Location = new System.Drawing.Point(3, 98);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(783, 175);
            this.groupBox12.TabIndex = 2;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Profit && Loss";
            // 
            // maxMaxLossNumericUpDown
            // 
            this.maxMaxLossNumericUpDown.DecimalPlaces = 2;
            this.maxMaxLossNumericUpDown.Enabled = false;
            this.maxMaxLossNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.maxMaxLossNumericUpDown.Location = new System.Drawing.Point(215, 126);
            this.maxMaxLossNumericUpDown.Name = "maxMaxLossNumericUpDown";
            this.maxMaxLossNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maxMaxLossNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.maxMaxLossNumericUpDown.TabIndex = 90;
            this.maxMaxLossNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // minMaxProfitNumericUpDown
            // 
            this.minMaxProfitNumericUpDown.DecimalPlaces = 2;
            this.minMaxProfitNumericUpDown.Enabled = false;
            this.minMaxProfitNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.minMaxProfitNumericUpDown.Location = new System.Drawing.Point(215, 104);
            this.minMaxProfitNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.minMaxProfitNumericUpDown.Name = "minMaxProfitNumericUpDown";
            this.minMaxProfitNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.minMaxProfitNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.minMaxProfitNumericUpDown.TabIndex = 87;
            this.minMaxProfitNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(433, 128);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(27, 13);
            this.label20.TabIndex = 85;
            this.label20.Text = "[ % ]";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(433, 106);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(27, 13);
            this.label81.TabIndex = 84;
            this.label81.Text = "[ % ]";
            // 
            // maxMaxLossCheckBox
            // 
            this.maxMaxLossCheckBox.AutoSize = true;
            this.maxMaxLossCheckBox.Location = new System.Drawing.Point(9, 127);
            this.maxMaxLossCheckBox.Name = "maxMaxLossCheckBox";
            this.maxMaxLossCheckBox.Size = new System.Drawing.Size(118, 17);
            this.maxMaxLossCheckBox.TabIndex = 83;
            this.maxMaxLossCheckBox.Text = "Maximum Max-Loss";
            this.maxMaxLossCheckBox.UseVisualStyleBackColor = true;
            this.maxMaxLossCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // minMaxProfitCheckBox
            // 
            this.minMaxProfitCheckBox.AutoSize = true;
            this.minMaxProfitCheckBox.Location = new System.Drawing.Point(9, 105);
            this.minMaxProfitCheckBox.Name = "minMaxProfitCheckBox";
            this.minMaxProfitCheckBox.Size = new System.Drawing.Size(117, 17);
            this.minMaxProfitCheckBox.TabIndex = 81;
            this.minMaxProfitCheckBox.Text = "Minimum Max-Profit";
            this.minMaxProfitCheckBox.UseVisualStyleBackColor = true;
            this.minMaxProfitCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // profitLossRatioCheckBox
            // 
            this.profitLossRatioCheckBox.AutoSize = true;
            this.profitLossRatioCheckBox.Location = new System.Drawing.Point(9, 149);
            this.profitLossRatioCheckBox.Name = "profitLossRatioCheckBox";
            this.profitLossRatioCheckBox.Size = new System.Drawing.Size(195, 17);
            this.profitLossRatioCheckBox.TabIndex = 64;
            this.profitLossRatioCheckBox.Text = "Minimum Max-Profit/Max-Loss Ratio";
            this.profitLossRatioCheckBox.UseVisualStyleBackColor = true;
            this.profitLossRatioCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // minProtectionNumericUpDown
            // 
            this.minProtectionNumericUpDown.DecimalPlaces = 2;
            this.minProtectionNumericUpDown.Enabled = false;
            this.minProtectionNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.minProtectionNumericUpDown.Location = new System.Drawing.Point(215, 82);
            this.minProtectionNumericUpDown.Name = "minProtectionNumericUpDown";
            this.minProtectionNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.minProtectionNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.minProtectionNumericUpDown.TabIndex = 79;
            this.minProtectionNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // profitLossMinRatioNumericUpDown
            // 
            this.profitLossMinRatioNumericUpDown.DecimalPlaces = 2;
            this.profitLossMinRatioNumericUpDown.Enabled = false;
            this.profitLossMinRatioNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.profitLossMinRatioNumericUpDown.Location = new System.Drawing.Point(215, 148);
            this.profitLossMinRatioNumericUpDown.Name = "profitLossMinRatioNumericUpDown";
            this.profitLossMinRatioNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.profitLossMinRatioNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.profitLossMinRatioNumericUpDown.TabIndex = 65;
            this.profitLossMinRatioNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.profitLossMinRatioNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(433, 84);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(108, 13);
            this.label80.TabIndex = 76;
            this.label80.Text = "[ % stock movement ]";
            // 
            // minProtectionCheckBox
            // 
            this.minProtectionCheckBox.AutoSize = true;
            this.minProtectionCheckBox.Location = new System.Drawing.Point(9, 83);
            this.minProtectionCheckBox.Name = "minProtectionCheckBox";
            this.minProtectionCheckBox.Size = new System.Drawing.Size(116, 17);
            this.minProtectionCheckBox.TabIndex = 77;
            this.minProtectionCheckBox.Text = "Minmum Protection";
            this.minProtectionCheckBox.UseVisualStyleBackColor = true;
            this.minProtectionCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // maxBreakevenNumericUpDown
            // 
            this.maxBreakevenNumericUpDown.DecimalPlaces = 2;
            this.maxBreakevenNumericUpDown.Enabled = false;
            this.maxBreakevenNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.maxBreakevenNumericUpDown.Location = new System.Drawing.Point(215, 60);
            this.maxBreakevenNumericUpDown.Name = "maxBreakevenNumericUpDown";
            this.maxBreakevenNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.maxBreakevenNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.maxBreakevenNumericUpDown.TabIndex = 74;
            this.maxBreakevenNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(433, 62);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(108, 13);
            this.label82.TabIndex = 71;
            this.label82.Text = "[ % stock movement ]";
            // 
            // maxBreakevenCheckBox
            // 
            this.maxBreakevenCheckBox.AutoSize = true;
            this.maxBreakevenCheckBox.Location = new System.Drawing.Point(9, 61);
            this.maxBreakevenCheckBox.Name = "maxBreakevenCheckBox";
            this.maxBreakevenCheckBox.Size = new System.Drawing.Size(125, 17);
            this.maxBreakevenCheckBox.TabIndex = 72;
            this.maxBreakevenCheckBox.Text = "Maximum Breakeven";
            this.maxBreakevenCheckBox.UseVisualStyleBackColor = true;
            this.maxBreakevenCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // protectionMaxProbNumericUpDown
            // 
            this.protectionMaxProbNumericUpDown.DecimalPlaces = 2;
            this.protectionMaxProbNumericUpDown.Enabled = false;
            this.protectionMaxProbNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.protectionMaxProbNumericUpDown.Location = new System.Drawing.Point(332, 37);
            this.protectionMaxProbNumericUpDown.Name = "protectionMaxProbNumericUpDown";
            this.protectionMaxProbNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.protectionMaxProbNumericUpDown.TabIndex = 70;
            this.protectionMaxProbNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.protectionMaxProbNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // protectionMinProbNumericUpDown
            // 
            this.protectionMinProbNumericUpDown.DecimalPlaces = 2;
            this.protectionMinProbNumericUpDown.Enabled = false;
            this.protectionMinProbNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.protectionMinProbNumericUpDown.Location = new System.Drawing.Point(215, 38);
            this.protectionMinProbNumericUpDown.Name = "protectionMinProbNumericUpDown";
            this.protectionMinProbNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.protectionMinProbNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.protectionMinProbNumericUpDown.TabIndex = 69;
            this.protectionMinProbNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(316, 40);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(10, 13);
            this.label54.TabIndex = 68;
            this.label54.Text = "-";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(433, 40);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(27, 13);
            this.label56.TabIndex = 66;
            this.label56.Text = "[ % ]";
            // 
            // protectionProbCheckBox
            // 
            this.protectionProbCheckBox.AutoSize = true;
            this.protectionProbCheckBox.Location = new System.Drawing.Point(9, 39);
            this.protectionProbCheckBox.Name = "protectionProbCheckBox";
            this.protectionProbCheckBox.Size = new System.Drawing.Size(125, 17);
            this.protectionProbCheckBox.TabIndex = 67;
            this.protectionProbCheckBox.Text = "Protection Probability";
            this.protectionProbCheckBox.UseVisualStyleBackColor = true;
            this.protectionProbCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // breakevenMaxProbNumericUpDown
            // 
            this.breakevenMaxProbNumericUpDown.DecimalPlaces = 2;
            this.breakevenMaxProbNumericUpDown.Enabled = false;
            this.breakevenMaxProbNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.breakevenMaxProbNumericUpDown.Location = new System.Drawing.Point(332, 15);
            this.breakevenMaxProbNumericUpDown.Name = "breakevenMaxProbNumericUpDown";
            this.breakevenMaxProbNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.breakevenMaxProbNumericUpDown.TabIndex = 53;
            this.breakevenMaxProbNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.breakevenMaxProbNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // breakevenMinProbNumericUpDown
            // 
            this.breakevenMinProbNumericUpDown.DecimalPlaces = 2;
            this.breakevenMinProbNumericUpDown.Enabled = false;
            this.breakevenMinProbNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.breakevenMinProbNumericUpDown.Location = new System.Drawing.Point(215, 16);
            this.breakevenMinProbNumericUpDown.Name = "breakevenMinProbNumericUpDown";
            this.breakevenMinProbNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.breakevenMinProbNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.breakevenMinProbNumericUpDown.TabIndex = 52;
            this.breakevenMinProbNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(316, 18);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(10, 13);
            this.label51.TabIndex = 51;
            this.label51.Text = "-";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(433, 18);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(27, 13);
            this.label49.TabIndex = 0;
            this.label49.Text = "[ % ]";
            // 
            // breakevenProbCheckBox
            // 
            this.breakevenProbCheckBox.AutoSize = true;
            this.breakevenProbCheckBox.Location = new System.Drawing.Point(9, 17);
            this.breakevenProbCheckBox.Name = "breakevenProbCheckBox";
            this.breakevenProbCheckBox.Size = new System.Drawing.Size(129, 17);
            this.breakevenProbCheckBox.TabIndex = 32;
            this.breakevenProbCheckBox.Text = "Breakeven Probability";
            this.breakevenProbCheckBox.UseVisualStyleBackColor = true;
            this.breakevenProbCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.Controls.Add(this.totalThetaMaxNumericUpDown);
            this.groupBox10.Controls.Add(this.totalVegaMaxNumericUpDown);
            this.groupBox10.Controls.Add(this.totalThetaMinNumericUpDown);
            this.groupBox10.Controls.Add(this.totalVegaMinNumericUpDown);
            this.groupBox10.Controls.Add(this.label55);
            this.groupBox10.Controls.Add(this.totalThetaCheckBox);
            this.groupBox10.Controls.Add(this.label57);
            this.groupBox10.Controls.Add(this.totalVegaCheckBox);
            this.groupBox10.Controls.Add(this.totalGammaMaxNumericUpDown);
            this.groupBox10.Controls.Add(this.totalDeltaMaxNumericUpDown);
            this.groupBox10.Controls.Add(this.totalGammaMinNumericUpDown);
            this.groupBox10.Controls.Add(this.totalDeltaMinNumericUpDown);
            this.groupBox10.Controls.Add(this.label50);
            this.groupBox10.Controls.Add(this.totalGammaCheckBox);
            this.groupBox10.Controls.Add(this.label53);
            this.groupBox10.Controls.Add(this.totalDeltaCheckBox);
            this.groupBox10.Location = new System.Drawing.Point(3, 25);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(783, 69);
            this.groupBox10.TabIndex = 1;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Greeks Filter ";
            // 
            // totalThetaMaxNumericUpDown
            // 
            this.totalThetaMaxNumericUpDown.DecimalPlaces = 2;
            this.totalThetaMaxNumericUpDown.Enabled = false;
            this.totalThetaMaxNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.totalThetaMaxNumericUpDown.Location = new System.Drawing.Point(679, 38);
            this.totalThetaMaxNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.totalThetaMaxNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.totalThetaMaxNumericUpDown.Name = "totalThetaMaxNumericUpDown";
            this.totalThetaMaxNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.totalThetaMaxNumericUpDown.TabIndex = 50;
            this.totalThetaMaxNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalThetaMaxNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // totalVegaMaxNumericUpDown
            // 
            this.totalVegaMaxNumericUpDown.DecimalPlaces = 2;
            this.totalVegaMaxNumericUpDown.Enabled = false;
            this.totalVegaMaxNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.totalVegaMaxNumericUpDown.Location = new System.Drawing.Point(679, 16);
            this.totalVegaMaxNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.totalVegaMaxNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.totalVegaMaxNumericUpDown.Name = "totalVegaMaxNumericUpDown";
            this.totalVegaMaxNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.totalVegaMaxNumericUpDown.TabIndex = 47;
            this.totalVegaMaxNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalVegaMaxNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // totalThetaMinNumericUpDown
            // 
            this.totalThetaMinNumericUpDown.DecimalPlaces = 2;
            this.totalThetaMinNumericUpDown.Enabled = false;
            this.totalThetaMinNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.totalThetaMinNumericUpDown.Location = new System.Drawing.Point(562, 39);
            this.totalThetaMinNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.totalThetaMinNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.totalThetaMinNumericUpDown.Name = "totalThetaMinNumericUpDown";
            this.totalThetaMinNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.totalThetaMinNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.totalThetaMinNumericUpDown.TabIndex = 49;
            this.totalThetaMinNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalThetaMinNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            // 
            // totalVegaMinNumericUpDown
            // 
            this.totalVegaMinNumericUpDown.DecimalPlaces = 2;
            this.totalVegaMinNumericUpDown.Enabled = false;
            this.totalVegaMinNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.totalVegaMinNumericUpDown.Location = new System.Drawing.Point(562, 17);
            this.totalVegaMinNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.totalVegaMinNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.totalVegaMinNumericUpDown.Name = "totalVegaMinNumericUpDown";
            this.totalVegaMinNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.totalVegaMinNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.totalVegaMinNumericUpDown.TabIndex = 45;
            this.totalVegaMinNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalVegaMinNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(663, 41);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(10, 13);
            this.label55.TabIndex = 42;
            this.label55.Text = "-";
            // 
            // totalThetaCheckBox
            // 
            this.totalThetaCheckBox.AutoSize = true;
            this.totalThetaCheckBox.Location = new System.Drawing.Point(429, 40);
            this.totalThetaCheckBox.Name = "totalThetaCheckBox";
            this.totalThetaCheckBox.Size = new System.Drawing.Size(119, 17);
            this.totalThetaCheckBox.TabIndex = 48;
            this.totalThetaCheckBox.Text = "Strategy total Theta";
            this.totalThetaCheckBox.UseVisualStyleBackColor = true;
            this.totalThetaCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(663, 18);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(10, 13);
            this.label57.TabIndex = 43;
            this.label57.Text = "-";
            // 
            // totalVegaCheckBox
            // 
            this.totalVegaCheckBox.AutoSize = true;
            this.totalVegaCheckBox.Location = new System.Drawing.Point(429, 17);
            this.totalVegaCheckBox.Name = "totalVegaCheckBox";
            this.totalVegaCheckBox.Size = new System.Drawing.Size(116, 17);
            this.totalVegaCheckBox.TabIndex = 44;
            this.totalVegaCheckBox.Text = "Strategy total Vega";
            this.totalVegaCheckBox.UseVisualStyleBackColor = true;
            this.totalVegaCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // totalGammaMaxNumericUpDown
            // 
            this.totalGammaMaxNumericUpDown.DecimalPlaces = 2;
            this.totalGammaMaxNumericUpDown.Enabled = false;
            this.totalGammaMaxNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.totalGammaMaxNumericUpDown.Location = new System.Drawing.Point(259, 38);
            this.totalGammaMaxNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.totalGammaMaxNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.totalGammaMaxNumericUpDown.Name = "totalGammaMaxNumericUpDown";
            this.totalGammaMaxNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.totalGammaMaxNumericUpDown.TabIndex = 20;
            this.totalGammaMaxNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalGammaMaxNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // totalDeltaMaxNumericUpDown
            // 
            this.totalDeltaMaxNumericUpDown.DecimalPlaces = 2;
            this.totalDeltaMaxNumericUpDown.Enabled = false;
            this.totalDeltaMaxNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.totalDeltaMaxNumericUpDown.Location = new System.Drawing.Point(259, 16);
            this.totalDeltaMaxNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.totalDeltaMaxNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.totalDeltaMaxNumericUpDown.Name = "totalDeltaMaxNumericUpDown";
            this.totalDeltaMaxNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.totalDeltaMaxNumericUpDown.TabIndex = 17;
            this.totalDeltaMaxNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalDeltaMaxNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // totalGammaMinNumericUpDown
            // 
            this.totalGammaMinNumericUpDown.DecimalPlaces = 2;
            this.totalGammaMinNumericUpDown.Enabled = false;
            this.totalGammaMinNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.totalGammaMinNumericUpDown.Location = new System.Drawing.Point(142, 39);
            this.totalGammaMinNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.totalGammaMinNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.totalGammaMinNumericUpDown.Name = "totalGammaMinNumericUpDown";
            this.totalGammaMinNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.totalGammaMinNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.totalGammaMinNumericUpDown.TabIndex = 19;
            this.totalGammaMinNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalGammaMinNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            // 
            // totalDeltaMinNumericUpDown
            // 
            this.totalDeltaMinNumericUpDown.DecimalPlaces = 2;
            this.totalDeltaMinNumericUpDown.Enabled = false;
            this.totalDeltaMinNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.totalDeltaMinNumericUpDown.Location = new System.Drawing.Point(142, 17);
            this.totalDeltaMinNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.totalDeltaMinNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.totalDeltaMinNumericUpDown.Name = "totalDeltaMinNumericUpDown";
            this.totalDeltaMinNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.totalDeltaMinNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.totalDeltaMinNumericUpDown.TabIndex = 16;
            this.totalDeltaMinNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totalDeltaMinNumericUpDown.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(243, 41);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(10, 13);
            this.label50.TabIndex = 0;
            this.label50.Text = "-";
            // 
            // totalGammaCheckBox
            // 
            this.totalGammaCheckBox.AutoSize = true;
            this.totalGammaCheckBox.Location = new System.Drawing.Point(9, 40);
            this.totalGammaCheckBox.Name = "totalGammaCheckBox";
            this.totalGammaCheckBox.Size = new System.Drawing.Size(127, 17);
            this.totalGammaCheckBox.TabIndex = 18;
            this.totalGammaCheckBox.Text = "Strategy total Gamma";
            this.totalGammaCheckBox.UseVisualStyleBackColor = true;
            this.totalGammaCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(243, 18);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(10, 13);
            this.label53.TabIndex = 0;
            this.label53.Text = "-";
            // 
            // totalDeltaCheckBox
            // 
            this.totalDeltaCheckBox.AutoSize = true;
            this.totalDeltaCheckBox.Location = new System.Drawing.Point(9, 17);
            this.totalDeltaCheckBox.Name = "totalDeltaCheckBox";
            this.totalDeltaCheckBox.Size = new System.Drawing.Size(116, 17);
            this.totalDeltaCheckBox.TabIndex = 15;
            this.totalDeltaCheckBox.Text = "Strategy total Delta";
            this.totalDeltaCheckBox.UseVisualStyleBackColor = true;
            this.totalDeltaCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(5, 3);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(215, 14);
            this.label43.TabIndex = 0;
            this.label43.Text = "Step 3: Setup Wizard Filters (2/2)";
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox11.Controls.Add(this.stockMove2RadioButton);
            this.groupBox11.Controls.Add(this.stockMove1RadioButton);
            this.groupBox11.Controls.Add(this.label64);
            this.groupBox11.Controls.Add(this.label63);
            this.groupBox11.Controls.Add(this.label62);
            this.groupBox11.Controls.Add(this.checkBox8);
            this.groupBox11.Controls.Add(this.stockMoveMaxStdDevNumericUpDown);
            this.groupBox11.Controls.Add(this.stockMoveMinStdDevNumericUpDown);
            this.groupBox11.Controls.Add(this.label60);
            this.groupBox11.Controls.Add(this.label61);
            this.groupBox11.Controls.Add(this.stockMoveMaxNumericUpDown);
            this.groupBox11.Controls.Add(this.stockMoveMinNumericUpDown);
            this.groupBox11.Controls.Add(this.label58);
            this.groupBox11.Controls.Add(this.label59);
            this.groupBox11.Controls.Add(this.stockMoveCheckBox);
            this.groupBox11.Controls.Add(this.expReturnMinNumericUpDown);
            this.groupBox11.Controls.Add(this.label52);
            this.groupBox11.Controls.Add(this.expReturnCheckBox);
            this.groupBox11.Location = new System.Drawing.Point(3, 279);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(783, 99);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Expected Return Filter ";
            // 
            // stockMove2RadioButton
            // 
            this.stockMove2RadioButton.AutoSize = true;
            this.stockMove2RadioButton.Location = new System.Drawing.Point(195, 64);
            this.stockMove2RadioButton.Name = "stockMove2RadioButton";
            this.stockMove2RadioButton.Size = new System.Drawing.Size(14, 13);
            this.stockMove2RadioButton.TabIndex = 68;
            this.stockMove2RadioButton.UseVisualStyleBackColor = true;
            this.stockMove2RadioButton.CheckedChanged += new System.EventHandler(this.xxxRadioButton_CheckedChanged);
            // 
            // stockMove1RadioButton
            // 
            this.stockMove1RadioButton.AutoSize = true;
            this.stockMove1RadioButton.Checked = true;
            this.stockMove1RadioButton.Location = new System.Drawing.Point(195, 43);
            this.stockMove1RadioButton.Name = "stockMove1RadioButton";
            this.stockMove1RadioButton.Size = new System.Drawing.Size(14, 13);
            this.stockMove1RadioButton.TabIndex = 67;
            this.stockMove1RadioButton.TabStop = true;
            this.stockMove1RadioButton.UseVisualStyleBackColor = true;
            this.stockMove1RadioButton.CheckedChanged += new System.EventHandler(this.xxxRadioButton_CheckedChanged);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(535, 63);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(10, 13);
            this.label64.TabIndex = 66;
            this.label64.Text = "]";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(535, 40);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(10, 13);
            this.label63.TabIndex = 65;
            this.label63.Text = "]";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(535, 19);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(10, 13);
            this.label62.TabIndex = 64;
            this.label62.Text = "]";
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(21, -74);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(117, 17);
            this.checkBox8.TabIndex = 81;
            this.checkBox8.Text = "Minimum Max-Profit";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // stockMoveMaxStdDevNumericUpDown
            // 
            this.stockMoveMaxStdDevNumericUpDown.DecimalPlaces = 2;
            this.stockMoveMaxStdDevNumericUpDown.Enabled = false;
            this.stockMoveMaxStdDevNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.stockMoveMaxStdDevNumericUpDown.Location = new System.Drawing.Point(332, 61);
            this.stockMoveMaxStdDevNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMoveMaxStdDevNumericUpDown.Name = "stockMoveMaxStdDevNumericUpDown";
            this.stockMoveMaxStdDevNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMoveMaxStdDevNumericUpDown.TabIndex = 63;
            this.stockMoveMaxStdDevNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMoveMaxStdDevNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // stockMoveMinStdDevNumericUpDown
            // 
            this.stockMoveMinStdDevNumericUpDown.DecimalPlaces = 2;
            this.stockMoveMinStdDevNumericUpDown.Enabled = false;
            this.stockMoveMinStdDevNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.stockMoveMinStdDevNumericUpDown.Location = new System.Drawing.Point(215, 62);
            this.stockMoveMinStdDevNumericUpDown.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.stockMoveMinStdDevNumericUpDown.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.stockMoveMinStdDevNumericUpDown.Name = "stockMoveMinStdDevNumericUpDown";
            this.stockMoveMinStdDevNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.stockMoveMinStdDevNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMoveMinStdDevNumericUpDown.TabIndex = 62;
            this.stockMoveMinStdDevNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMoveMinStdDevNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(316, 64);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(10, 13);
            this.label60.TabIndex = 61;
            this.label60.Text = "-";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(434, 63);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(103, 13);
            this.label61.TabIndex = 59;
            this.label61.Text = "[  standard-deviation";
            // 
            // stockMoveMaxNumericUpDown
            // 
            this.stockMoveMaxNumericUpDown.DecimalPlaces = 2;
            this.stockMoveMaxNumericUpDown.Enabled = false;
            this.stockMoveMaxNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMoveMaxNumericUpDown.Location = new System.Drawing.Point(332, 38);
            this.stockMoveMaxNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.stockMoveMaxNumericUpDown.Name = "stockMoveMaxNumericUpDown";
            this.stockMoveMaxNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMoveMaxNumericUpDown.TabIndex = 58;
            this.stockMoveMaxNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMoveMaxNumericUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // stockMoveMinNumericUpDown
            // 
            this.stockMoveMinNumericUpDown.DecimalPlaces = 2;
            this.stockMoveMinNumericUpDown.Enabled = false;
            this.stockMoveMinNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.stockMoveMinNumericUpDown.Location = new System.Drawing.Point(215, 39);
            this.stockMoveMinNumericUpDown.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.stockMoveMinNumericUpDown.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.stockMoveMinNumericUpDown.Name = "stockMoveMinNumericUpDown";
            this.stockMoveMinNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.stockMoveMinNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.stockMoveMinNumericUpDown.TabIndex = 57;
            this.stockMoveMinNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stockMoveMinNumericUpDown.Value = new decimal(new int[] {
            10,
            0,
            0,
            -2147483648});
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(316, 41);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(10, 13);
            this.label58.TabIndex = 56;
            this.label58.Text = "-";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(434, 40);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(102, 13);
            this.label59.TabIndex = 54;
            this.label59.Text = "[ % stock movement";
            // 
            // stockMoveCheckBox
            // 
            this.stockMoveCheckBox.AutoSize = true;
            this.stockMoveCheckBox.Location = new System.Drawing.Point(9, 40);
            this.stockMoveCheckBox.Name = "stockMoveCheckBox";
            this.stockMoveCheckBox.Size = new System.Drawing.Size(182, 17);
            this.stockMoveCheckBox.TabIndex = 55;
            this.stockMoveCheckBox.Text = "Assume Stock Movement Range";
            this.stockMoveCheckBox.UseVisualStyleBackColor = true;
            this.stockMoveCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // expReturnMinNumericUpDown
            // 
            this.expReturnMinNumericUpDown.DecimalPlaces = 2;
            this.expReturnMinNumericUpDown.Enabled = false;
            this.expReturnMinNumericUpDown.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.expReturnMinNumericUpDown.Location = new System.Drawing.Point(215, 17);
            this.expReturnMinNumericUpDown.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.expReturnMinNumericUpDown.Name = "expReturnMinNumericUpDown";
            this.expReturnMinNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.expReturnMinNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.expReturnMinNumericUpDown.TabIndex = 33;
            this.expReturnMinNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(434, 19);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(105, 13);
            this.label52.TabIndex = 0;
            this.label52.Text = "[ % of net-investment";
            // 
            // expReturnCheckBox
            // 
            this.expReturnCheckBox.AutoSize = true;
            this.expReturnCheckBox.Location = new System.Drawing.Point(9, 17);
            this.expReturnCheckBox.Name = "expReturnCheckBox";
            this.expReturnCheckBox.Size = new System.Drawing.Size(202, 17);
            this.expReturnCheckBox.TabIndex = 32;
            this.expReturnCheckBox.Text = "Minimum expected return (1-month %)";
            this.expReturnCheckBox.UseVisualStyleBackColor = true;
            this.expReturnCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.indicator2CheckBox);
            this.tabPage5.Controls.Add(this.indicator2GroupBox);
            this.tabPage5.Controls.Add(this.indicator1CheckBox);
            this.tabPage5.Controls.Add(this.indicator1GroupBox);
            this.tabPage5.Controls.Add(this.label73);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(789, 384);
            this.tabPage5.TabIndex = 7;
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // indicator2CheckBox
            // 
            this.indicator2CheckBox.AutoSize = true;
            this.indicator2CheckBox.Location = new System.Drawing.Point(15, 137);
            this.indicator2CheckBox.Name = "indicator2CheckBox";
            this.indicator2CheckBox.Size = new System.Drawing.Size(15, 14);
            this.indicator2CheckBox.TabIndex = 41;
            this.indicator2CheckBox.UseVisualStyleBackColor = true;
            this.indicator2CheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // indicator2GroupBox
            // 
            this.indicator2GroupBox.Controls.Add(this.indicator2MaxNumericUpDown);
            this.indicator2GroupBox.Controls.Add(this.indicator2MinNumericUpDown);
            this.indicator2GroupBox.Controls.Add(this.label78);
            this.indicator2GroupBox.Controls.Add(this.indicator2FilterCheckBox);
            this.indicator2GroupBox.Controls.Add(this.label69);
            this.indicator2GroupBox.Controls.Add(this.indicator2FormatTextBox);
            this.indicator2GroupBox.Controls.Add(this.label70);
            this.indicator2GroupBox.Controls.Add(this.label71);
            this.indicator2GroupBox.Controls.Add(this.label72);
            this.indicator2GroupBox.Controls.Add(this.indicator2NameTextBox);
            this.indicator2GroupBox.Controls.Add(this.indicator2EquationTextBox);
            this.indicator2GroupBox.Location = new System.Drawing.Point(3, 136);
            this.indicator2GroupBox.Name = "indicator2GroupBox";
            this.indicator2GroupBox.Size = new System.Drawing.Size(777, 105);
            this.indicator2GroupBox.TabIndex = 40;
            this.indicator2GroupBox.TabStop = false;
            this.indicator2GroupBox.Text = "       Options Indicator 2";
            this.toolTip.SetToolTip(this.indicator2GroupBox, "Add private indicators to options chain.\r\n\r\nMore information about how to write a" +
                    " private\r\nindicator is available at \"OptionsOracle Getting\r\nStarted Guide\".\r\n");
            // 
            // indicator2MaxNumericUpDown
            // 
            this.indicator2MaxNumericUpDown.DecimalPlaces = 2;
            this.indicator2MaxNumericUpDown.Enabled = false;
            this.indicator2MaxNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.indicator2MaxNumericUpDown.Location = new System.Drawing.Point(183, 76);
            this.indicator2MaxNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.indicator2MaxNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.indicator2MaxNumericUpDown.Name = "indicator2MaxNumericUpDown";
            this.indicator2MaxNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.indicator2MaxNumericUpDown.TabIndex = 48;
            this.indicator2MaxNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.indicator2MaxNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // indicator2MinNumericUpDown
            // 
            this.indicator2MinNumericUpDown.DecimalPlaces = 2;
            this.indicator2MinNumericUpDown.Enabled = false;
            this.indicator2MinNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.indicator2MinNumericUpDown.Location = new System.Drawing.Point(66, 76);
            this.indicator2MinNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.indicator2MinNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.indicator2MinNumericUpDown.Name = "indicator2MinNumericUpDown";
            this.indicator2MinNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.indicator2MinNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.indicator2MinNumericUpDown.TabIndex = 47;
            this.indicator2MinNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.indicator2MinNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(167, 80);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(10, 13);
            this.label78.TabIndex = 45;
            this.label78.Text = "-";
            // 
            // indicator2FilterCheckBox
            // 
            this.indicator2FilterCheckBox.AutoSize = true;
            this.indicator2FilterCheckBox.Location = new System.Drawing.Point(12, 78);
            this.indicator2FilterCheckBox.Name = "indicator2FilterCheckBox";
            this.indicator2FilterCheckBox.Size = new System.Drawing.Size(53, 17);
            this.indicator2FilterCheckBox.TabIndex = 46;
            this.indicator2FilterCheckBox.Text = "Value";
            this.indicator2FilterCheckBox.UseVisualStyleBackColor = true;
            this.indicator2FilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(184, 27);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(42, 13);
            this.label69.TabIndex = 44;
            this.label69.Text = "Format:";
            // 
            // indicator2FormatTextBox
            // 
            this.indicator2FormatTextBox.Location = new System.Drawing.Point(228, 23);
            this.indicator2FormatTextBox.Name = "indicator2FormatTextBox";
            this.indicator2FormatTextBox.Size = new System.Drawing.Size(27, 20);
            this.indicator2FormatTextBox.TabIndex = 43;
            this.indicator2FormatTextBox.Text = "N2";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(9, 27);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(38, 13);
            this.label70.TabIndex = 36;
            this.label70.Text = "Name:";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(328, 76);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(439, 13);
            this.label71.TabIndex = 40;
            this.label71.Text = "Enter Indicator Equation (*). Example: (Option[A].ImpliedVolatility / Option[B].I" +
                "mpliedVolatility)";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(9, 54);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(52, 13);
            this.label72.TabIndex = 35;
            this.label72.Text = "Equation:";
            // 
            // indicator2NameTextBox
            // 
            this.indicator2NameTextBox.Location = new System.Drawing.Point(67, 23);
            this.indicator2NameTextBox.Name = "indicator2NameTextBox";
            this.indicator2NameTextBox.Size = new System.Drawing.Size(109, 20);
            this.indicator2NameTextBox.TabIndex = 34;
            this.indicator2NameTextBox.Text = "Ind 2";
            // 
            // indicator2EquationTextBox
            // 
            this.indicator2EquationTextBox.Location = new System.Drawing.Point(67, 50);
            this.indicator2EquationTextBox.Multiline = true;
            this.indicator2EquationTextBox.Name = "indicator2EquationTextBox";
            this.indicator2EquationTextBox.Size = new System.Drawing.Size(700, 20);
            this.indicator2EquationTextBox.TabIndex = 32;
            // 
            // indicator1CheckBox
            // 
            this.indicator1CheckBox.AutoSize = true;
            this.indicator1CheckBox.Location = new System.Drawing.Point(12, 25);
            this.indicator1CheckBox.Name = "indicator1CheckBox";
            this.indicator1CheckBox.Size = new System.Drawing.Size(15, 14);
            this.indicator1CheckBox.TabIndex = 39;
            this.indicator1CheckBox.UseVisualStyleBackColor = true;
            this.indicator1CheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // indicator1GroupBox
            // 
            this.indicator1GroupBox.Controls.Add(this.indicator1MaxNumericUpDown);
            this.indicator1GroupBox.Controls.Add(this.indicator1MinNumericUpDown);
            this.indicator1GroupBox.Controls.Add(this.label79);
            this.indicator1GroupBox.Controls.Add(this.indicator1FilterCheckBox);
            this.indicator1GroupBox.Controls.Add(this.label74);
            this.indicator1GroupBox.Controls.Add(this.indicator1FormatTextBox);
            this.indicator1GroupBox.Controls.Add(this.label75);
            this.indicator1GroupBox.Controls.Add(this.label76);
            this.indicator1GroupBox.Controls.Add(this.label77);
            this.indicator1GroupBox.Controls.Add(this.indicator1NameTextBox);
            this.indicator1GroupBox.Controls.Add(this.indicator1EquationTextBox);
            this.indicator1GroupBox.Location = new System.Drawing.Point(3, 25);
            this.indicator1GroupBox.Name = "indicator1GroupBox";
            this.indicator1GroupBox.Size = new System.Drawing.Size(777, 105);
            this.indicator1GroupBox.TabIndex = 38;
            this.indicator1GroupBox.TabStop = false;
            this.indicator1GroupBox.Text = "       Options Indicator 1";
            this.toolTip.SetToolTip(this.indicator1GroupBox, "Add private indicators to options chain.\r\n\r\nMore information about how to write a" +
                    " private\r\nindicator is available at \"OptionsOracle Getting\r\nStarted Guide\".");
            // 
            // indicator1MaxNumericUpDown
            // 
            this.indicator1MaxNumericUpDown.DecimalPlaces = 2;
            this.indicator1MaxNumericUpDown.Enabled = false;
            this.indicator1MaxNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.indicator1MaxNumericUpDown.Location = new System.Drawing.Point(184, 76);
            this.indicator1MaxNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.indicator1MaxNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.indicator1MaxNumericUpDown.Name = "indicator1MaxNumericUpDown";
            this.indicator1MaxNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.indicator1MaxNumericUpDown.TabIndex = 52;
            this.indicator1MaxNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.indicator1MaxNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // indicator1MinNumericUpDown
            // 
            this.indicator1MinNumericUpDown.DecimalPlaces = 2;
            this.indicator1MinNumericUpDown.Enabled = false;
            this.indicator1MinNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.indicator1MinNumericUpDown.Location = new System.Drawing.Point(67, 76);
            this.indicator1MinNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.indicator1MinNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.indicator1MinNumericUpDown.Name = "indicator1MinNumericUpDown";
            this.indicator1MinNumericUpDown.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.indicator1MinNumericUpDown.Size = new System.Drawing.Size(95, 20);
            this.indicator1MinNumericUpDown.TabIndex = 51;
            this.indicator1MinNumericUpDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.indicator1MinNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(168, 80);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(10, 13);
            this.label79.TabIndex = 49;
            this.label79.Text = "-";
            // 
            // indicator1FilterCheckBox
            // 
            this.indicator1FilterCheckBox.AutoSize = true;
            this.indicator1FilterCheckBox.Location = new System.Drawing.Point(13, 78);
            this.indicator1FilterCheckBox.Name = "indicator1FilterCheckBox";
            this.indicator1FilterCheckBox.Size = new System.Drawing.Size(53, 17);
            this.indicator1FilterCheckBox.TabIndex = 50;
            this.indicator1FilterCheckBox.Text = "Value";
            this.indicator1FilterCheckBox.UseVisualStyleBackColor = true;
            this.indicator1FilterCheckBox.CheckedChanged += new System.EventHandler(this.xxxCheckBox_CheckedChanged);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(184, 27);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(42, 13);
            this.label74.TabIndex = 46;
            this.label74.Text = "Format:";
            // 
            // indicator1FormatTextBox
            // 
            this.indicator1FormatTextBox.Location = new System.Drawing.Point(228, 23);
            this.indicator1FormatTextBox.Name = "indicator1FormatTextBox";
            this.indicator1FormatTextBox.Size = new System.Drawing.Size(27, 20);
            this.indicator1FormatTextBox.TabIndex = 45;
            this.indicator1FormatTextBox.Text = "N2";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(303, 73);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(464, 13);
            this.label75.TabIndex = 41;
            this.label75.Text = "Enter Indicator Equation (*). Example: Math.max(Stock.ImpliedVolatility, Option[A" +
                "].ImpliedVolatility)";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(9, 27);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(38, 13);
            this.label76.TabIndex = 36;
            this.label76.Text = "Name:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(9, 54);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(52, 13);
            this.label77.TabIndex = 35;
            this.label77.Text = "Equation:";
            // 
            // indicator1NameTextBox
            // 
            this.indicator1NameTextBox.Location = new System.Drawing.Point(67, 23);
            this.indicator1NameTextBox.Name = "indicator1NameTextBox";
            this.indicator1NameTextBox.Size = new System.Drawing.Size(109, 20);
            this.indicator1NameTextBox.TabIndex = 34;
            this.indicator1NameTextBox.Text = "Ind 1";
            // 
            // indicator1EquationTextBox
            // 
            this.indicator1EquationTextBox.Location = new System.Drawing.Point(67, 50);
            this.indicator1EquationTextBox.Multiline = true;
            this.indicator1EquationTextBox.Name = "indicator1EquationTextBox";
            this.indicator1EquationTextBox.Size = new System.Drawing.Size(700, 20);
            this.indicator1EquationTextBox.TabIndex = 30;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.Location = new System.Drawing.Point(5, 3);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(204, 14);
            this.label73.TabIndex = 2;
            this.label73.Text = "Step 4: Setup Wizard Indicators";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.stockDatabaseGroupBox);
            this.tabPage6.Controls.Add(this.downloadMethodGroupBox);
            this.tabPage6.Controls.Add(this.progressGroupBox);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(789, 384);
            this.tabPage6.TabIndex = 3;
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // stockDatabaseGroupBox
            // 
            this.stockDatabaseGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.stockDatabaseGroupBox.Controls.Add(this.stockListDataGridView1);
            this.stockDatabaseGroupBox.Controls.Add(this.label17);
            this.stockDatabaseGroupBox.Location = new System.Drawing.Point(486, 62);
            this.stockDatabaseGroupBox.Name = "stockDatabaseGroupBox";
            this.stockDatabaseGroupBox.Size = new System.Drawing.Size(296, 242);
            this.stockDatabaseGroupBox.TabIndex = 0;
            this.stockDatabaseGroupBox.TabStop = false;
            this.stockDatabaseGroupBox.Text = "Stocks Database Status";
            // 
            // stockListDataGridView1
            // 
            this.stockListDataGridView1.AllowUserToAddRows = false;
            this.stockListDataGridView1.AllowUserToDeleteRows = false;
            this.stockListDataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.stockListDataGridView1.AutoGenerateColumns = false;
            this.stockListDataGridView1.ColumnHeadersHeight = 22;
            this.stockListDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.stockListDataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stockDownloadSymbolColumn,
            this.stockDownloadDatabaseColumn});
            this.stockListDataGridView1.DataSource = this.stocksTableBindingSource;
            this.stockListDataGridView1.Location = new System.Drawing.Point(9, 35);
            this.stockListDataGridView1.Name = "stockListDataGridView1";
            this.stockListDataGridView1.ReadOnly = true;
            this.stockListDataGridView1.RowHeadersVisible = false;
            this.stockListDataGridView1.RowHeadersWidth = 16;
            this.stockListDataGridView1.RowTemplate.Height = 20;
            this.stockListDataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.stockListDataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.stockListDataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.stockListDataGridView1.Size = new System.Drawing.Size(279, 195);
            this.stockListDataGridView1.TabIndex = 0;
            // 
            // stockDownloadSymbolColumn
            // 
            this.stockDownloadSymbolColumn.DataPropertyName = "Symbol";
            this.stockDownloadSymbolColumn.HeaderText = "Symbol";
            this.stockDownloadSymbolColumn.Name = "stockDownloadSymbolColumn";
            this.stockDownloadSymbolColumn.ReadOnly = true;
            this.stockDownloadSymbolColumn.Width = 95;
            // 
            // stockDownloadDatabaseColumn
            // 
            this.stockDownloadDatabaseColumn.DataPropertyName = "Database";
            this.stockDownloadDatabaseColumn.HeaderText = "Database";
            this.stockDownloadDatabaseColumn.Name = "stockDownloadDatabaseColumn";
            this.stockDownloadDatabaseColumn.ReadOnly = true;
            this.stockDownloadDatabaseColumn.Width = 180;
            // 
            // stocksTableBindingSource
            // 
            this.stocksTableBindingSource.DataMember = "StocksTable";
            this.stocksTableBindingSource.DataSource = this.wizardSet;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(6, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(40, 13);
            this.label17.TabIndex = 0;
            this.label17.Text = "Status:";
            // 
            // downloadMethodGroupBox
            // 
            this.downloadMethodGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.downloadMethodGroupBox.Controls.Add(this.dw1RadioButton);
            this.downloadMethodGroupBox.Controls.Add(this.label3);
            this.downloadMethodGroupBox.Controls.Add(this.dw3RadioButton);
            this.downloadMethodGroupBox.Controls.Add(this.oldDaysTextBox);
            this.downloadMethodGroupBox.Controls.Add(this.dw2RadioButton);
            this.downloadMethodGroupBox.Location = new System.Drawing.Point(3, 202);
            this.downloadMethodGroupBox.Name = "downloadMethodGroupBox";
            this.downloadMethodGroupBox.Size = new System.Drawing.Size(477, 102);
            this.downloadMethodGroupBox.TabIndex = 0;
            this.downloadMethodGroupBox.TabStop = false;
            this.downloadMethodGroupBox.Text = "Download Options";
            // 
            // dw1RadioButton
            // 
            this.dw1RadioButton.AutoSize = true;
            this.dw1RadioButton.Location = new System.Drawing.Point(8, 19);
            this.dw1RadioButton.Name = "dw1RadioButton";
            this.dw1RadioButton.Size = new System.Drawing.Size(159, 17);
            this.dw1RadioButton.TabIndex = 35;
            this.dw1RadioButton.Text = "Download data for all stocks";
            this.dw1RadioButton.UseVisualStyleBackColor = true;
            this.dw1RadioButton.CheckedChanged += new System.EventHandler(this.xxxRadioButton_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(440, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "days";
            // 
            // dw3RadioButton
            // 
            this.dw3RadioButton.AutoSize = true;
            this.dw3RadioButton.Checked = true;
            this.dw3RadioButton.Location = new System.Drawing.Point(8, 65);
            this.dw3RadioButton.Name = "dw3RadioButton";
            this.dw3RadioButton.Size = new System.Drawing.Size(397, 17);
            this.dw3RadioButton.TabIndex = 37;
            this.dw3RadioButton.TabStop = true;
            this.dw3RadioButton.Text = "Download data for stocks that are not in local database, or with data older than";
            this.dw3RadioButton.UseVisualStyleBackColor = true;
            this.dw3RadioButton.CheckedChanged += new System.EventHandler(this.xxxRadioButton_CheckedChanged);
            // 
            // oldDaysTextBox
            // 
            this.oldDaysTextBox.Location = new System.Drawing.Point(406, 64);
            this.oldDaysTextBox.Name = "oldDaysTextBox";
            this.oldDaysTextBox.Size = new System.Drawing.Size(30, 20);
            this.oldDaysTextBox.TabIndex = 38;
            this.oldDaysTextBox.Text = "1";
            this.oldDaysTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dw2RadioButton
            // 
            this.dw2RadioButton.AutoSize = true;
            this.dw2RadioButton.Location = new System.Drawing.Point(8, 42);
            this.dw2RadioButton.Name = "dw2RadioButton";
            this.dw2RadioButton.Size = new System.Drawing.Size(308, 17);
            this.dw2RadioButton.TabIndex = 36;
            this.dw2RadioButton.Text = "Download data only for stocks that are not in local database\r\n";
            this.dw2RadioButton.UseVisualStyleBackColor = true;
            this.dw2RadioButton.CheckedChanged += new System.EventHandler(this.xxxRadioButton_CheckedChanged);
            // 
            // progressGroupBox
            // 
            this.progressGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.progressGroupBox.Controls.Add(this.downloadStatusLabel);
            this.progressGroupBox.Controls.Add(this.label16);
            this.progressGroupBox.Controls.Add(this.downloadStartStopButton);
            this.progressGroupBox.Controls.Add(this.downloadProgressBar);
            this.progressGroupBox.Controls.Add(this.label18);
            this.progressGroupBox.Controls.Add(this.downloadStartTimeLabel);
            this.progressGroupBox.Controls.Add(this.downloadEstFinishTimeLabel);
            this.progressGroupBox.Location = new System.Drawing.Point(3, 62);
            this.progressGroupBox.Name = "progressGroupBox";
            this.progressGroupBox.Size = new System.Drawing.Size(477, 134);
            this.progressGroupBox.TabIndex = 0;
            this.progressGroupBox.TabStop = false;
            this.progressGroupBox.Text = "Download Progress";
            // 
            // downloadStatusLabel
            // 
            this.downloadStatusLabel.Location = new System.Drawing.Point(5, 16);
            this.downloadStatusLabel.Name = "downloadStatusLabel";
            this.downloadStatusLabel.Size = new System.Drawing.Size(252, 19);
            this.downloadStatusLabel.TabIndex = 0;
            this.downloadStatusLabel.Text = "Status:";
            this.downloadStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(243, 82);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 13);
            this.label16.TabIndex = 0;
            this.label16.Text = "Est. Finish Time:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // downloadStartStopButton
            // 
            this.downloadStartStopButton.Location = new System.Drawing.Point(8, 60);
            this.downloadStartStopButton.Name = "downloadStartStopButton";
            this.downloadStartStopButton.Size = new System.Drawing.Size(153, 40);
            this.downloadStartStopButton.TabIndex = 34;
            this.downloadStartStopButton.Text = "Start\r\nDownload";
            this.downloadStartStopButton.UseVisualStyleBackColor = true;
            this.downloadStartStopButton.Click += new System.EventHandler(this.taskStartStopButton_Click);
            // 
            // downloadProgressBar
            // 
            this.downloadProgressBar.Location = new System.Drawing.Point(8, 35);
            this.downloadProgressBar.Name = "downloadProgressBar";
            this.downloadProgressBar.Size = new System.Drawing.Size(463, 19);
            this.downloadProgressBar.TabIndex = 0;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(243, 63);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 13);
            this.label18.TabIndex = 0;
            this.label18.Text = "Start Time:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // downloadStartTimeLabel
            // 
            this.downloadStartTimeLabel.AutoSize = true;
            this.downloadStartTimeLabel.Location = new System.Drawing.Point(331, 63);
            this.downloadStartTimeLabel.Name = "downloadStartTimeLabel";
            this.downloadStartTimeLabel.Size = new System.Drawing.Size(49, 13);
            this.downloadStartTimeLabel.TabIndex = 0;
            this.downloadStartTimeLabel.Text = "00:00:00";
            this.downloadStartTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // downloadEstFinishTimeLabel
            // 
            this.downloadEstFinishTimeLabel.AutoSize = true;
            this.downloadEstFinishTimeLabel.Location = new System.Drawing.Point(331, 82);
            this.downloadEstFinishTimeLabel.Name = "downloadEstFinishTimeLabel";
            this.downloadEstFinishTimeLabel.Size = new System.Drawing.Size(139, 13);
            this.downloadEstFinishTimeLabel.TabIndex = 0;
            this.downloadEstFinishTimeLabel.Text = "00:00:00 (00:00:00 to finish)";
            this.downloadEstFinishTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(778, 26);
            this.label15.TabIndex = 0;
            this.label15.Text = "Press \"Start Download\" to start the download phase, or press \"Skip\" to skip it. T" +
                "his phase can take some time, depends on your internet connection speed, and the" +
                "\r\nnumber of stocks in your list.";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(5, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(199, 14);
            this.label14.TabIndex = 0;
            this.label14.Text = "Step 5: Download stock data...";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.groupBox8);
            this.tabPage7.Controls.Add(this.label35);
            this.tabPage7.Controls.Add(this.label36);
            this.tabPage7.Controls.Add(this.groupBox3);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(789, 384);
            this.tabPage7.TabIndex = 5;
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox8.Controls.Add(this.stockListDataGridView2);
            this.groupBox8.Controls.Add(this.label34);
            this.groupBox8.Location = new System.Drawing.Point(486, 62);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(296, 242);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Stocks Analysis Status";
            // 
            // stockListDataGridView2
            // 
            this.stockListDataGridView2.AllowUserToAddRows = false;
            this.stockListDataGridView2.AllowUserToDeleteRows = false;
            this.stockListDataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.stockListDataGridView2.AutoGenerateColumns = false;
            this.stockListDataGridView2.ColumnHeadersHeight = 22;
            this.stockListDataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.stockListDataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stockAnalysisSymbolColumn,
            this.stockAnalysisAnalysisColumn});
            this.stockListDataGridView2.DataSource = this.stocksTableBindingSource;
            this.stockListDataGridView2.Location = new System.Drawing.Point(9, 35);
            this.stockListDataGridView2.Name = "stockListDataGridView2";
            this.stockListDataGridView2.ReadOnly = true;
            this.stockListDataGridView2.RowHeadersVisible = false;
            this.stockListDataGridView2.RowHeadersWidth = 16;
            this.stockListDataGridView2.RowTemplate.Height = 20;
            this.stockListDataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.stockListDataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.stockListDataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.stockListDataGridView2.Size = new System.Drawing.Size(279, 195);
            this.stockListDataGridView2.TabIndex = 0;
            // 
            // stockAnalysisSymbolColumn
            // 
            this.stockAnalysisSymbolColumn.DataPropertyName = "Symbol";
            this.stockAnalysisSymbolColumn.HeaderText = "Symbol";
            this.stockAnalysisSymbolColumn.Name = "stockAnalysisSymbolColumn";
            this.stockAnalysisSymbolColumn.ReadOnly = true;
            this.stockAnalysisSymbolColumn.Width = 95;
            // 
            // stockAnalysisAnalysisColumn
            // 
            this.stockAnalysisAnalysisColumn.DataPropertyName = "Analysis";
            this.stockAnalysisAnalysisColumn.HeaderText = "Analysis";
            this.stockAnalysisAnalysisColumn.Name = "stockAnalysisAnalysisColumn";
            this.stockAnalysisAnalysisColumn.ReadOnly = true;
            this.stockAnalysisAnalysisColumn.Width = 180;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 19);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(40, 13);
            this.label34.TabIndex = 0;
            this.label34.Text = "Status:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(6, 25);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(747, 26);
            this.label35.TabIndex = 0;
            this.label35.Text = "Press \"Start Analysis\" to start the analysis phase. This phase can take some time" +
                ", depends on your computer speed, the number of stocks in your list, and the\r\nse" +
                "ttings of the strategy filters.";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(5, 3);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(189, 14);
            this.label36.TabIndex = 0;
            this.label36.Text = "Step 6: Analyis Stocks Data...";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox3.Controls.Add(this.analysisStatusLabel);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.analysisStartStopButton);
            this.groupBox3.Controls.Add(this.analysisProgressBar);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.analysisStartTimeLabel);
            this.groupBox3.Controls.Add(this.analysisEstFinishTimeLabel);
            this.groupBox3.Location = new System.Drawing.Point(3, 62);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(477, 134);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Analysis Progress";
            // 
            // analysisStatusLabel
            // 
            this.analysisStatusLabel.Location = new System.Drawing.Point(5, 16);
            this.analysisStatusLabel.Name = "analysisStatusLabel";
            this.analysisStatusLabel.Size = new System.Drawing.Size(252, 19);
            this.analysisStatusLabel.TabIndex = 20;
            this.analysisStatusLabel.Text = "Status:";
            this.analysisStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(243, 82);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(84, 13);
            this.label21.TabIndex = 0;
            this.label21.Text = "Est. Finish Time:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // analysisStartStopButton
            // 
            this.analysisStartStopButton.Location = new System.Drawing.Point(8, 60);
            this.analysisStartStopButton.Name = "analysisStartStopButton";
            this.analysisStartStopButton.Size = new System.Drawing.Size(153, 40);
            this.analysisStartStopButton.TabIndex = 39;
            this.analysisStartStopButton.Text = "Start\r\nAnalysis";
            this.analysisStartStopButton.UseVisualStyleBackColor = true;
            this.analysisStartStopButton.Click += new System.EventHandler(this.taskStartStopButton_Click);
            // 
            // analysisProgressBar
            // 
            this.analysisProgressBar.Location = new System.Drawing.Point(8, 35);
            this.analysisProgressBar.Name = "analysisProgressBar";
            this.analysisProgressBar.Size = new System.Drawing.Size(462, 19);
            this.analysisProgressBar.TabIndex = 19;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(243, 63);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(58, 13);
            this.label23.TabIndex = 0;
            this.label23.Text = "Start Time:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // analysisStartTimeLabel
            // 
            this.analysisStartTimeLabel.AutoSize = true;
            this.analysisStartTimeLabel.Location = new System.Drawing.Point(331, 63);
            this.analysisStartTimeLabel.Name = "analysisStartTimeLabel";
            this.analysisStartTimeLabel.Size = new System.Drawing.Size(49, 13);
            this.analysisStartTimeLabel.TabIndex = 0;
            this.analysisStartTimeLabel.Text = "00:00:00";
            this.analysisStartTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // analysisEstFinishTimeLabel
            // 
            this.analysisEstFinishTimeLabel.AutoSize = true;
            this.analysisEstFinishTimeLabel.Location = new System.Drawing.Point(331, 82);
            this.analysisEstFinishTimeLabel.Name = "analysisEstFinishTimeLabel";
            this.analysisEstFinishTimeLabel.Size = new System.Drawing.Size(139, 13);
            this.analysisEstFinishTimeLabel.TabIndex = 0;
            this.analysisEstFinishTimeLabel.Text = "00:00:00 (00:00:00 to finish)";
            this.analysisEstFinishTimeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label5);
            this.tabPage8.Controls.Add(this.moveDaysToExpTextBox);
            this.tabPage8.Controls.Add(this.moveButton);
            this.tabPage8.Controls.Add(this.resultLoadButton);
            this.tabPage8.Controls.Add(this.resultSaveButton);
            this.tabPage8.Controls.Add(this.label30);
            this.tabPage8.Controls.Add(this.moveHistoricalVolatilityTextBox);
            this.tabPage8.Controls.Add(this.label27);
            this.tabPage8.Controls.Add(this.label26);
            this.tabPage8.Controls.Add(this.moveImpiledVolatilityTextBox);
            this.tabPage8.Controls.Add(this.movePriceTextBox);
            this.tabPage8.Controls.Add(this.movePositionTextBox);
            this.tabPage8.Controls.Add(this.label25);
            this.tabPage8.Controls.Add(this.resultsDataGridView);
            this.tabPage8.Controls.Add(this.label19);
            this.tabPage8.Location = new System.Drawing.Point(4, 25);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(789, 384);
            this.tabPage8.TabIndex = 4;
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(441, 327);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 47;
            this.label5.Text = "Days to Expiration:";
            // 
            // moveDaysToExpTextBox
            // 
            this.moveDaysToExpTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.moveDaysToExpTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moveDaysToExpTextBox.Location = new System.Drawing.Point(542, 323);
            this.moveDaysToExpTextBox.Name = "moveDaysToExpTextBox";
            this.moveDaysToExpTextBox.Size = new System.Drawing.Size(46, 20);
            this.moveDaysToExpTextBox.TabIndex = 46;
            this.moveDaysToExpTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // moveButton
            // 
            this.moveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.moveButton.Image = global::OptionsOracle.Properties.Resources.forward;
            this.moveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.moveButton.Location = new System.Drawing.Point(593, 294);
            this.moveButton.Name = "moveButton";
            this.moveButton.Size = new System.Drawing.Size(90, 50);
            this.moveButton.TabIndex = 32;
            this.moveButton.Text = "         Strategy\r\n         Table";
            this.moveButton.UseVisualStyleBackColor = true;
            this.moveButton.Click += new System.EventHandler(this.moveButton_Click);
            // 
            // resultLoadButton
            // 
            this.resultLoadButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.resultLoadButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.resultLoadButton.Location = new System.Drawing.Point(689, 294);
            this.resultLoadButton.Name = "resultLoadButton";
            this.resultLoadButton.Size = new System.Drawing.Size(90, 24);
            this.resultLoadButton.TabIndex = 44;
            this.resultLoadButton.Text = "Load";
            this.resultLoadButton.UseVisualStyleBackColor = true;
            this.resultLoadButton.Click += new System.EventHandler(this.resultLoadButton_Click);
            // 
            // resultSaveButton
            // 
            this.resultSaveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.resultSaveButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.resultSaveButton.Location = new System.Drawing.Point(689, 322);
            this.resultSaveButton.Name = "resultSaveButton";
            this.resultSaveButton.Size = new System.Drawing.Size(90, 24);
            this.resultSaveButton.TabIndex = 45;
            this.resultSaveButton.Text = "Save";
            this.resultSaveButton.UseVisualStyleBackColor = true;
            this.resultSaveButton.Click += new System.EventHandler(this.resultSaveButton_Click);
            // 
            // label30
            // 
            this.label30.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(286, 327);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(43, 13);
            this.label30.TabIndex = 0;
            this.label30.Text = "His-Vol:";
            // 
            // moveHistoricalVolatilityTextBox
            // 
            this.moveHistoricalVolatilityTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.moveHistoricalVolatilityTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moveHistoricalVolatilityTextBox.Location = new System.Drawing.Point(335, 323);
            this.moveHistoricalVolatilityTextBox.Name = "moveHistoricalVolatilityTextBox";
            this.moveHistoricalVolatilityTextBox.Size = new System.Drawing.Size(54, 20);
            this.moveHistoricalVolatilityTextBox.TabIndex = 0;
            this.moveHistoricalVolatilityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(167, 327);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(45, 13);
            this.label27.TabIndex = 0;
            this.label27.Text = "Imp-Vol:";
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(6, 327);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(88, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "Last Stock Price:";
            // 
            // moveImpiledVolatilityTextBox
            // 
            this.moveImpiledVolatilityTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.moveImpiledVolatilityTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moveImpiledVolatilityTextBox.Location = new System.Drawing.Point(218, 323);
            this.moveImpiledVolatilityTextBox.Name = "moveImpiledVolatilityTextBox";
            this.moveImpiledVolatilityTextBox.Size = new System.Drawing.Size(54, 20);
            this.moveImpiledVolatilityTextBox.TabIndex = 0;
            this.moveImpiledVolatilityTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // movePriceTextBox
            // 
            this.movePriceTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.movePriceTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movePriceTextBox.Location = new System.Drawing.Point(99, 323);
            this.movePriceTextBox.Name = "movePriceTextBox";
            this.movePriceTextBox.Size = new System.Drawing.Size(54, 20);
            this.movePriceTextBox.TabIndex = 0;
            this.movePriceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // movePositionTextBox
            // 
            this.movePositionTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.movePositionTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.movePositionTextBox.Location = new System.Drawing.Point(98, 295);
            this.movePositionTextBox.Name = "movePositionTextBox";
            this.movePositionTextBox.Size = new System.Drawing.Size(489, 20);
            this.movePositionTextBox.TabIndex = 0;
            this.movePositionTextBox.TextChanged += new System.EventHandler(this.moveTextBox_TextChanged);
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(4, 299);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(92, 13);
            this.label25.TabIndex = 0;
            this.label25.Text = "Selected Position:";
            // 
            // resultsDataGridView
            // 
            this.resultsDataGridView.AllowUserToAddRows = false;
            this.resultsDataGridView.AllowUserToDeleteRows = false;
            this.resultsDataGridView.AllowUserToOrderColumns = true;
            this.resultsDataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.resultsDataGridView.AutoGenerateColumns = false;
            this.resultsDataGridView.ColumnHeadersHeight = 36;
            this.resultsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.resultsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.wizardResultsIndexColumn,
            this.wizardResultsStockColumn,
            this.wizardResultsPositionColumn,
            this.wizardResultsEndDateColumn,
            this.wizardResultsNetInvestmentColumn,
            this.wizardResultsTotalDebitColumn,
            this.wizardResultsMaxProfitPotentialColumn,
            this.wizardResultsMaxProfitPotentialPrcColumn,
            this.wizardResultsMaxLossRiskColumn,
            this.wizardResultsMaxLossRiskPrcColumn,
            this.wizardResultsLowerBreakevenColumn,
            this.wizardResultsUpperBreakevenColumn,
            this.wizardResultsReturnAtMovementColumn,
            this.wizardResultsReturnAtMovementPrcColumn,
            this.wizardResultsMeanReturnColumn,
            this.wizardResultsMeanReturnPrcColumn,
            this.wizardResultsTotalDeltaColumn,
            this.wizardResultsTotalGammaColumn,
            this.wizardResultsTotalThetaColumn,
            this.wizardResultsTotalVegaColumn,
            this.wizardResultsInterestPaidColumn,
            this.wizardResultsBreakevenProbColumn,
            this.wizardResultsProtectionProbColumn,
            this.wizardResultsProfitLossRatioColumn,
            this.wizardResultsStockLastPriceColumn,
            this.wizardResultsStockImpVolatilityColumn,
            this.wizardResultsStockHisVolatilityColumn,
            this.wizardResultsIndicator1Column,
            this.wizardResultsIndicator2Column});
            this.resultsDataGridView.DataSource = this.resultsTableBindingSource;
            this.resultsDataGridView.Location = new System.Drawing.Point(6, 25);
            this.resultsDataGridView.Name = "resultsDataGridView";
            this.resultsDataGridView.ReadOnly = true;
            this.resultsDataGridView.RowHeadersVisible = false;
            this.resultsDataGridView.RowHeadersWidth = 16;
            this.resultsDataGridView.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Black;
            this.resultsDataGridView.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Cornsilk;
            this.resultsDataGridView.RowTemplate.Height = 20;
            this.resultsDataGridView.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.resultsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.resultsDataGridView.Size = new System.Drawing.Size(775, 263);
            this.resultsDataGridView.TabIndex = 40;
            this.resultsDataGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.resultsDataGridView_CellDoubleClick);
            this.resultsDataGridView.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.resultsDataGridView_CellFormatting);
            this.resultsDataGridView.SelectionChanged += new System.EventHandler(this.resultsDataGridView_SelectionChanged);
            // 
            // wizardResultsIndexColumn
            // 
            this.wizardResultsIndexColumn.DataPropertyName = "Index";
            dataGridViewCellStyle3.Format = "0000";
            dataGridViewCellStyle3.NullValue = null;
            this.wizardResultsIndexColumn.DefaultCellStyle = dataGridViewCellStyle3;
            this.wizardResultsIndexColumn.Frozen = true;
            this.wizardResultsIndexColumn.HeaderText = "Id";
            this.wizardResultsIndexColumn.Name = "wizardResultsIndexColumn";
            this.wizardResultsIndexColumn.ReadOnly = true;
            this.wizardResultsIndexColumn.Width = 32;
            // 
            // wizardResultsStockColumn
            // 
            this.wizardResultsStockColumn.DataPropertyName = "Stock";
            this.wizardResultsStockColumn.HeaderText = "Stock";
            this.wizardResultsStockColumn.Name = "wizardResultsStockColumn";
            this.wizardResultsStockColumn.ReadOnly = true;
            this.wizardResultsStockColumn.Width = 42;
            // 
            // wizardResultsPositionColumn
            // 
            this.wizardResultsPositionColumn.DataPropertyName = "Position";
            this.wizardResultsPositionColumn.HeaderText = "Position";
            this.wizardResultsPositionColumn.Name = "wizardResultsPositionColumn";
            this.wizardResultsPositionColumn.ReadOnly = true;
            this.wizardResultsPositionColumn.Visible = false;
            // 
            // wizardResultsEndDateColumn
            // 
            this.wizardResultsEndDateColumn.DataPropertyName = "EndDate";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.Format = "dd-MMM-yy";
            this.wizardResultsEndDateColumn.DefaultCellStyle = dataGridViewCellStyle4;
            this.wizardResultsEndDateColumn.HeaderText = "End Date";
            this.wizardResultsEndDateColumn.Name = "wizardResultsEndDateColumn";
            this.wizardResultsEndDateColumn.ReadOnly = true;
            this.wizardResultsEndDateColumn.Width = 65;
            // 
            // wizardResultsNetInvestmentColumn
            // 
            this.wizardResultsNetInvestmentColumn.DataPropertyName = "NetInvestment";
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle5.Format = "N2";
            dataGridViewCellStyle5.NullValue = "N/A";
            this.wizardResultsNetInvestmentColumn.DefaultCellStyle = dataGridViewCellStyle5;
            this.wizardResultsNetInvestmentColumn.HeaderText = "Total Investment";
            this.wizardResultsNetInvestmentColumn.Name = "wizardResultsNetInvestmentColumn";
            this.wizardResultsNetInvestmentColumn.ReadOnly = true;
            this.wizardResultsNetInvestmentColumn.Width = 75;
            // 
            // wizardResultsTotalDebitColumn
            // 
            this.wizardResultsTotalDebitColumn.DataPropertyName = "TotalDebit";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N2";
            dataGridViewCellStyle6.NullValue = "N/A";
            this.wizardResultsTotalDebitColumn.DefaultCellStyle = dataGridViewCellStyle6;
            this.wizardResultsTotalDebitColumn.HeaderText = "Total Debit";
            this.wizardResultsTotalDebitColumn.Name = "wizardResultsTotalDebitColumn";
            this.wizardResultsTotalDebitColumn.ReadOnly = true;
            this.wizardResultsTotalDebitColumn.Width = 75;
            // 
            // wizardResultsMaxProfitPotentialColumn
            // 
            this.wizardResultsMaxProfitPotentialColumn.DataPropertyName = "MaxProfitPotential";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N2";
            dataGridViewCellStyle7.NullValue = "N/A";
            this.wizardResultsMaxProfitPotentialColumn.DefaultCellStyle = dataGridViewCellStyle7;
            this.wizardResultsMaxProfitPotentialColumn.HeaderText = "Max Profit Potential";
            this.wizardResultsMaxProfitPotentialColumn.Name = "wizardResultsMaxProfitPotentialColumn";
            this.wizardResultsMaxProfitPotentialColumn.ReadOnly = true;
            this.wizardResultsMaxProfitPotentialColumn.Width = 70;
            // 
            // wizardResultsMaxProfitPotentialPrcColumn
            // 
            this.wizardResultsMaxProfitPotentialPrcColumn.DataPropertyName = "MaxProfitPotentialPrc";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "P2";
            dataGridViewCellStyle8.NullValue = "N/A";
            this.wizardResultsMaxProfitPotentialPrcColumn.DefaultCellStyle = dataGridViewCellStyle8;
            this.wizardResultsMaxProfitPotentialPrcColumn.HeaderText = "Max Profit Potential %";
            this.wizardResultsMaxProfitPotentialPrcColumn.Name = "wizardResultsMaxProfitPotentialPrcColumn";
            this.wizardResultsMaxProfitPotentialPrcColumn.ReadOnly = true;
            this.wizardResultsMaxProfitPotentialPrcColumn.Visible = false;
            this.wizardResultsMaxProfitPotentialPrcColumn.Width = 70;
            // 
            // wizardResultsMaxLossRiskColumn
            // 
            this.wizardResultsMaxLossRiskColumn.DataPropertyName = "MaxLossRisk";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N2";
            dataGridViewCellStyle9.NullValue = "N/A";
            this.wizardResultsMaxLossRiskColumn.DefaultCellStyle = dataGridViewCellStyle9;
            this.wizardResultsMaxLossRiskColumn.HeaderText = "Max Loss Risk";
            this.wizardResultsMaxLossRiskColumn.Name = "wizardResultsMaxLossRiskColumn";
            this.wizardResultsMaxLossRiskColumn.ReadOnly = true;
            this.wizardResultsMaxLossRiskColumn.Width = 70;
            // 
            // wizardResultsMaxLossRiskPrcColumn
            // 
            this.wizardResultsMaxLossRiskPrcColumn.DataPropertyName = "MaxLossRiskPrc";
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle10.Format = "P2";
            dataGridViewCellStyle10.NullValue = "N/A";
            this.wizardResultsMaxLossRiskPrcColumn.DefaultCellStyle = dataGridViewCellStyle10;
            this.wizardResultsMaxLossRiskPrcColumn.HeaderText = "Max Loss Risk %";
            this.wizardResultsMaxLossRiskPrcColumn.Name = "wizardResultsMaxLossRiskPrcColumn";
            this.wizardResultsMaxLossRiskPrcColumn.ReadOnly = true;
            this.wizardResultsMaxLossRiskPrcColumn.Visible = false;
            this.wizardResultsMaxLossRiskPrcColumn.Width = 70;
            // 
            // wizardResultsLowerBreakevenColumn
            // 
            this.wizardResultsLowerBreakevenColumn.DataPropertyName = "LowerBreakeven";
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle11.Format = "P2";
            dataGridViewCellStyle11.NullValue = "N/A";
            this.wizardResultsLowerBreakevenColumn.DefaultCellStyle = dataGridViewCellStyle11;
            this.wizardResultsLowerBreakevenColumn.HeaderText = "Lower Prot. / Breakeven";
            this.wizardResultsLowerBreakevenColumn.Name = "wizardResultsLowerBreakevenColumn";
            this.wizardResultsLowerBreakevenColumn.ReadOnly = true;
            this.wizardResultsLowerBreakevenColumn.Width = 75;
            // 
            // wizardResultsUpperBreakevenColumn
            // 
            this.wizardResultsUpperBreakevenColumn.DataPropertyName = "UpperBreakeven";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle12.Format = "P2";
            dataGridViewCellStyle12.NullValue = "N/A";
            this.wizardResultsUpperBreakevenColumn.DefaultCellStyle = dataGridViewCellStyle12;
            this.wizardResultsUpperBreakevenColumn.HeaderText = "Upper Prot. / Breakeven";
            this.wizardResultsUpperBreakevenColumn.Name = "wizardResultsUpperBreakevenColumn";
            this.wizardResultsUpperBreakevenColumn.ReadOnly = true;
            this.wizardResultsUpperBreakevenColumn.Width = 75;
            // 
            // wizardResultsReturnAtMovementColumn
            // 
            this.wizardResultsReturnAtMovementColumn.DataPropertyName = "ReturnAtMovement";
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle13.Format = "N2";
            dataGridViewCellStyle13.NullValue = "N/A";
            this.wizardResultsReturnAtMovementColumn.DefaultCellStyle = dataGridViewCellStyle13;
            this.wizardResultsReturnAtMovementColumn.HeaderText = "Return if Unchanged";
            this.wizardResultsReturnAtMovementColumn.Name = "wizardResultsReturnAtMovementColumn";
            this.wizardResultsReturnAtMovementColumn.ReadOnly = true;
            this.wizardResultsReturnAtMovementColumn.Width = 75;
            // 
            // wizardResultsReturnAtMovementPrcColumn
            // 
            this.wizardResultsReturnAtMovementPrcColumn.DataPropertyName = "ReturnAtMovementPrc";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle14.Format = "P2";
            dataGridViewCellStyle14.NullValue = "N/A";
            this.wizardResultsReturnAtMovementPrcColumn.DefaultCellStyle = dataGridViewCellStyle14;
            this.wizardResultsReturnAtMovementPrcColumn.HeaderText = "1Mo % Retn if Unchanged";
            this.wizardResultsReturnAtMovementPrcColumn.Name = "wizardResultsReturnAtMovementPrcColumn";
            this.wizardResultsReturnAtMovementPrcColumn.ReadOnly = true;
            this.wizardResultsReturnAtMovementPrcColumn.Width = 75;
            // 
            // wizardResultsMeanReturnColumn
            // 
            this.wizardResultsMeanReturnColumn.DataPropertyName = "MeanReturn";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle15.Format = "N2";
            dataGridViewCellStyle15.NullValue = "N/A";
            this.wizardResultsMeanReturnColumn.DefaultCellStyle = dataGridViewCellStyle15;
            this.wizardResultsMeanReturnColumn.HeaderText = "Expected Return";
            this.wizardResultsMeanReturnColumn.Name = "wizardResultsMeanReturnColumn";
            this.wizardResultsMeanReturnColumn.ReadOnly = true;
            this.wizardResultsMeanReturnColumn.Width = 75;
            // 
            // wizardResultsMeanReturnPrcColumn
            // 
            this.wizardResultsMeanReturnPrcColumn.DataPropertyName = "MeanReturnPrc";
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle16.Format = "P2";
            dataGridViewCellStyle16.NullValue = "N/A";
            this.wizardResultsMeanReturnPrcColumn.DefaultCellStyle = dataGridViewCellStyle16;
            this.wizardResultsMeanReturnPrcColumn.HeaderText = "1Mo % Expc-Return";
            this.wizardResultsMeanReturnPrcColumn.Name = "wizardResultsMeanReturnPrcColumn";
            this.wizardResultsMeanReturnPrcColumn.ReadOnly = true;
            this.wizardResultsMeanReturnPrcColumn.Width = 75;
            // 
            // wizardResultsTotalDeltaColumn
            // 
            this.wizardResultsTotalDeltaColumn.DataPropertyName = "TotalDelta";
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle17.Format = "N2";
            dataGridViewCellStyle17.NullValue = "N/A";
            this.wizardResultsTotalDeltaColumn.DefaultCellStyle = dataGridViewCellStyle17;
            this.wizardResultsTotalDeltaColumn.HeaderText = "Total Delta";
            this.wizardResultsTotalDeltaColumn.Name = "wizardResultsTotalDeltaColumn";
            this.wizardResultsTotalDeltaColumn.ReadOnly = true;
            this.wizardResultsTotalDeltaColumn.Width = 65;
            // 
            // wizardResultsTotalGammaColumn
            // 
            this.wizardResultsTotalGammaColumn.DataPropertyName = "TotalGamma";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle18.Format = "N2";
            dataGridViewCellStyle18.NullValue = "N/A";
            this.wizardResultsTotalGammaColumn.DefaultCellStyle = dataGridViewCellStyle18;
            this.wizardResultsTotalGammaColumn.HeaderText = "Total Gamma";
            this.wizardResultsTotalGammaColumn.Name = "wizardResultsTotalGammaColumn";
            this.wizardResultsTotalGammaColumn.ReadOnly = true;
            this.wizardResultsTotalGammaColumn.Width = 65;
            // 
            // wizardResultsTotalThetaColumn
            // 
            this.wizardResultsTotalThetaColumn.DataPropertyName = "TotalTheta";
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle19.Format = "N2";
            dataGridViewCellStyle19.NullValue = "N/A";
            this.wizardResultsTotalThetaColumn.DefaultCellStyle = dataGridViewCellStyle19;
            this.wizardResultsTotalThetaColumn.HeaderText = "Total Theta";
            this.wizardResultsTotalThetaColumn.Name = "wizardResultsTotalThetaColumn";
            this.wizardResultsTotalThetaColumn.ReadOnly = true;
            this.wizardResultsTotalThetaColumn.Width = 65;
            // 
            // wizardResultsTotalVegaColumn
            // 
            this.wizardResultsTotalVegaColumn.DataPropertyName = "TotalVega";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle20.Format = "N2";
            dataGridViewCellStyle20.NullValue = "N/A";
            this.wizardResultsTotalVegaColumn.DefaultCellStyle = dataGridViewCellStyle20;
            this.wizardResultsTotalVegaColumn.HeaderText = "Total Vega";
            this.wizardResultsTotalVegaColumn.Name = "wizardResultsTotalVegaColumn";
            this.wizardResultsTotalVegaColumn.ReadOnly = true;
            this.wizardResultsTotalVegaColumn.Width = 65;
            // 
            // wizardResultsInterestPaidColumn
            // 
            this.wizardResultsInterestPaidColumn.DataPropertyName = "InterestPaid";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle21.Format = "N2";
            dataGridViewCellStyle21.NullValue = "N/A";
            this.wizardResultsInterestPaidColumn.DefaultCellStyle = dataGridViewCellStyle21;
            this.wizardResultsInterestPaidColumn.HeaderText = "Interest Paid";
            this.wizardResultsInterestPaidColumn.Name = "wizardResultsInterestPaidColumn";
            this.wizardResultsInterestPaidColumn.ReadOnly = true;
            this.wizardResultsInterestPaidColumn.Width = 65;
            // 
            // wizardResultsBreakevenProbColumn
            // 
            this.wizardResultsBreakevenProbColumn.DataPropertyName = "BreakevenProb";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle22.Format = "P2";
            dataGridViewCellStyle22.NullValue = "N/A";
            this.wizardResultsBreakevenProbColumn.DefaultCellStyle = dataGridViewCellStyle22;
            this.wizardResultsBreakevenProbColumn.HeaderText = "Breakeven Prob";
            this.wizardResultsBreakevenProbColumn.Name = "wizardResultsBreakevenProbColumn";
            this.wizardResultsBreakevenProbColumn.ReadOnly = true;
            this.wizardResultsBreakevenProbColumn.Width = 65;
            // 
            // wizardResultsProtectionProbColumn
            // 
            this.wizardResultsProtectionProbColumn.DataPropertyName = "ProtectionProb";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle23.Format = "P2";
            dataGridViewCellStyle23.NullValue = "N/A";
            this.wizardResultsProtectionProbColumn.DefaultCellStyle = dataGridViewCellStyle23;
            this.wizardResultsProtectionProbColumn.HeaderText = "Protection Prob";
            this.wizardResultsProtectionProbColumn.Name = "wizardResultsProtectionProbColumn";
            this.wizardResultsProtectionProbColumn.ReadOnly = true;
            this.wizardResultsProtectionProbColumn.Width = 65;
            // 
            // wizardResultsProfitLossRatioColumn
            // 
            this.wizardResultsProfitLossRatioColumn.DataPropertyName = "ProfitLossRatio";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle24.Format = "N2";
            dataGridViewCellStyle24.NullValue = "N/A";
            this.wizardResultsProfitLossRatioColumn.DefaultCellStyle = dataGridViewCellStyle24;
            this.wizardResultsProfitLossRatioColumn.HeaderText = "Profit/Loss Ratio";
            this.wizardResultsProfitLossRatioColumn.Name = "wizardResultsProfitLossRatioColumn";
            this.wizardResultsProfitLossRatioColumn.ReadOnly = true;
            this.wizardResultsProfitLossRatioColumn.Width = 65;
            // 
            // wizardResultsStockLastPriceColumn
            // 
            this.wizardResultsStockLastPriceColumn.DataPropertyName = "StockLastPrice";
            this.wizardResultsStockLastPriceColumn.HeaderText = "StockLastPrice";
            this.wizardResultsStockLastPriceColumn.Name = "wizardResultsStockLastPriceColumn";
            this.wizardResultsStockLastPriceColumn.ReadOnly = true;
            this.wizardResultsStockLastPriceColumn.Visible = false;
            this.wizardResultsStockLastPriceColumn.Width = 70;
            // 
            // wizardResultsStockImpVolatilityColumn
            // 
            this.wizardResultsStockImpVolatilityColumn.DataPropertyName = "StockImpVolatility";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle25.Format = "N2";
            this.wizardResultsStockImpVolatilityColumn.DefaultCellStyle = dataGridViewCellStyle25;
            this.wizardResultsStockImpVolatilityColumn.HeaderText = "Stock ImpVol";
            this.wizardResultsStockImpVolatilityColumn.Name = "wizardResultsStockImpVolatilityColumn";
            this.wizardResultsStockImpVolatilityColumn.ReadOnly = true;
            this.wizardResultsStockImpVolatilityColumn.Width = 70;
            // 
            // wizardResultsStockHisVolatilityColumn
            // 
            this.wizardResultsStockHisVolatilityColumn.DataPropertyName = "StockHisVolatility";
            this.wizardResultsStockHisVolatilityColumn.HeaderText = "StockHisVolatility";
            this.wizardResultsStockHisVolatilityColumn.Name = "wizardResultsStockHisVolatilityColumn";
            this.wizardResultsStockHisVolatilityColumn.ReadOnly = true;
            this.wizardResultsStockHisVolatilityColumn.Visible = false;
            this.wizardResultsStockHisVolatilityColumn.Width = 70;
            // 
            // wizardResultsIndicator1Column
            // 
            this.wizardResultsIndicator1Column.DataPropertyName = "Indicator1";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle26.Format = "N2";
            this.wizardResultsIndicator1Column.DefaultCellStyle = dataGridViewCellStyle26;
            this.wizardResultsIndicator1Column.HeaderText = "Ind 1";
            this.wizardResultsIndicator1Column.Name = "wizardResultsIndicator1Column";
            this.wizardResultsIndicator1Column.ReadOnly = true;
            this.wizardResultsIndicator1Column.Visible = false;
            // 
            // wizardResultsIndicator2Column
            // 
            this.wizardResultsIndicator2Column.DataPropertyName = "Indicator2";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle27.Format = "N2";
            this.wizardResultsIndicator2Column.DefaultCellStyle = dataGridViewCellStyle27;
            this.wizardResultsIndicator2Column.HeaderText = "Ind 2";
            this.wizardResultsIndicator2Column.Name = "wizardResultsIndicator2Column";
            this.wizardResultsIndicator2Column.ReadOnly = true;
            this.wizardResultsIndicator2Column.Visible = false;
            // 
            // resultsTableBindingSource
            // 
            this.resultsTableBindingSource.DataMember = "ResultsTable";
            this.resultsTableBindingSource.DataSource = this.wizardSet;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(5, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(161, 14);
            this.label19.TabIndex = 0;
            this.label19.Text = "Step 7: Review Results...";
            // 
            // skipAllButton
            // 
            this.skipAllButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.skipAllButton.Location = new System.Drawing.Point(696, 393);
            this.skipAllButton.Name = "skipAllButton";
            this.skipAllButton.Size = new System.Drawing.Size(90, 24);
            this.skipAllButton.TabIndex = 6;
            this.skipAllButton.Text = "Skip All >>";
            this.skipAllButton.UseVisualStyleBackColor = true;
            this.skipAllButton.Click += new System.EventHandler(this.skipAllButton_Click);
            // 
            // ReturnAtMovementPrc
            // 
            this.ReturnAtMovementPrc.DataPropertyName = "ReturnAtMovementPrc";
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle28.Format = "P2";
            dataGridViewCellStyle28.NullValue = "N/A";
            this.ReturnAtMovementPrc.DefaultCellStyle = dataGridViewCellStyle28;
            this.ReturnAtMovementPrc.HeaderText = "1Mo % Return";
            this.ReturnAtMovementPrc.Name = "ReturnAtMovementPrc";
            this.ReturnAtMovementPrc.ReadOnly = true;
            this.ReturnAtMovementPrc.ToolTipText = "Return at specificed stock price movement from last price factored to 1 month ret" +
                "urn %";
            this.ReturnAtMovementPrc.Width = 65;
            // 
            // nextButton
            // 
            this.nextButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.nextButton.Enabled = false;
            this.nextButton.Location = new System.Drawing.Point(696, 420);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(90, 24);
            this.nextButton.TabIndex = 5;
            this.nextButton.Text = "Next >>";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // backButton
            // 
            this.backButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.backButton.Enabled = false;
            this.backButton.Location = new System.Drawing.Point(600, 420);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(90, 24);
            this.backButton.TabIndex = 6;
            this.backButton.Text = "<< Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // taskWorker
            // 
            this.taskWorker.WorkerReportsProgress = true;
            this.taskWorker.WorkerSupportsCancellation = true;
            this.taskWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.taskWorker_DoWork);
            this.taskWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.taskWorker_RunWorkerCompleted);
            this.taskWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.taskWorker_ProgressChanged);
            // 
            // taskTimer
            // 
            this.taskTimer.Interval = 1000;
            this.taskTimer.Tick += new System.EventHandler(this.taskTimer_Tick);
            // 
            // stockDataGridViewTextBoxColumn
            // 
            this.stockDataGridViewTextBoxColumn.DataPropertyName = "Stock";
            this.stockDataGridViewTextBoxColumn.Frozen = true;
            this.stockDataGridViewTextBoxColumn.HeaderText = "Stock";
            this.stockDataGridViewTextBoxColumn.Name = "stockDataGridViewTextBoxColumn";
            this.stockDataGridViewTextBoxColumn.ReadOnly = true;
            this.stockDataGridViewTextBoxColumn.Width = 40;
            // 
            // positionDataGridViewTextBoxColumn
            // 
            this.positionDataGridViewTextBoxColumn.DataPropertyName = "Position";
            this.positionDataGridViewTextBoxColumn.Frozen = true;
            this.positionDataGridViewTextBoxColumn.HeaderText = "Positions";
            this.positionDataGridViewTextBoxColumn.Name = "positionDataGridViewTextBoxColumn";
            this.positionDataGridViewTextBoxColumn.ReadOnly = true;
            this.positionDataGridViewTextBoxColumn.Visible = false;
            // 
            // endDateDataGridViewTextBoxColumn
            // 
            this.endDateDataGridViewTextBoxColumn.DataPropertyName = "EndDate";
            this.endDateDataGridViewTextBoxColumn.HeaderText = "End Date";
            this.endDateDataGridViewTextBoxColumn.Name = "endDateDataGridViewTextBoxColumn";
            this.endDateDataGridViewTextBoxColumn.ReadOnly = true;
            this.endDateDataGridViewTextBoxColumn.ToolTipText = "End date of strategy";
            this.endDateDataGridViewTextBoxColumn.Width = 60;
            // 
            // netInvestmentDataGridViewTextBoxColumn
            // 
            this.netInvestmentDataGridViewTextBoxColumn.DataPropertyName = "NetInvestment";
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle29.Format = "N2";
            dataGridViewCellStyle29.NullValue = "N/A";
            this.netInvestmentDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle29;
            this.netInvestmentDataGridViewTextBoxColumn.HeaderText = "Investment";
            this.netInvestmentDataGridViewTextBoxColumn.Name = "netInvestmentDataGridViewTextBoxColumn";
            this.netInvestmentDataGridViewTextBoxColumn.ReadOnly = true;
            this.netInvestmentDataGridViewTextBoxColumn.ToolTipText = "Net investment required for this position";
            this.netInvestmentDataGridViewTextBoxColumn.Width = 75;
            // 
            // maxProfitPotentialDataGridViewTextBoxColumn
            // 
            this.maxProfitPotentialDataGridViewTextBoxColumn.DataPropertyName = "MaxProfitPotential";
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle30.Format = "N2";
            dataGridViewCellStyle30.NullValue = "N/A";
            this.maxProfitPotentialDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle30;
            this.maxProfitPotentialDataGridViewTextBoxColumn.HeaderText = "Max Profit Potential";
            this.maxProfitPotentialDataGridViewTextBoxColumn.Name = "maxProfitPotentialDataGridViewTextBoxColumn";
            this.maxProfitPotentialDataGridViewTextBoxColumn.ReadOnly = true;
            this.maxProfitPotentialDataGridViewTextBoxColumn.ToolTipText = "Maximum profit potential";
            this.maxProfitPotentialDataGridViewTextBoxColumn.Width = 65;
            // 
            // maxLossRiskDataGridViewTextBoxColumn
            // 
            this.maxLossRiskDataGridViewTextBoxColumn.DataPropertyName = "MaxLossRisk";
            dataGridViewCellStyle31.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle31.Format = "N2";
            dataGridViewCellStyle31.NullValue = "N/A";
            this.maxLossRiskDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle31;
            this.maxLossRiskDataGridViewTextBoxColumn.HeaderText = "Max Loss Risk";
            this.maxLossRiskDataGridViewTextBoxColumn.Name = "maxLossRiskDataGridViewTextBoxColumn";
            this.maxLossRiskDataGridViewTextBoxColumn.ReadOnly = true;
            this.maxLossRiskDataGridViewTextBoxColumn.ToolTipText = "Maximum loss risk";
            this.maxLossRiskDataGridViewTextBoxColumn.Width = 65;
            // 
            // lowerBreakevenDataGridViewTextBoxColumn
            // 
            this.lowerBreakevenDataGridViewTextBoxColumn.DataPropertyName = "LowerBreakeven";
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle32.Format = "P2";
            dataGridViewCellStyle32.NullValue = "N/A";
            this.lowerBreakevenDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle32;
            this.lowerBreakevenDataGridViewTextBoxColumn.HeaderText = "Lower Zero Return";
            this.lowerBreakevenDataGridViewTextBoxColumn.Name = "lowerBreakevenDataGridViewTextBoxColumn";
            this.lowerBreakevenDataGridViewTextBoxColumn.ReadOnly = true;
            this.lowerBreakevenDataGridViewTextBoxColumn.ToolTipText = "Lower zero return (breakeven / protection) in % of stock price";
            this.lowerBreakevenDataGridViewTextBoxColumn.Width = 65;
            // 
            // upperBreakevenDataGridViewTextBoxColumn
            // 
            this.upperBreakevenDataGridViewTextBoxColumn.DataPropertyName = "UpperBreakeven";
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle33.Format = "P2";
            dataGridViewCellStyle33.NullValue = "N/A";
            this.upperBreakevenDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle33;
            this.upperBreakevenDataGridViewTextBoxColumn.HeaderText = "Upper Zero Return";
            this.upperBreakevenDataGridViewTextBoxColumn.Name = "upperBreakevenDataGridViewTextBoxColumn";
            this.upperBreakevenDataGridViewTextBoxColumn.ReadOnly = true;
            this.upperBreakevenDataGridViewTextBoxColumn.ToolTipText = "Upper zero return (breakeven / protection) in % of stock price";
            this.upperBreakevenDataGridViewTextBoxColumn.Width = 65;
            // 
            // returnAtPriceDataGridViewTextBoxColumn
            // 
            this.returnAtPriceDataGridViewTextBoxColumn.DataPropertyName = "ReturnAtMovement";
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle34.Format = "N2";
            dataGridViewCellStyle34.NullValue = "N/A";
            this.returnAtPriceDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle34;
            this.returnAtPriceDataGridViewTextBoxColumn.HeaderText = "Return @ Movement";
            this.returnAtPriceDataGridViewTextBoxColumn.Name = "returnAtPriceDataGridViewTextBoxColumn";
            this.returnAtPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.returnAtPriceDataGridViewTextBoxColumn.ToolTipText = "Return at specificed stock price movement from last price";
            this.returnAtPriceDataGridViewTextBoxColumn.Width = 65;
            // 
            // meanReturnDataGridViewTextBoxColumn
            // 
            this.meanReturnDataGridViewTextBoxColumn.DataPropertyName = "MeanReturn";
            dataGridViewCellStyle35.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle35.Format = "N2";
            dataGridViewCellStyle35.NullValue = "N/A";
            this.meanReturnDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle35;
            this.meanReturnDataGridViewTextBoxColumn.HeaderText = "Expected Return";
            this.meanReturnDataGridViewTextBoxColumn.Name = "meanReturnDataGridViewTextBoxColumn";
            this.meanReturnDataGridViewTextBoxColumn.ReadOnly = true;
            this.meanReturnDataGridViewTextBoxColumn.ToolTipText = "Expected return given the stock movement probability";
            this.meanReturnDataGridViewTextBoxColumn.Width = 75;
            // 
            // meanReturnPrcDataGridViewTextBoxColumn
            // 
            this.meanReturnPrcDataGridViewTextBoxColumn.DataPropertyName = "MeanReturnPrc";
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle36.Format = "P2";
            dataGridViewCellStyle36.NullValue = "N/A";
            this.meanReturnPrcDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle36;
            this.meanReturnPrcDataGridViewTextBoxColumn.HeaderText = "1Mo % Expected";
            this.meanReturnPrcDataGridViewTextBoxColumn.Name = "meanReturnPrcDataGridViewTextBoxColumn";
            this.meanReturnPrcDataGridViewTextBoxColumn.ReadOnly = true;
            this.meanReturnPrcDataGridViewTextBoxColumn.ToolTipText = "Expected return given the stock movement probability factored to 1 month return %" +
                "";
            this.meanReturnPrcDataGridViewTextBoxColumn.Width = 65;
            // 
            // totalDeltaDataGridViewTextBoxColumn
            // 
            this.totalDeltaDataGridViewTextBoxColumn.DataPropertyName = "TotalDelta";
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle37.Format = "N2";
            dataGridViewCellStyle37.NullValue = "N/A";
            this.totalDeltaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle37;
            this.totalDeltaDataGridViewTextBoxColumn.HeaderText = "Delta";
            this.totalDeltaDataGridViewTextBoxColumn.Name = "totalDeltaDataGridViewTextBoxColumn";
            this.totalDeltaDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalDeltaDataGridViewTextBoxColumn.ToolTipText = "Total position delta";
            this.totalDeltaDataGridViewTextBoxColumn.Width = 65;
            // 
            // totalGammaDataGridViewTextBoxColumn
            // 
            this.totalGammaDataGridViewTextBoxColumn.DataPropertyName = "TotalGamma";
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle38.Format = "N2";
            dataGridViewCellStyle38.NullValue = "N/A";
            this.totalGammaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle38;
            this.totalGammaDataGridViewTextBoxColumn.HeaderText = "Gamma";
            this.totalGammaDataGridViewTextBoxColumn.Name = "totalGammaDataGridViewTextBoxColumn";
            this.totalGammaDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalGammaDataGridViewTextBoxColumn.ToolTipText = "Total position gamma";
            this.totalGammaDataGridViewTextBoxColumn.Width = 65;
            // 
            // totalThetaDataGridViewTextBoxColumn
            // 
            this.totalThetaDataGridViewTextBoxColumn.DataPropertyName = "TotalTheta";
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle39.Format = "N2";
            dataGridViewCellStyle39.NullValue = "N/A";
            this.totalThetaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle39;
            this.totalThetaDataGridViewTextBoxColumn.HeaderText = "Theta";
            this.totalThetaDataGridViewTextBoxColumn.Name = "totalThetaDataGridViewTextBoxColumn";
            this.totalThetaDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalThetaDataGridViewTextBoxColumn.ToolTipText = "Total position theta";
            this.totalThetaDataGridViewTextBoxColumn.Width = 65;
            // 
            // totalVegaDataGridViewTextBoxColumn
            // 
            this.totalVegaDataGridViewTextBoxColumn.DataPropertyName = "TotalVega";
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle40.Format = "N2";
            dataGridViewCellStyle40.NullValue = "N/A";
            this.totalVegaDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle40;
            this.totalVegaDataGridViewTextBoxColumn.HeaderText = "Vega";
            this.totalVegaDataGridViewTextBoxColumn.Name = "totalVegaDataGridViewTextBoxColumn";
            this.totalVegaDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalVegaDataGridViewTextBoxColumn.ToolTipText = "Total position vega";
            this.totalVegaDataGridViewTextBoxColumn.Width = 65;
            // 
            // interestPaidDataGridViewTextBoxColumn
            // 
            this.interestPaidDataGridViewTextBoxColumn.DataPropertyName = "InterestPaid";
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle41.Format = "N2";
            dataGridViewCellStyle41.NullValue = "N/A";
            this.interestPaidDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle41;
            this.interestPaidDataGridViewTextBoxColumn.HeaderText = "Interest";
            this.interestPaidDataGridViewTextBoxColumn.Name = "interestPaidDataGridViewTextBoxColumn";
            this.interestPaidDataGridViewTextBoxColumn.ReadOnly = true;
            this.interestPaidDataGridViewTextBoxColumn.ToolTipText = "Intereset paid";
            this.interestPaidDataGridViewTextBoxColumn.Width = 65;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeight = 22;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dataGridView1.DataSource = this.stocksTableBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(9, 35);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 16;
            this.dataGridView1.RowTemplate.Height = 20;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView1.Size = new System.Drawing.Size(279, 175);
            this.dataGridView1.TabIndex = 22;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Symbol";
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.Cornsilk;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle42;
            this.dataGridViewTextBoxColumn1.HeaderText = "Symbol";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 95;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Database";
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.Cornsilk;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle43;
            this.dataGridViewTextBoxColumn2.HeaderText = "Database";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 180;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Analysis";
            dataGridViewCellStyle44.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.Cornsilk;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridViewTextBoxColumn3.HeaderText = "Analysis";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Visible = false;
            this.dataGridViewTextBoxColumn3.Width = 110;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 19);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(40, 13);
            this.label33.TabIndex = 23;
            this.label33.Text = "Status:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(316, 23);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(10, 13);
            this.label44.TabIndex = 37;
            this.label44.Text = "-";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(9, 22);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(126, 17);
            this.checkBox1.TabIndex = 35;
            this.checkBox1.Text = "Expiration date range";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarForeColor = System.Drawing.Color.Cornsilk;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(0)))));
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.DarkSeaGreen;
            this.dateTimePicker1.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.dateTimePicker1.CalendarTrailingForeColor = System.Drawing.Color.LightGray;
            this.dateTimePicker1.CustomFormat = "d-MMM-yyyy";
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(332, 19);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(95, 20);
            this.dateTimePicker1.TabIndex = 39;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarForeColor = System.Drawing.Color.Cornsilk;
            this.dateTimePicker2.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(48)))), ((int)(((byte)(0)))));
            this.dateTimePicker2.CalendarTitleBackColor = System.Drawing.Color.DarkSeaGreen;
            this.dateTimePicker2.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.dateTimePicker2.CalendarTrailingForeColor = System.Drawing.Color.LightGray;
            this.dateTimePicker2.CustomFormat = "d-MMM-yyyy";
            this.dateTimePicker2.Enabled = false;
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(215, 19);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(95, 20);
            this.dateTimePicker2.TabIndex = 37;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 2;
            this.numericUpDown1.Enabled = false;
            this.numericUpDown1.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown1.Location = new System.Drawing.Point(332, 46);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown1.TabIndex = 51;
            this.numericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown1.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DecimalPlaces = 2;
            this.numericUpDown2.Enabled = false;
            this.numericUpDown2.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown2.Location = new System.Drawing.Point(332, 21);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown2.TabIndex = 49;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown2.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.DecimalPlaces = 2;
            this.numericUpDown3.Enabled = false;
            this.numericUpDown3.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown3.Location = new System.Drawing.Point(215, 47);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown3.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown3.TabIndex = 50;
            this.numericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.DecimalPlaces = 2;
            this.numericUpDown4.Enabled = false;
            this.numericUpDown4.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown4.Location = new System.Drawing.Point(215, 22);
            this.numericUpDown4.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown4.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown4.TabIndex = 48;
            this.numericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(433, 49);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(94, 13);
            this.label45.TabIndex = 41;
            this.label45.Text = "[ % of stock-price ]";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(316, 49);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(10, 13);
            this.label46.TabIndex = 43;
            this.label46.Text = "-";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(9, 48);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(188, 17);
            this.checkBox2.TabIndex = 42;
            this.checkBox2.Text = "Out of the money stike price range";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(433, 23);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(94, 13);
            this.label47.TabIndex = 17;
            this.label47.Text = "[ % of stock-price ]";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(316, 23);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(10, 13);
            this.label48.TabIndex = 37;
            this.label48.Text = "-";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(9, 22);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(168, 17);
            this.checkBox3.TabIndex = 35;
            this.checkBox3.Text = "In the money stike price range";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // restartButton
            // 
            this.restartButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.restartButton.Location = new System.Drawing.Point(17, 420);
            this.restartButton.Name = "restartButton";
            this.restartButton.Size = new System.Drawing.Size(90, 24);
            this.restartButton.TabIndex = 12;
            this.restartButton.Text = "<< Restart";
            this.restartButton.UseVisualStyleBackColor = true;
            this.restartButton.Click += new System.EventHandler(this.restartButton_Click);
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.DecimalPlaces = 2;
            this.numericUpDown5.Enabled = false;
            this.numericUpDown5.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown5.Location = new System.Drawing.Point(332, 82);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown5.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown5.TabIndex = 50;
            this.numericUpDown5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown5.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.DecimalPlaces = 2;
            this.numericUpDown6.Enabled = false;
            this.numericUpDown6.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown6.Location = new System.Drawing.Point(332, 60);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown6.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown6.TabIndex = 47;
            this.numericUpDown6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown6.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.DecimalPlaces = 2;
            this.numericUpDown7.Enabled = false;
            this.numericUpDown7.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown7.Location = new System.Drawing.Point(215, 83);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown7.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown7.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown7.TabIndex = 49;
            this.numericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown7.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.DecimalPlaces = 2;
            this.numericUpDown8.Enabled = false;
            this.numericUpDown8.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown8.Location = new System.Drawing.Point(215, 61);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown8.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown8.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown8.TabIndex = 45;
            this.numericUpDown8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown8.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(316, 85);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(10, 13);
            this.label65.TabIndex = 42;
            this.label65.Text = "-";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(9, 84);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(119, 17);
            this.checkBox4.TabIndex = 48;
            this.checkBox4.Text = "Strategy total Theta";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(316, 62);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(10, 13);
            this.label66.TabIndex = 43;
            this.label66.Text = "-";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(9, 61);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(116, 17);
            this.checkBox5.TabIndex = 44;
            this.checkBox5.Text = "Strategy total Vega";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.DecimalPlaces = 2;
            this.numericUpDown9.Enabled = false;
            this.numericUpDown9.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown9.Location = new System.Drawing.Point(332, 38);
            this.numericUpDown9.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown9.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown9.TabIndex = 20;
            this.numericUpDown9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown9.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.DecimalPlaces = 2;
            this.numericUpDown10.Enabled = false;
            this.numericUpDown10.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown10.Location = new System.Drawing.Point(332, 16);
            this.numericUpDown10.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown10.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown10.TabIndex = 17;
            this.numericUpDown10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown10.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // numericUpDown11
            // 
            this.numericUpDown11.DecimalPlaces = 2;
            this.numericUpDown11.Enabled = false;
            this.numericUpDown11.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown11.Location = new System.Drawing.Point(215, 39);
            this.numericUpDown11.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown11.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown11.Name = "numericUpDown11";
            this.numericUpDown11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown11.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown11.TabIndex = 19;
            this.numericUpDown11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown11.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            // 
            // numericUpDown12
            // 
            this.numericUpDown12.DecimalPlaces = 2;
            this.numericUpDown12.Enabled = false;
            this.numericUpDown12.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown12.Location = new System.Drawing.Point(215, 17);
            this.numericUpDown12.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown12.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDown12.Name = "numericUpDown12";
            this.numericUpDown12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpDown12.Size = new System.Drawing.Size(95, 20);
            this.numericUpDown12.TabIndex = 16;
            this.numericUpDown12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown12.Value = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(316, 41);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(10, 13);
            this.label67.TabIndex = 0;
            this.label67.Text = "-";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(9, 40);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(127, 17);
            this.checkBox6.TabIndex = 18;
            this.checkBox6.Text = "Strategy total Gamma";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(316, 18);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(10, 13);
            this.label68.TabIndex = 0;
            this.label68.Text = "-";
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(9, 17);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(116, 17);
            this.checkBox7.TabIndex = 15;
            this.checkBox7.Text = "Strategy total Delta";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // opwSaveFileDialog
            // 
            this.opwSaveFileDialog.Filter = "opw files (*.opw)|*.opw|csv files (*.csv)|*.csv|All files (*.*)|*.*";
            this.opwSaveFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opwPath;
            // 
            // opwOpenFileDialog
            // 
            this.opwOpenFileDialog.Filter = "opw files (*.opw)|*.opw|All files (*.*)|*.*";
            this.opwOpenFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opwPath;
            // 
            // opsSaveFileDialog
            // 
            this.opsSaveFileDialog.Filter = "Wizard strategy files (*.ops)|*.ops|All files (*.*)|*.*";
            this.opsSaveFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opsPath;
            // 
            // opsOpenFileDialog
            // 
            this.opsOpenFileDialog.Filter = "Wizard strategy files (*.ops)|*.ops|All files (*.*)|*.*";
            this.opsOpenFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opsPath;
            // 
            // txtSaveFileDialog
            // 
            this.txtSaveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            this.txtSaveFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.txtPath;
            // 
            // txtOpenFileDialog
            // 
            this.txtOpenFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            this.txtOpenFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.txtPath;
            // 
            // opxSaveFileDialog
            // 
            this.opxSaveFileDialog.Filter = "Wizard strategy result files (*.opx)|*.opx|All files (*.*)|*.*";
            this.opxSaveFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opxPath;
            // 
            // opxOpenFileDialog
            // 
            this.opxOpenFileDialog.Filter = "Wizard strategy result files (*.opx)|*.opx|All files (*.*)|*.*";
            this.opxOpenFileDialog.InitialDirectory = global::OptionsOracle.Properties.Settings.Default.opxPath;
            // 
            // WizardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 452);
            this.Controls.Add(this.restartButton);
            this.Controls.Add(this.skipAllButton);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.wizardControl);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.cancelButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "WizardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Strategy Wizard";
            this.strategyGroup.ResumeLayout(false);
            this.strategyGroup.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.strategyDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wizardTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wizardSet)).EndInit();
            this.strategyTabControl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.investmentSizeManualNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateRulesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.strikeRulesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.expirationRulesBindingSource)).EndInit();
            this.wizardControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.stockListGroupBox.ResumeLayout(false);
            this.stockListGroupBox.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.historicalVolNotePanel.ResumeLayout(false);
            this.historicalVolNotePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockMaxVolRatioNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMinVolRatioNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMaxHisVolNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMinHisVolNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMaxImpVolNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMinImpVolNumericUpDown)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maxResultsNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minOpenIntNumericUpDown)).EndInit();
            this.expirationFilterGroupBox.ResumeLayout(false);
            this.expirationFilterGroupBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockMaxPriceNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMinPriceNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otmMaxStrikeNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itmMaxStrikeNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otmMinStrikeNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itmMinStrikeNumericUpDown)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maxMaxLossNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minMaxProfitNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.minProtectionNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.profitLossMinRatioNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.maxBreakevenNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.protectionMaxProbNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.protectionMinProbNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.breakevenMaxProbNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.breakevenMinProbNumericUpDown)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.totalThetaMaxNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalVegaMaxNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalThetaMinNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalVegaMinNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalGammaMaxNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalDeltaMaxNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalGammaMinNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.totalDeltaMinNumericUpDown)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockMoveMaxStdDevNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMoveMinStdDevNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMoveMaxNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockMoveMinNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.expReturnMinNumericUpDown)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.indicator2GroupBox.ResumeLayout(false);
            this.indicator2GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.indicator2MaxNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicator2MinNumericUpDown)).EndInit();
            this.indicator1GroupBox.ResumeLayout(false);
            this.indicator1GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.indicator1MaxNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicator1MinNumericUpDown)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.stockDatabaseGroupBox.ResumeLayout(false);
            this.stockDatabaseGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockListDataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stocksTableBindingSource)).EndInit();
            this.downloadMethodGroupBox.ResumeLayout(false);
            this.downloadMethodGroupBox.PerformLayout();
            this.progressGroupBox.ResumeLayout(false);
            this.progressGroupBox.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockListDataGridView2)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultsTableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ComboBox strategyComboBox;
        private System.Windows.Forms.GroupBox strategyGroup;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl wizardControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox oldDaysTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton dw3RadioButton;
        private System.Windows.Forms.RadioButton dw2RadioButton;
        private System.Windows.Forms.RadioButton dw1RadioButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox stocksListTextBox;
        private System.Windows.Forms.Button nextButton;
        private System.Windows.Forms.Label infoLabel;
        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.GroupBox stockListGroupBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox downloadMethodGroupBox;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.TabPage tabPage3;
        private OptionsOracle.Data.WizardSet wizardSet;
        private System.Windows.Forms.BindingSource wizardTableBindingSource;
        private System.Windows.Forms.DataGridView strategyDataGridView;
        private System.Windows.Forms.Button addRowbutton;
        private System.Windows.Forms.Button deleteRowbutton;
        private System.Windows.Forms.Button clearPositionButton;
        private System.Windows.Forms.NumericUpDown investmentSizeManualNumericUpDown;
        private System.Windows.Forms.Button loadButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.BindingSource strikeRulesBindingSource;
        private System.Windows.Forms.BindingSource expirationRulesBindingSource;
        private System.Windows.Forms.BindingSource dateRulesBindingSource;
        private System.Windows.Forms.DateTimePicker endDateManualDateTimePicker;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox expirationFilterGroupBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox expFilterCheckBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker maxExpDateTimePicker;
        private System.Windows.Forms.DateTimePicker minExpDateTimePicker;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox itmStrikeFilterCheckBox;
        private System.Windows.Forms.NumericUpDown otmMaxStrikeNumericUpDown;
        private System.Windows.Forms.NumericUpDown itmMaxStrikeNumericUpDown;
        private System.Windows.Forms.NumericUpDown otmMinStrikeNumericUpDown;
        private System.Windows.Forms.NumericUpDown itmMinStrikeNumericUpDown;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.CheckBox otmStrikeFilterCheckBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox openIntFilterCheckBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown minOpenIntNumericUpDown;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button downloadStartStopButton;
        private System.Windows.Forms.Label label15;
        private System.ComponentModel.BackgroundWorker taskWorker;
        private System.Windows.Forms.Label downloadStartTimeLabel;
        private System.Windows.Forms.Label downloadStatusLabel;
        private System.Windows.Forms.ProgressBar downloadProgressBar;
        private System.Windows.Forms.DataGridView stockListDataGridView1;
        private System.Windows.Forms.BindingSource stocksTableBindingSource;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label downloadEstFinishTimeLabel;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Timer taskTimer;
        private System.Windows.Forms.GroupBox progressGroupBox;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label analysisStatusLabel;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button analysisStartStopButton;
        private System.Windows.Forms.ProgressBar analysisProgressBar;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label analysisStartTimeLabel;
        private System.Windows.Forms.Label analysisEstFinishTimeLabel;
        private System.Windows.Forms.GroupBox stockDatabaseGroupBox;
        private System.Windows.Forms.DataGridView resultsDataGridView;
        private System.Windows.Forms.BindingSource resultsTableBindingSource;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn endDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn netInvestmentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maxProfitPotentialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn maxLossRiskDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lowerBreakevenDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn upperBreakevenDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn returnAtPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReturnAtMovementPrc;
        private System.Windows.Forms.DataGridViewTextBoxColumn meanReturnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn meanReturnPrcDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalDeltaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalGammaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalThetaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalVegaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn interestPaidDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox investmentSizeModeComboBox;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox endDateModeComboBox;
        private System.Windows.Forms.Label endDateManualLabel;
        private System.Windows.Forms.Label investmentSizeManualLabel;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.DataGridView stockListDataGridView2;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.NumericUpDown stockMaxImpVolNumericUpDown;
        private System.Windows.Forms.NumericUpDown stockMinImpVolNumericUpDown;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.CheckBox stockImpVolFilterCheckBox;
        private System.Windows.Forms.NumericUpDown stockMaxVolRatioNumericUpDown;
        private System.Windows.Forms.NumericUpDown stockMinVolRatioNumericUpDown;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.CheckBox stockVolRatioFilterCheckBox;
        private System.Windows.Forms.NumericUpDown stockMaxHisVolNumericUpDown;
        private System.Windows.Forms.NumericUpDown stockMinHisVolNumericUpDown;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.CheckBox stockHisVolFilterCheckBox;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel historicalVolNotePanel;
        private System.Windows.Forms.Button loadListButton;
        private System.Windows.Forms.Button saveListButton;
        private System.Windows.Forms.Button clearListButton;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.NumericUpDown expReturnMinNumericUpDown;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.CheckBox expReturnCheckBox;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.NumericUpDown totalGammaMaxNumericUpDown;
        private System.Windows.Forms.NumericUpDown totalDeltaMaxNumericUpDown;
        private System.Windows.Forms.NumericUpDown totalGammaMinNumericUpDown;
        private System.Windows.Forms.NumericUpDown totalDeltaMinNumericUpDown;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.CheckBox totalGammaCheckBox;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.CheckBox totalDeltaCheckBox;
        private System.Windows.Forms.NumericUpDown totalThetaMaxNumericUpDown;
        private System.Windows.Forms.NumericUpDown totalVegaMaxNumericUpDown;
        private System.Windows.Forms.NumericUpDown totalThetaMinNumericUpDown;
        private System.Windows.Forms.NumericUpDown totalVegaMinNumericUpDown;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.CheckBox totalThetaCheckBox;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.CheckBox totalVegaCheckBox;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.NumericUpDown breakevenMaxProbNumericUpDown;
        private System.Windows.Forms.NumericUpDown breakevenMinProbNumericUpDown;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.CheckBox breakevenProbCheckBox;
        private System.Windows.Forms.NumericUpDown profitLossMinRatioNumericUpDown;
        private System.Windows.Forms.CheckBox profitLossRatioCheckBox;
        private System.Windows.Forms.NumericUpDown protectionMaxProbNumericUpDown;
        private System.Windows.Forms.NumericUpDown protectionMinProbNumericUpDown;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.CheckBox protectionProbCheckBox;
        private System.Windows.Forms.Button resultLoadButton;
        private System.Windows.Forms.Button resultSaveButton;
        private System.Windows.Forms.CheckBox askBidFilterCheckBox;
        private System.Windows.Forms.CheckBox impVolFilterCheckBox;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button skipAllButton;
        private System.Windows.Forms.Button restartButton;
        private System.Windows.Forms.CheckBox duplicateOptionsFilterCheckBox;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown maxResultsNumericUpDown;
        private System.Windows.Forms.CheckBox maxResultsFilterCheckBox;
        private System.Windows.Forms.NumericUpDown stockMaxPriceNumericUpDown;
        private System.Windows.Forms.NumericUpDown stockMinPriceNumericUpDown;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox stockPriceFilterCheckBox;
        private System.Windows.Forms.Button moveButton;
        private System.Windows.Forms.NumericUpDown stockMoveMaxNumericUpDown;
        private System.Windows.Forms.NumericUpDown stockMoveMinNumericUpDown;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.CheckBox stockMoveCheckBox;
        private System.Windows.Forms.TabControl strategyTabControl;
        private System.Windows.Forms.TabPage tabStrategy1;
        private System.Windows.Forms.TabPage tabStrategy2;
        private System.Windows.Forms.TabPage tabStrategy3;
        private System.Windows.Forms.TabPage tabStrategy4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox moveDaysToExpTextBox;
        private System.Windows.Forms.TextBox moveHistoricalVolatilityTextBox;
        private System.Windows.Forms.TextBox moveImpiledVolatilityTextBox;
        private System.Windows.Forms.TextBox movePriceTextBox;
        private System.Windows.Forms.TextBox movePositionTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockDownloadSymbolColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockDownloadDatabaseColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockAnalysisSymbolColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockAnalysisAnalysisColumn;
        private System.Windows.Forms.NumericUpDown stockMoveMaxStdDevNumericUpDown;
        private System.Windows.Forms.NumericUpDown stockMoveMinStdDevNumericUpDown;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.RadioButton stockMove2RadioButton;
        private System.Windows.Forms.RadioButton stockMove1RadioButton;
        private System.Windows.Forms.Button quickGetButton;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.NumericUpDown numericUpDown11;
        private System.Windows.Forms.NumericUpDown numericUpDown12;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox indicator1CheckBox;
        private System.Windows.Forms.GroupBox indicator1GroupBox;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox indicator1FormatTextBox;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.TextBox indicator1NameTextBox;
        private System.Windows.Forms.TextBox indicator1EquationTextBox;
        private System.Windows.Forms.CheckBox indicator2CheckBox;
        private System.Windows.Forms.GroupBox indicator2GroupBox;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox indicator2FormatTextBox;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox indicator2NameTextBox;
        private System.Windows.Forms.TextBox indicator2EquationTextBox;
        private System.Windows.Forms.NumericUpDown indicator2MaxNumericUpDown;
        private System.Windows.Forms.NumericUpDown indicator2MinNumericUpDown;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.CheckBox indicator2FilterCheckBox;
        private System.Windows.Forms.NumericUpDown indicator1MaxNumericUpDown;
        private System.Windows.Forms.NumericUpDown indicator1MinNumericUpDown;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.CheckBox indicator1FilterCheckBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardEndDateColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardIndexColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardTypeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardQuantityColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardStrikeSign1Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardStrike1Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardStrikeSign2Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardStrike2Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardExpirationSign1Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardExpiration1Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardExpirationSign2Column;
        private System.Windows.Forms.DataGridViewComboBoxColumn wizardExpiration2Column;
        private System.Windows.Forms.Button clearSetButton;
        private System.Windows.Forms.Button loadSetButton;
        private System.Windows.Forms.Button saveSetButton;
        private System.Windows.Forms.NumericUpDown minProtectionNumericUpDown;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.CheckBox minProtectionCheckBox;
        private System.Windows.Forms.NumericUpDown maxBreakevenNumericUpDown;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.CheckBox maxBreakevenCheckBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsIndexColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsStockColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsPositionColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsEndDateColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsNetInvestmentColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsTotalDebitColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsMaxProfitPotentialColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsMaxProfitPotentialPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsMaxLossRiskColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsMaxLossRiskPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsLowerBreakevenColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsUpperBreakevenColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsReturnAtMovementColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsReturnAtMovementPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsMeanReturnColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsMeanReturnPrcColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsTotalDeltaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsTotalGammaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsTotalThetaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsTotalVegaColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsInterestPaidColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsBreakevenProbColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsProtectionProbColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsProfitLossRatioColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsStockLastPriceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsStockImpVolatilityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsStockHisVolatilityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsIndicator1Column;
        private System.Windows.Forms.DataGridViewTextBoxColumn wizardResultsIndicator2Column;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.CheckBox maxMaxLossCheckBox;
        private System.Windows.Forms.CheckBox minMaxProfitCheckBox;
        private System.Windows.Forms.NumericUpDown maxMaxLossNumericUpDown;
        private System.Windows.Forms.NumericUpDown minMaxProfitNumericUpDown;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.SaveFileDialog opwSaveFileDialog;
        private System.Windows.Forms.OpenFileDialog opwOpenFileDialog;
        private System.Windows.Forms.SaveFileDialog opsSaveFileDialog;
        private System.Windows.Forms.OpenFileDialog opsOpenFileDialog;
        private System.Windows.Forms.SaveFileDialog txtSaveFileDialog;
        private System.Windows.Forms.OpenFileDialog txtOpenFileDialog;
        private System.Windows.Forms.SaveFileDialog opxSaveFileDialog;
        private System.Windows.Forms.OpenFileDialog opxOpenFileDialog;
    }
}